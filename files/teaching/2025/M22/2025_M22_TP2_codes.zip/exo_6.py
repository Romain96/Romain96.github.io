import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

if __name__ == "__main__":
	print("M22 - TP2 - Exercice 6")

	# 1.	Importer les données dans un dataframe pandas appelé df et le modifier afin de garder les lignes correspondantes à la station de Strasbourg Entzheim.
	df = pd.read_csv("exo_6/DECADAGRO_67_previous-1950-2024.csv", sep=";")
	print(df)

	df = df[df["NOM_USUEL"] == "STRASBOURG-ENTZHEIM"]
	print(df)

	# 2.	Créer un tableau NumPy y_max contenant les valeurs de la colonne TX.
	y_max = df["TX"].to_numpy()
	print(y_max)

	# 3.	Créer un tableau NumPy y_min contenant les valeurs de la colonne TN.
	y_min = df["TN"].to_numpy()
	print(y_min)

	# 4.	Créer un tableau Numpy x contenant les valeurs de 0 à N avec N la longueur de TX et TN.
	x = np.arange(0, y_max.shape[0], 1)
	print(x)

	# 5.	Visualiser graphiquement les valeurs de y_max et y_min en fonction de x.
	fig, ax = plt.subplots()
	ax.plot(x, y_max, 'r', label="y_max")
	ax.plot(x, y_min, 'b', label="y_min")
	ax.legend()
	ax.set_title("Température de la station de Strasbourg-Entzheim (1950-2024)")
	ax.set_xlabel("Points de mesure")
	ax.set_ylabel("Température (°c)")
	plt.show()

	# 6.	Utiliser NumPy (polyfit et polyval) pour calculer les tendances des séries y_max et y_min.
	p_min = np.polyfit(x, y_min, 10)
	p_max = np.polyfit(x, y_max, 10)
	fit_p_min = np.poly1d(p_min)
	fit_p_max = np.poly1d(p_max)
	
	# 7.	Visualiser graphiquement les valeurs et tendances des série
	fig, ax = plt.subplots()
	ax.plot(x, fit_p_max(x), 'r')
	ax.plot(x, fit_p_min(x), 'b')
	ax.set_title("Extimation des tendances des température de la station de Strasbourg-Entzheim (1950-2024)")
	ax.set_xlabel("Points de mesure")
	ax.set_ylabel("Tendance de température (°c)")
	plt.show()
