import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

if __name__ == "__main__":
	print("M22 - TP2 - Exercice 6")

	# 1.	Importer les données dans un dataframe pandas appelé df et le modifier afin de garder les lignes correspondantes à la station de Strasbourg Entzheim.
	df = pd.read_csv("exo_6/DECADAGRO_67_previous-1950-2024.csv", sep=";")
	print(df)

	df = df[df["NOM_USUEL"] == "STRASBOURG-ENTZHEIM"]
	print(df)

	# 2.	Créer un tableau NumPy y_max contenant les valeurs de la colonne TX.
	y_max = df["TX"].to_numpy()
	print(y_max)

	# 3.	Créer un tableau NumPy y_min contenant les valeurs de la colonne TN.
	y_min = df["TN"].to_numpy()
	print(y_min)

	# 4.	Créer un tableau Numpy x contenant les valeurs de 0 à N avec N la longueur de TX et TN.
	x = np.arange(0, y_max.shape[0], 1)
	print(x)

	# 5.	Visualiser graphiquement les valeurs de y_max et y_min en fonction de x.
	fig, ax = plt.subplots()
	ax.plot(x, y_max, color="red", marker="", linestyle="-", linewidth=1, label="y_max")
	ax.plot(x, y_min, color="blue", marker="", linestyle="-", linewidth=1, label="y_min")
	ax.legend()
	ax.set_title("Températures de la station de Strasbourg-Entzheim (1950-2024)")
	ax.set_xlabel("Points de mesure")
	ax.set_ylabel("Température (°c)")
	plt.tight_layout()
	plt.show()

	# 6.	Utiliser NumPy (polyfit et polyval) pour calculer les tendances des séries y_max et y_min.
	# note : np.polyfit est dépréciée, j'utilise le nouveau module Polynomial
	tendance_min = np.polynomial.Polynomial.fit(x, y_min, deg=10)
	tendance_max = np.polynomial.Polynomial.fit(x, y_max, deg=10)
	tendance_min_x, tendance_min_y = tendance_min.linspace(n=x.shape[0]*10)
	tendance_max_x, tendance_max_y = tendance_max.linspace(n=x.shape[0]*10)
	
	# 7.	Visualiser graphiquement les valeurs et tendances des série
	fig, axs = plt.subplots(nrows=2, ncols=1, sharex=True, sharey=True)
	axs[0].plot(x, y_max, color="red", marker="", linestyle="-", linewidth=1, label="y_max")
	axs[0].plot(x, y_min, color="blue", marker="", linestyle="-", linewidth=1, label="y_min")
	axs[1].plot(tendance_min_x, tendance_min_y, color="blue", marker="", linestyle="-", linewidth=2, label="tendance y_min")
	axs[1].plot(tendance_max_x, tendance_max_y, color="red", marker="", linestyle="-", linewidth=2, label="tendance y_max")
	axs[0].set_title("Températures mesurées")
	axs[1].set_title("Estimation des tendances des températures")
	axs[0].set_xlabel("Points de mesure")
	axs[1].set_xlabel("Points de mesure")
	axs[0].set_ylabel("Température (°c)")
	axs[1].set_ylabel("Tendance de température (°c)")
	plt.suptitle("Station météo de Strasbourg-Entzheim (1950-2024)")
	axs[0].legend()
	axs[1].legend()
	plt.legend()
	plt.tight_layout()
	plt.show()