import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

if __name__ == "__main__":
	print("M22 - TP2 - Exercice 5")

	# 1.    Charger les données dans un dataframe
	df = pd.read_csv("exo_5/fr-esr-parcoursup_2021.csv", sep=";")

	# Modifier df afin de garder les colonnes suivantes :
	columns = []
	# a. le code UAI de l’établissement
	columns.append("Code UAI de l'établissement")
	# b. l’intitulé de la formation
	columns.append("Filière de formation détaillée")
	# c. les taux d’admissions
	columns.append("% d’admis ayant reçu leur proposition d’admission à l'ouverture de la procédure principale")
	columns.append("% d’admis ayant reçu leur proposition d’admission avant le baccalauréat")
	columns.append("% d’admis ayant reçu leur proposition d’admission avant la fin de la procédure principale")
	columns.append("% d’admis dont filles")
	columns.append("% d’admis néo bacheliers issus de la même académie")
	columns.append("% d’admis néo bacheliers issus de la même académie (Paris/Créteil/Versailles réunies)")
	columns.append("% d’admis néo bacheliers issus du même établissement (BTS/CPGE)")
	columns.append("% d’admis néo bacheliers boursiers")
	columns.append("% d’admis néo bacheliers")
	columns.append("% d’admis néo bacheliers sans information sur la mention au bac")
	columns.append("% d’admis néo bacheliers sans mention au bac")
	columns.append("% d’admis néo bacheliers avec mention Assez Bien au bac")
	columns.append("% d’admis néo bacheliers avec mention Bien au bac")
	columns.append("% d’admis néo bacheliers avec mention Très Bien au bac")
	columns.append("% d’admis néo bacheliers avec mention Très Bien avec félicitations au bac")
	columns.append("% d’admis néo bacheliers généraux")
	columns.append("% d’admis néo bacheliers technologiques")
	columns.append("% d’admis néo bacheliers professionnels")

	df = df[columns]
	print(df)

	# 3. Modifier df afin de garder les lignes correspondant à l’IUT Robert Schuman.
	df = df[df["Code UAI de l'établissement"] == "0671557D"]
	print(df)
	print(df["Filière de formation détaillée"])

	# 4. Créer une nouvelle colonne formation qui contiendra les 32 premiers caractères de l'intitulé de la formation.
	df["formation"] = df["Filière de formation détaillée"].map(lambda x : x[26:])
	print(df[["formation"]])

	# 5. Afficher un graphique à barres représentant les différents taux d’admission pour chaque formation.

	ax = df.plot.bar(title="Taux d'admission pour l'IUT Robert Schuman")
	plt.legend(bbox_to_anchor=(1.04, 1), loc="upper left")
	plt.subplots_adjust(right=0.7)
	plt.tight_layout(rect=[0, 0, 0.75, 1])
	plt.show()
