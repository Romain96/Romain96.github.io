import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

if __name__ == "__main__":
	print("M22 - TP2 - Exercice 7")

	# 1.	Créer un dataframe df_201x pour chaque année concernés par l’étude à partir des données téléchargées.

	df_2018 = pd.read_csv("exo_7/fr-esr-parcoursup_2018.csv", sep=";")
	df_2019 = pd.read_csv("exo_7/fr-esr-parcoursup_2019.csv", sep=";")
	df_2020 = pd.read_csv("exo_7/fr-esr-parcoursup_2020.csv", sep=";")
	df_2021 = pd.read_csv("exo_7/fr-esr-parcoursup_2021.csv", sep=";")
	df_2022 = pd.read_csv("exo_7/fr-esr-parcoursup_2022.csv", sep=";")
	dfs = {
		"2018": df_2018, 
		"2019": df_2019, 
		"2020": df_2020, 
		"2021": df_2021, 
		#"2022": df_2022
	}
	for key in dfs.keys():
		print(f"Import de df_{key} :\n{dfs[key].describe()}")

	# 2.	Modifier df afin de garder les lignes correspondant à l’IUT Robert Schuman.
	for key in dfs.keys():
		df = dfs[key]
		dfs[key] = df[df["Établissement"] == "I.U.T. d'Illkirch"]
		print(f"df_{key} avec seulement l'IUTRS :\n{dfs[key].describe()}")

	# 3.	Modifier df afin de garder les lignes correspondant aux formations suivantes :
	# a.	Chimie
	# b.	Informatique
	# c. 	Techniques de commercialisation
	formations = ["Chimie", "Informatique", "Techniques de commercialisation"]
	for key in dfs.keys():
		df = dfs[key]
		dfs[key] = df[df["Filière de formation détaillée"].str.match(".*Chimie.*|.*Informatique.*|.*Techniques de commercialisation.*")]
		print(f"df_{key} avec ['Chimie', 'Informatique', 'Techniques de commercialisation']:\n{dfs[key]}")

	# 4.	Modifier df pour garder les colonnes suivantes :
	# a.	l’année de la session
	# b.	l’intitulé de la formation
	# c.	le pourcentage de bac techno
	colonnes =  ["Session", "Filière de formation détaillée", "% d’admis néo bacheliers technologiques"]
	for key in dfs.keys():
		df = dfs[key]
		dfs[key] = df[colonnes]
		print(f"df_{key} avec ['Session', 'Filière de formation détaillée', '% d’admis néo bacheliers technologiques'] :\n{dfs[key]}")

	# 5.	Afficher sous forme de graphique l’évolution du taux d'admission des étudiants provenant de bacs technologiques.
	df = pd.concat([dfs[i] for i in dfs.keys()])
	print(df)
	chimie = df[df["Filière de formation détaillée"].str.match(".*Chimie.*")]
	info = df[df["Filière de formation détaillée"].str.match(".*Informatique.*")]
	techdeco = df[df["Filière de formation détaillée"].str.match(".*Techniques de commercialisation.*")]

	fig, ax = plt.subplots()
	ax.plot(chimie["Session"], chimie["% d’admis néo bacheliers technologiques"], 'r-', label="Chimie")
	ax.plot(info["Session"], info["% d’admis néo bacheliers technologiques"], 'b-', label="Informatique")
	ax.plot(techdeco["Session"], techdeco["% d’admis néo bacheliers technologiques"], 'g-', label="Tech. de co.")
	ax.set_xlim(2017, 2022)
	ax.set_ylim(0, 100)
	plt.title("Évolution du pourcentage de bacheliers technologiques à l'IUTRS (2018-2021)")
	plt.xlabel("Année")
	plt.ylabel("% de bachelier technologiques")
	plt.legend()
	plt.tight_layout()
	plt.show()
