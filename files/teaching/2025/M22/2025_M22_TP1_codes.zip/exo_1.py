import numpy as np

if __name__ == "__main__":
    print("M22 - TP1 - Exercice 1")
    
    # 1.    Créer les listes suivantes
    #       - a : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    #       - b : [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43]
    #       - d : ['quatre', 'chaînes', 'de', 'caractères']
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    b = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43]
    d = ['quatre', 'chaînes', 'de', 'caractères']
    print(f"\n1.\na = {a}, type = {type(a)}\nb = {b}, type = {type(b)}\nd = {d}, type = {type(d)}")
    
    # 2.    Transformer a et b en tableau NumPy
    a = np.array(a, np.int32)
    b = np.array(b, np.int32)
    print(f"\n2.\na = {a}, type = {type(a)}\nb = {b}, type = {type(b)}")
    
    # 3.    Ajouter 2 aux valeurs de a.
    #       Multiplier par 2 les valeurs de a
    a.__iadd__(2)   # ou bien : a = a.__add__(2)
    a.__imul__(2)   # ou bien : a = a.__mul__(2)
    print(f"\n3.\na * 2 = {a}\na + 2 = {a}")
    
    # 4.    Additionner et multiplier les tableaux a et b entre eux
    aplusb = a + b
    aprodb = a * b
    print(f"\n4.\na = {a}\nb = {b}")
    print(f"a + b = {aplusb}\na * b = {aprodb}")
    
    # 5.    Calculer (avec NumPy) pour b
    print(f"\n5.\nb = {b}")
    #       - a. moyenne
    print(f"moyenne de b = {b.mean()}")
    #       - b. variance
    print(f"variance de b = {b.var()}")
    #       - c. écart-type
    print(f"écart-type de b = {b.std()}")
    #       - d. médiane
    print(f"médiane de b = {np.median(b)}")
    #       - e. minimum
    print(f"minium de b = {b.min()}")
    #       - f. maximum
    print(f"maximum de b = {b.max()}")
    #       - g. quartiles
    print("quartiles de b :")
    print(f"- q1 = {np.quantile(b, 0.25)}") # premier quartile
    print(f"- q3 = {np.quantile(b, 0.75)}") # troisième quartile
