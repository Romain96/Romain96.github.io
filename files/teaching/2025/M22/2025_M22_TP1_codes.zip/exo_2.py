import numpy as np

# 1. Écrire une fonction moyenne donnant la moyenne d’une série numérique.
def moyenne (serie : np.ndarray) -> np.double:
    return serie.mean()
    
# 2. Écrire une fonction variance donnant la variance d’une série numérique.  
def variance (serie : np.ndarray) -> np.double:
    return serie.var()

# 3. Écrire une fonction ecart_type donnant l’écart-type d’une série numérique.
def ecart_type (serie : np.ndarray) -> np.double:
    return serie.std()

# 4. Créer un tableau vals_norm de 15 valeurs générées aléatoirement via une loi normale de moyenne 10 et d’écart-type 2.
def vals_norm (moyenne : float, ecart_type : float, n : int) -> np.ndarray:
    rng = np.random.default_rng()
    return rng.normal(loc = moyenne, scale = ecart_type, size = n)

# 5. Créer un tableau vals_unif de 15 valeurs générées aléatoirement via une loi uniforme sur l’intervalle [0 ; 20]
def vals_unif (min_val : float, max_val : float, n : int) -> np.ndarray:
    rng = np.random.default_rng()
    return rng.uniform(low = min_val, high = max_val, size = n)

if __name__ == "__main__":
    print("M22 - TP1 - Exercice 2")
    print(f"\n4.\nvals_norm(10, 2, 15) = {vals_norm(10, 2, 15)}")
    print(f"\n5.\nvals_unif(0, 20, 15) = {vals_unif(0, 20, 15)}")
