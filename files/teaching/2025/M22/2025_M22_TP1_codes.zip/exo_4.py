import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from exo_2 import ecart_type, vals_norm, vals_unif

if __name__ == "__main__":
	print("M22 - TP1 - Exercice 4")
	
	
	# 1. Créer un dataframe nommée df à partir de vals_norm et vals_unif avec les noms des colonnes suivants : norm et unif.
	norm = np.sort(vals_norm(10, 2, 15))
	unif = np.sort(vals_unif(0, 20, 15))
	df = pd.DataFrame(data = {"norm": norm, "unif": unif})
	print(f"\n1.\ndf =\n{df}")
	print(df.describe())
	
	# 2. Calculer l’écart type de la colonne norm (avec pandas) et l’écart type du tableau vals_norm (avec votre fonction ecart_type ou avec NumPy).
	#   a. Renseignez-vous sur la correction de Bessel [en.wikipedia.org].
	ecart_type_pd = df["norm"].std()
	ecart_type_np = df["norm"].to_numpy().std()
	print("\n2.a\ncalcul de l'écart-type de norm :")
	print(f"\tavec pandas : {ecart_type_pd}")
	print(f"\tavec numpy : {ecart_type_np}")
	
	#   b. Modifier la valeur renvoyée par pandas pour qu’elle corresponde à la valeur renvoyée par votre fonction.
	ecart_type_pd = df["norm"].std(ddof = 0)    # Delta Degrees of Freedom. The divisor used in calculations is N - ddof, where N represents the number of elements.
	print("\n2.b\ncalcul de l'écart-type de norm :")
	print(f"\tavec pandas : {ecart_type_pd}")
	print(f"\tavec numpy : {ecart_type_np}")
	
	# 3. Calculer la covariance, le coefficient de corrélation, ainsi que les constantes pour l’équation de régression linéaire pour les séries vals_norm et vals_unif.
	print("\n3.")
	print(f"covariance:\n{df.cov()}")
	print(f"coefficient de corrélation:\n{df.corr()}")
	
	x = np.arange(1, len(df) + 1, 1)

	# régression linéaire pour norm
	x_norm_bar = x.mean()
	y_norm_bar = df["norm"].mean()
	S_norm_xy = ((x - x_norm_bar) * (df["norm"] - y_norm_bar)).sum() / len(df)
	S_norm_x2 = x.var()
	a_norm = S_norm_xy / S_norm_x2
	b_norm = y_norm_bar - a_norm * x_norm_bar
	print(f"coefficients de régression linaire pour norm : a = {a_norm}, b = {b_norm}")

	# régression linéaire pour unif
	x_unif_bar = x.mean()
	y_unif_bar = df["unif"].mean()
	S_unif_xy = ((x - x_unif_bar) * (df["unif"] - y_unif_bar)).sum() / len(df)
	S_unif_x2 = x.var()
	a_unif = S_unif_xy / S_unif_x2
	b_unif = y_unif_bar - a_unif * x_unif_bar
	print(f"coefficients de régression linaire pour unif : a = {a_unif}, b = {b_unif}")
	
	# tracé des droites de régression linéaire
	fit_fn_norm = np.poly1d([a_norm, b_norm])
	fit_fn_unif = np.poly1d([a_unif, b_unif])

	fig, ax = plt.subplots()
	plt.plot(x, fit_fn_norm(x), 'r-')
	plt.plot(x, df['norm'], 'ro')
	plt.plot(x, fit_fn_unif(x), 'b-')
	plt.plot(x, df['unif'], 'bo')
	plt.show()
	
	# 4. Créer une deuxième dataframe qu’on nommera df2 avec les mêmes noms de colonnes et 5 valeurs supplémentaires.
	norm2 = np.sort(vals_norm(10, 2, 20))
	unif2 = np.sort(vals_unif(0, 20, 20))
	df2 = pd.DataFrame(data = {"norm": norm2, "unif": unif2})
	print(f"\n4.\ndf2 =\n{df2}")
	
	# 5. Ajouter les lignes de df2 à df.
	for i in range(df2["norm"].index.start, df2["norm"].index.stop, df2["norm"].index.step):
		df.loc[len(df)] = [df2["norm"].loc[i], df2["unif"].loc[i]]
	print(f"\n5.\ndf + df2 =\n{df}")
	
	# 6. Ajouter une colonne à df que l’on nommera somme qui est la somme des deux premières colonnes.
	df["somme"] = df["norm"] + df["unif"]
	print(f"\n6.\ndf =\n{df}")
	
	# 7. Sélectionner le sous dataframe de df qui ne contient que les valeurs supérieures à 5 dans la colonne unif.
	print(f"\n7.\n{df[df["unif"] > 5]}")
	
	# 8. Sélectionner le sous dataframe de df qui ne contient que les colonnes norm et somme
	print(f"\n8.\n{df[["norm", "somme"]]}")
