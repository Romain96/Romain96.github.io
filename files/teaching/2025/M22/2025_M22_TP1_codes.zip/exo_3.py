import numpy as np
import matplotlib.pyplot as plt

from exo_2 import vals_norm, vals_unif

# Visualiser a et b sur un graphique
def visu_ab () -> None:
    a = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    b = np.array([1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43])
    
    fig, ax = plt.subplots()
    x = np.arange(1, a.shape[0] + 1, 1)
    ax.plot(x, a, 'ro')
    ax.plot(x, b, 'bo')
    plt.show()

# Créer les tableaux vals_norm_sort et vals_unif_sort contenant les valeurs des tableaux vals_norm et vals_unif triées.
def creer_tableaux () -> tuple[np.ndarray, np.ndarray]:
    norm = np.sort(vals_norm(10, 2, 15))
    unif = np.sort(vals_unif(0, 20, 15))
    return (norm, unif)
    
# Visualiser vals_norm_sort et vals_unif_sort sur un graphique
def visu_tableaux (a : np.ndarray, b : np.ndarray) -> None:
    fig, ax = plt.subplots()
    xa = np.arange(1, a.shape[0] + 1, 1)
    xb = np.arange(1, b.shape[0] + 1, 1)
    ax.plot(xa, a, 'ro')
    ax.plot(xb, b, 'bo')
    plt.show()

if __name__ == "__main__":
    print("M22 - TP1 - Exercice 3")
    visu_ab()
    norm, unif = creer_tableaux()
    visu_tableaux(norm, unif)
    
