import numpy as np
import matplotlib.pyplot as plt

from exo_2 import vals_norm, vals_unif

# Visualiser a et b sur un graphique
def visu_ab () -> None:
    a = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    b = np.array([1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43])
    
    fig, ax = plt.subplots()
    x = np.arange(1, a.shape[0] + 1, 1)
    ax.plot(x, a, color="red", linestyle="", marker="o", label="a")
    ax.plot(x, b, color="blue", linestyle="", marker="o", label="b")
    ax.set_title("Visualisation de a et b")
    plt.legend()
    plt.show()

# Créer les tableaux vals_norm_sort et vals_unif_sort contenant les valeurs des tableaux vals_norm et vals_unif triées.
def creer_tableaux () -> tuple[np.ndarray, np.ndarray]:
    norm = np.sort(vals_norm(10, 2, 15))
    unif = np.sort(vals_unif(0, 20, 15))
    return (norm, unif)
    
# Visualiser vals_norm_sort et vals_unif_sort sur un graphique
def visu_tableaux (a : np.ndarray, b : np.ndarray, label_a, label_b) -> None:
    fig, ax = plt.subplots()
    x = np.arange(1, b.shape[0] + 1, 1)
    ax.plot(x, a, color="red", linestyle="", marker="o", label=label_a)
    ax.plot(x, b, color="blue", linestyle="", marker="o", label=label_b)
    ax.set_title("Visualisation de " + label_a + " et " + label_b)
    plt.legend()
    plt.show()

if __name__ == "__main__":
    print("M22 - TP1 - Exercice 3")
    visu_ab()
    norm, unif = creer_tableaux()
    visu_tableaux(norm, unif, "norm", "unif")
    
