#include "exo1.h"

#include <stdio.h>
#include <string.h>
#include <math.h>

void i_code(uint32_t nb, uint8_t *bits)
{
    // Bien réexpliquer le passage de paramètre par pointeur (vu en S12)
    for (size_t i = 0; i < 32; i++) // prférer le type size_t qui est recommandé pour les indices de tableau notamment
    {
        // Technique de masquage classique pour récupérer le bit à la position i :
        uint32_t bit_i = (1 << (31 - i)); // le bit à la position i est égal à 1 et les autres à 0
        bits[i] = (nb & bit_i) ? 1 : 0;   // nb & bit_i = 0 si le bit à la position i de nb est à 0 (et donc considéré comme le booléen false)
                                          // sinon nb & bit_i = bit_i qui est différent de 0 (et donc considéré comme le booléen true)
        /*
        on peut préférer :
        (nb & bit_i) == 0 ? 0 : 1;

        en tout cas, préférer la notation ternaire à un bloc if else
        */

        /*
        autre remarque :
        on a déjà affiché l'encodage d'un entier en M11
        mais en M11, on a calculé l'encodage,
        ici, on lit directement dans la mémoire de nb
        */
    }
}

void u_code(union floatint fi, uint8_t *bits)
{
    // expliquer le fonctionnement en mémoire d'une union
    // (fi.f et fi.i partagent le même emplacement en mémoire mais sont interprétés différemment)
    // pas encore vu dans les cours précédents
    i_code(fi.i, bits);
}

void f_code(float f, uint8_t *bits)
{
    // devrait permettre de comprendre ce qui a été dit précédemment
    union floatint fi;
    fi.f = f;
    u_code(fi, bits);
}

void get_info(uint8_t const *bits, uint8_t *code_sign, uint8_t *code_exp, uint8_t *code_mantisse)
{
    // on pourra les laisser faire des boucles pour la copie
    // mais il est intéressant de leur montrer une fonction plus bas niveau
    memcpy(code_sign, bits, SIZE_SIGN_CODE);
    memcpy(code_exp, bits + SIZE_SIGN_CODE, SIZE_EXP_CODE);
    memcpy(code_mantisse, bits + SIZE_SIGN_CODE + SIZE_EXP_CODE, SIZE_MANTISSE_CODE);
}

void get_info_2(uint8_t *bits, uint8_t *code_sign, uint8_t **code_exp, uint8_t **code_mantisse)
{
    *code_sign = bits[0];
    *code_exp = bits + SIZE_SIGN_CODE;
    *code_mantisse = bits + SIZE_SIGN_CODE + SIZE_EXP_CODE;
}

int exposant(uint8_t const *code)
{
    // coder ici
    int exp = 0;
    for (size_t i = 0; i < SIZE_EXP_CODE; i++)
    {
        exp = exp << 1; // ou exp *= 2;
        exp += code[i];
    }
    return exp - 127; // d'après la norme IEEE 754
}

float mantisse(uint8_t const *code)
{
    // coder ici
    float mant = 1; // rappeler que la mantisse est codée en notation
                    // positionnelle sans l'unité qui est toujours égale à 1
    float puissance_positionelle = 0.5;
    for (size_t i = 0; i < SIZE_MANTISSE_CODE; i++)
    {
        mant += code[i] * puissance_positionelle;
        puissance_positionelle /= 2;
        // C'est un choix se rapportant à la notation positionnelle qu'on pourra rappeler
    }
    return mant;
}

char *mantisse_b(uint8_t const *code, char *str)
{
    // coder ici
    memcpy(str, "(1.", 3); // on copie "(1." dans str sans le '\0' (c'est un choix)
                           // Rappeler qu'une chaîne de caractère est terminée par '\0'
                           // On pourrait utiliser strcpy(str, "(1."); ou strncpy
    for (size_t i = 0; i < SIZE_MANTISSE_CODE; i++)
    {
        str[i + 3] = code[i] + '0'; // on ajoute le caractère correspondant au bit i
                                    // Rappeler (M11) que '0'+0 = '0' et '0'+1 = '1'
    }
    strcpy(str + 3 + SIZE_MANTISSE_CODE, ")_2"); // pour changer

    // On pourra, si le temps le permet, discuter des avantages et inconvénients
    // de strncpy et strcpy
    return str;
}

float compute_float(uint8_t const *code_float)
{
    // coder ici
    uint8_t code_sign;
    uint8_t code_exp[SIZE_EXP_CODE];
    uint8_t code_mantisse[SIZE_MANTISSE_CODE];
    get_info(code_float, &code_sign, code_exp, code_mantisse);
    int exp = exposant(code_exp);
    float mant = mantisse(code_mantisse);
    float f = mant * pow(2, exp) * code_sign;
    return f;
}

void print_encoding(float f)
{
    // coder ici
    printf("Décomposition de %f :\n\n", f);
    union floatint fi;
    fi.f = f;
    uint8_t bits[32];
    u_code(fi, bits);
    uint8_t code_sign;
    uint8_t code_exp[SIZE_EXP_CODE];
    uint8_t code_mantisse[SIZE_MANTISSE_CODE];
    get_info(bits, &code_sign, code_exp, code_mantisse);
    /*
    2° possibilité, peut-être plus élégante :
    char *code_exp = NULL;  // ne pas oublier d'initialier un pointeur
    char *code_mantisse = NULL;
    get_info_2(bits, &code_sign, &code_exp, &code_mantisse);

    on pourrait aussi ajouter une fonction d'affichage
    pour ne pas dupliquer le code d'affichage
    */
    printf("Code signe : %d\n", code_sign);
    printf("Code exposant : ");
    for (size_t i = 0; i < SIZE_EXP_CODE; i++)
    {
        printf("%d", code_exp[i]);
    }
    printf("\n");
    printf("Code mantisse : ");
    for (size_t i = 0; i < SIZE_MANTISSE_CODE; i++)
    {
        printf("%d", code_mantisse[i]);
    }
    printf("\n\n");
    printf("Signe : %c\n", code_sign == 0 ? '+' : '-');
    printf("Exposant : %d\n", exposant(code_exp));
    char mantisse_str[30];
    printf("Mantisse : %s\n\n",
           mantisse_b(code_mantisse, mantisse_str));

    printf("Valeur : %f\n", compute_float(bits));
}