#ifndef __EXO2__

#define __EXO2__

typedef float (*function)(float); // typedef pour f : float -> float

float heron(float square, float init, unsigned int n);

float dichotomie(float a, float b, unsigned int n);

float dichotomie_p(function f, float a, float b, unsigned int n);

float Newton(float init, unsigned int n);

float Newton_p(function f, function f_prime, float init, unsigned int n);

float descente_de_gradient(float init, float alpha, unsigned int n);

float descente_de_gradient_p(function f, function f_prime, float init, float alpha, unsigned int n);

#endif