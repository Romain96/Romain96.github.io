#ifndef __EXO1__

#define __EXO1__

#define SIZE_SIGN_CODE 1
#define SIZE_EXP_CODE 8
#define SIZE_MANTISSE_CODE 23

#include <stdlib.h>
#include <stdint.h> // pour uint8_t, uint32_t, souvent dans stdint.h mais pas toujours
/*
uint8_t : entier non signé codé sur 8 bits
uint32_t : entier non signé codé sur 32 bits

uint8_t est un alias de unsigned char mais on explicite le fait de vouloir utiliser
un entier non signé codé sur 8 bits plutôt qu'un code ascii d'un caractère codé sur 8 bits

uint32_t est un alias de unsigned int généralement mas rien dans la norme ne garantit
que unsigned int soit codé sur 32 bits

Il n'y a pas d'équivalent pour les types flottants garantissant d'avoir un flottant
simple précision sur 32 bits. Généralement, on utilise float pour cela dns les architectures modernes.
*/

union floatint
{
    uint32_t i;
    float f;
};

void i_code(uint32_t nb, uint8_t *bits);

void u_code(union floatint fi, uint8_t *bits);

void f_code(float f, uint8_t *bits);

void get_info(uint8_t const *bits, uint8_t *code_sign, uint8_t *code_exp, uint8_t *code_mantisse);

void get_info_2(uint8_t *bits, uint8_t *code_sign, uint8_t **code_exp, uint8_t **code_mantisse);

int exposant(uint8_t const *code);

float mantisse(uint8_t const *code);

char *mantisse_b(uint8_t const *code, char *str);

float compute_float(uint8_t const *code_float);

void print_encoding(float f);

#endif