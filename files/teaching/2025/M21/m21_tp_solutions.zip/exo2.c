#include "exo2.h"
#include <stdio.h>

float heron(float a, float init, unsigned int n)
{
    float x = init;
    for (size_t i = 0; i < n; i++)
    {
        x = (x + a / x) / 2;
    }
    return x;
}

float f_dicho(float x) // autant définir la fonction utilisée
{
    return x * x - 3;
}

float dichotomie(float a, float b, unsigned int n)
{
    float m = (a + b) / 2;
    for (size_t i = 0; i < n; i++)
    {
        if (f_dicho(m) == 0)
        {
            return m;
        }
        if (f_dicho(m) * f_dicho(a) > 0)
        {
            a = m;
        }
        else
        {
            b = m;
        }
        m = (a + b) / 2;
    }
    return m;
}

float dichotomie_p(function f, float a, float b, unsigned int n)
{
    float m = (a + b) / 2;
    for (size_t i = 0; i < n; i++)
    {
        if (f(m) * f(a) > 0)
        {
            a = m;
        }
        else
        {
            b = m;
        }
        m = (a + b) / 2;
    }
    return m;
}

float function_Newton(float x)
{
    return x * x - 3;
}
float function_Newton_prime(float x)
{
    return 2 * x;
}

float Newton(float init, unsigned int n)
{
    float x = init;
    for (size_t i = 0; i < n; i++)
    {
        x = x - function_Newton(x) / function_Newton_prime(x);
    }

    return x;
}

float Newton_p(function f, function f_prime, float init, unsigned int n)
{
    float x = init;
    for (size_t i = 0; i < n; i++)
    {
        x = x - f(x) / f_prime(x);
    }

    return x;
}

float function_gradient(float x) // f(sqrt(2))=-sqrt(2) (minimum)
{
    return -(-3 * x * x * x * x * x / 16 + x * x * x / 2 + 3 * x / 4);
}

float function_gradient_prime(float x) // f'(sqrt(2))=0
{
    return -(-15 * x * x * x * x / 16 + 3 * x * x / 2 + 3. / 4.);
}

float descente_de_gradient(float init, float alpha, unsigned int n)
{
    float x = init;
    for (size_t i = 0; i < n; i++)
    {

        x = x - alpha * function_gradient_prime(x);
    }
    return function_gradient(x);
}

float descente_de_gradient_p(function f, function f_prime, float init, float alpha, unsigned int n)
{
    float x = init;
    for (size_t i = 0; i < n; i++)
    {
        x = x - alpha * f_prime(x);
    }
    return f(x);
}