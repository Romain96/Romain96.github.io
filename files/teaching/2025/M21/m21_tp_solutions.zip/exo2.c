#include "exo2.h"
#include <stdio.h>

float heron(float square, float init, unsigned int n)
{
    float return_value = init;	// alpha dans le cours
    for (size_t i = 0; i < n; i++)	// pour n de 0 à N - 1
    {
	    return_value = (return_value + square / return_value) / 2;	// x <- (x + a / x) / 2
    }
    return return_value;
}

float f_dicho(float x) // autant définir la fonction utilisée
{
    return x * x - 3;
}

float dichotomie(float a, float b, unsigned int n)
{
    float return_value = (a + b) / 2;
    for (size_t i = 0; i < n; i++)
    {
        if (f_dicho(return_value) == 0)
        {
            return return_value;
        }
        if (f_dicho(return_value) * f_dicho(a) > 0)
        {
            a = return_value;
        }
        else
        {
            b = return_value;
        }
        return_value = (a + b) / 2;
    }
    return return_value;
}

float dichotomie_p(function f, float a, float b, unsigned int n)
{
    float return_value = (a + b) / 2;
    for (size_t i = 0; i < n; i++)
    {
        if (f(return_value) * f(a) > 0)
        {
            a = return_value;
        }
        else
        {
            b = return_value;
        }
        return_value = (a + b) / 2;
    }
    return return_value;
}

float function_Newton(float x)
{
    return x * x * x * x * x - 3 * x + 1;
}
float function_Newton_prime(float x)
{
    return 5 * x * x * x * x - 3;
}

float Newton(float init, unsigned int n)
{
    float return_value = init;
    for (size_t i = 0; i < n; i++)
    {
        return_value = return_value - function_Newton(return_value) / function_Newton_prime(return_value);
    }

    return return_value;
}

float Newton_p(function f, function f_prime, float init, unsigned int n)
{
    float return_value = init;
    for (size_t i = 0; i < n; i++)
    {
        return_value = return_value - f(return_value) / f_prime(return_value);
    }

    return return_value;
}

float descente_de_gradient(float init, float alpha, unsigned int n)
{
    float x = init;
    for (size_t i = 0; i < n; i++)
    {

        x = x - alpha * function_Newton_prime(x);
    }
    return function_Newton(x);
}

float descente_de_gradient_p(function f, function f_prime, float init, float alpha, unsigned int n)
{
    float x = init;
    for (size_t i = 0; i < n; i++)
    {
        x = x - alpha * f_prime(x);
    }
    return f(x);
}
