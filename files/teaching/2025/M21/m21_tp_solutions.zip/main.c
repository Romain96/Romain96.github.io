#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "exo1.h"
#include "exo2.h"

#define TAB_SIZE 32

float f1(float x);
float f1_prime(float x);
float f2(float x);
float f2_prime(float x);
float f2_prime_prime(float x);

int main(int argc, char **argv)
{
    float f = -10023.099609;
    print_encoding(f);

    printf("\n\nCalculs de racine carée de 3 :\n");
    printf("Heron : %f\n", heron(3, 1, 10));
    printf("Dichotomie : %f\n", dichotomie(1, 2, 10));
    printf("Dichotomie_p : %f\n", dichotomie_p(f1, 1, 2, 10));
    printf("Newton_p : %f\n", Newton_p(f1, f1_prime, 1, 10));
    printf("Calculs de +/-racine(2) :\n");
    printf("Héron : %f\n", heron(2, 1, 10));
    printf("Dichotomie_p : %f\n", dichotomie_p(f2_prime, 1, 2, 10));
    printf("Newton_p : %f\n", Newton_p(f2_prime, f2_prime_prime, 1, 10));
    printf("Descente de gradient : %f\n", descente_de_gradient_p(f2, f2_prime, 1.8, 0.1, 10));
    exit(EXIT_SUCCESS);
}

float f1(float x)
{
    return x * x - 3;
}
float f1_prime(float x)
{
    return 2 * x;
}

float f2(float x) // f(sqrt(2))=-sqrt(2) (minimum)
{
    return -(-3 * x * x * x * x * x / 16 + x * x * x / 2 + 3 * x / 4);
}
float f2_prime(float x) // f'(sqrt(2))=0
{
    return -(-15 * x * x * x * x / 16 + 3 * x * x / 2 + 3. / 4.);
}
float f2_prime_prime(float x)
{
    return -(-15 * x * x * x / 4 + 3 * x);
}
