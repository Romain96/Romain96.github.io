#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <math.h>
#include "exo1.h"
#include "exo2.h"

#define TAB_SIZE 32

void print_int_tab(uint8_t *tab, size_t size); // pourquoi ne pas faire une fonction d'affichage de tableau d'entiers ?

float f1(float x);
float f1_prime(float x);
float f2(float x);
float f2_prime(float x);
float f2_prime_prime(float x);

int main(int argc, char **argv)
{
    // Exercice 1
    uint8_t bits[TAB_SIZE];
    float f = 11.00;
    f_code(f, bits);
    print_int_tab(bits, TAB_SIZE);
    print_encoding(f);

    // Exercice 2
    printf("\n\nCalculs de racine carée de 3 (math.sqrt(3) = %f) :\n", sqrt(3));
    printf("Héron : %f\n", heron(3, 10, 6));
    printf("Dichotomie : %f\n", dichotomie(1, 2, 21));
    printf("Dichotomie_p : %f\n", dichotomie_p(f1, 1, 2, 21));
    printf("Newton : %f\n", Newton(1, 4));
    printf("Newton_p : %f\n", Newton_p(f1, f1_prime, 10, 4));
    printf("\n\nCalculs de +/-racine(2) (math.sqrt(2) = %f):\n", sqrt(2));
    printf("Héron : %f\n", heron(2, 1, 10));
    printf("Dichotomie_p : %f\n", dichotomie_p(f2_prime, 1, 2, 10));
    printf("Newton_p : %f\n", Newton_p(f2_prime, f2_prime_prime, 1, 10));
    printf("Descente de gradient_p : %f\n", descente_de_gradient_p(f2, f2_prime, 1.8, 0.1, 10));
    exit(EXIT_SUCCESS);
}

void print_int_tab(uint8_t *tab, size_t size)
{
    for (size_t i = 0; i < size; i++)
    {
        if (i % 4 == 0 && i != 0)
        {
            printf(" ");
        }
        printf("%d", tab[i]);
    }
    printf("\n");
}

float f1(float x)
{
    return x * x - 3;
}
float f1_prime(float x)
{
    return 2 * x;
}

float f2(float x) // f(sqrt(2))=-sqrt(2) (minimum)
{
    return -(-3 * x * x * x * x * x / 16 + x * x * x / 2 + 3 * x / 4);
}
float f2_prime(float x) // f'(sqrt(2))=0
{
    return -(-15 * x * x * x * x / 16 + 3 * x * x / 2 + 3. / 4.);
}
float f2_prime_prime(float x)
{
    return -(-15 * x * x * x / 4 + 3 * x);
}