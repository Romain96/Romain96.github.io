package date;

import java.util.Objects;

/**
 * La classe Date permet de représenter une date composée d'un jour, d'un mois et d'une année.
 * @author Romain PERRIN
 */
public final class Date
{
    //-------------------------------------------------------------------------
    // Attributs
    //-------------------------------------------------------------------------

    private final int m_day;    // jour du mois
    private final Month m_month; // mois de l'année
    private final Year m_year;   // année

    //-------------------------------------------------------------------------
    // Constructeurs
    //-------------------------------------------------------------------------

    /**
     * Constructeur paramétré de la classe Date
     * @param day : jour du mois (doit entre 1 et Month.daysNumber(year))
     * @param month : mois de l'année (doit être un entier entre 1 et 12)
     * @param year : année (sans contrainte)
     */
    public Date(int day, int month, int year)
    {
        this.m_year = new Year(year);
        this.m_month = new Month(month);
        this.m_day = (day < 1 || day > this.m_month.daysNumber(this.m_year)) ? 1 : day;
    }

    //-------------------------------------------------------------------------
    // Getters & setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // Méthodes
    //-------------------------------------------------------------------------

    /** Permet de comparer deux dates
     * @param other : la date à comparer avec l'instance courante
     * @return true si les deux dates sont égales, false sinon
     */
    public boolean equals(Date other)
    {
        return this.m_day == other.m_day && this.m_month.equals(other.m_month) && this.m_year.equals(other.m_year);
    }

    /** Permet de savoir si une date est antérieure à une autre
     * @param other : la date à comparer avec l'instance courante
     * @return true si l'instance courante est antérieure à other, false sinon
     */
    public boolean isBefore(Date other)
    {
        return this.m_year.isBefore(other.m_year)
                || (this.m_year.equals(other.m_year) && this.m_month.isBefore(other.m_month))
                || (this.m_year.equals(other.m_year) && this.m_month.equals(other.m_month) && this.m_day < other.m_day);
    }

    /**
     * Surcharge de la méthode toString
     * @return une chaîne de caractères représentant la date au format "DD Month YYYY"
     */
    @Override
    public String toString()
    {
        return this.m_day + " " + this.m_month.getMonthAsText() + " " + this.m_year.toInt();
    }

    /**
     * Permet de comparer deux objets.
     * @param obj : un autre objet
     * @return true si les deux objets sont de la même classe et si les dates sont identiques, false sinon
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj == null || obj.getClass() != this.getClass())
        {
            return false;
        }
        Date date = (Date) obj; // downcast
        return this.m_day == date.m_day && this.m_month.equals(date.m_month) && this.m_year.equals(date.m_year);
    }

    /**
     * Permet d'obtenir un hash de la date.
     * @return un hash code de la date
     */
    @Override
    public int hashCode()
    {
        return Objects.hash(this.m_day, this.m_month.toInt(), this.m_year.toInt());
    }
}

