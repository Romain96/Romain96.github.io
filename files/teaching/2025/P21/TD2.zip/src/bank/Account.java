package bank;

import java.util.Objects;

/**
 * La classe Account permet de simuler un compte bancaire basique.
 * Il est possible de connaître le solde d'un compte ainsi que d'effectuer des virements entre comptes.
 * Il est impossible de modifier le solde autrement que par un virement.
 * @author Romain PERRIN
 */
public class Account
{
    //-------------------------------------------------------------------------
    // Attributs
    //-------------------------------------------------------------------------

    private double m_balance;	// solde du compte

    //-------------------------------------------------------------------------
    // Constructeurs
    //-------------------------------------------------------------------------

    /**
     * Constructeur paramétré du compte.
     * @param initialBalance : solde initial du compte
     */
    public Account(double initialBalance)
    {
        this.m_balance = initialBalance >= 0 ? initialBalance : 0;
    }

    /**
     * Constructeur par copie du compte.
     * @param other : un autre compte
     */
    public Account(Account other)
    {
        this.m_balance = (other != null) ? other.getBalance() : 0;  // seulement si other existe
    }

    //-------------------------------------------------------------------------
    // Getters & setters
    //-------------------------------------------------------------------------

    /**
     * Permet de consulter le solde du compte
     * @return le solde actuel du compte
     */
    public double getBalance()
    {
        return m_balance;
    }

    //-------------------------------------------------------------------------
    // Méthodes
    //-------------------------------------------------------------------------

    /**
     * Permet d'effectuer un virement depuis le compte actuel vers le compte indiqué
     * @param amount : montant du virement (doit être strictement positif)
     * @param recipient : compte du destinataire (doit être non null)
     * @return retourne vrai si le virement a eu lieu, faux sinon
     */
    public boolean transfer(double amount, Account recipient)
    {
        // seulement si le montant est strictement positif, le destinataire n'est pas null est le solde excède le montant du virement
        if (amount > 0 && amount <= this.m_balance && recipient != null)
        {
            this.m_balance -= amount;
            recipient.m_balance += amount;
            return true;
        }
        return false;
    }

    /**
     * Retourne le montant du solde sous forme de chaîne de caractères
     * @return "Account(balance: _balance_)"
     */
    @Override
    public String toString()
    {
        return "Account(_balance: " + this.getBalance() + "€_)";
    }

    /**
     * Permet de comparer deux Account.
     * @param obj : un autre compte
     * @return true si les deux objets sont de la classe Account et que leurs soldes sont identiques, false sinon
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj == null || obj.getClass() != this.getClass())
        {
            return false;
        }
        Account objAsAccount = (Account) obj;   // obj est non null et de la classe Account (downcast)
        return this.getBalance() == objAsAccount.getBalance();
    }

    /**
     * Retourne une valeur hachée pour le compte.
     * @return un entier (hash code)
     */
    @Override
    public int hashCode()
    {
        return Objects.hash(this.m_balance);
    }
}

