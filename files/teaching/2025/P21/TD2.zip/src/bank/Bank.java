package bank;

import java.util.ArrayList;
import java.util.Optional;

/**
 * La classe Bank permet de manipuler des comptes (Account).
 * @author Romain PERRIN
 */
public class Bank
{
    //-------------------------------------------------------------------------
    // Attributs
    //-------------------------------------------------------------------------

    private ArrayList<Account> m_accounts;  // liste des comptes de la banque

    //-------------------------------------------------------------------------
    // Constructeurs
    //-------------------------------------------------------------------------

    /**
     * Constructeur vide de la banque
     */
    public Bank()
    {
        this.m_accounts = new ArrayList<Account>();
    }

    /**
     * Constructeur par copie de la banque (copie profonde des comptes)
     * @param other : un autre banque
     */
    public Bank(Bank other)
    {
        this.m_accounts = new ArrayList<Account>(other.m_accounts.size());
        // parcours des comptes de l'autre banque et copie profonde (foreach)
        for (Account acc : other.m_accounts)
        {
            this.m_accounts.add(new Account(acc));  // utilisation du constructeur par copie de Account
        }
    }

    //-------------------------------------------------------------------------
    // Getters & setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // Méthodes
    //-------------------------------------------------------------------------

    /**
     * Permet de créer un compte dans la banque étant donné un solde initial
     * @param initialBalance : solde initial du nouveau compte (doit être >= 0)
     * @return le numéro du nouveau compte
     */
    public int addAccount(float initialBalance)
    {
        int accountNumber = m_accounts.size();
        m_accounts.add(new Account(initialBalance));    // la vérification de initialBalance a lieu dans le constructeur de Account
        return accountNumber;
    }

    /**
     * Permet de vérifier si un compte existe dans la banque étant donné son numéro de compte.
     * @param accountNumber : le numéro du compte à rechercher
     * @return true si le compte existe dans la banque, false sinon
     */
    public boolean hasAccount(int accountNumber)
    {
        return accountNumber >= 0 && accountNumber < m_accounts.size();
    }

    /**
     * Permet d'obtenir le solde courant d'un compte étant donné son numéro de compte.
     * @param accountNumber : le numéro du compte à rechercher
     * @return le solde du compte si celui-ci existe, vide sinon
     */
    public Optional<Double> getBalance(int accountNumber)
    {
        if (this.hasAccount(accountNumber))
        {
            return Optional.of(this.m_accounts.get(accountNumber).getBalance());
        }
        return Optional.empty();
    }

    /**
     * Permet le transfert d'argent entre deux comptes.
     * @param amount : montant du transfert
     * @param debtorNumber : numéro de compte du débiteur (dans ma banque courante)
     * @param recipientNumber : numéro de compte du créditeur
     * @param recipientBank : banque du créditeur
     * @return true si le transfert a eu lieu, false sinon
     */
    public boolean transfer(double amount, int debtorNumber, int recipientNumber, Bank recipientBank)
    {
        if (this.hasAccount(debtorNumber) && recipientBank != null && recipientBank.hasAccount(recipientNumber))
        {
            Account debtor = this.m_accounts.get(debtorNumber);
            Account recipient = recipientBank.m_accounts.get(recipientNumber);
            return debtor.transfer(amount, recipient);
        }
        return false;
    }

    /**
     * Permet de simuler un virement sans modifier les comptes concernés.
     * @param amount : montant du virement (doit être > 0)
     * @param debtorNumber : numéro de compte du débiteur
     * @param recipientNumber : numéro de compte du créditeur
     * @param recipientBank : banque du créditeur (doit être != null)
     * @return true si le virement a eu lieu, false sinon
     */
    public boolean simulateTransfer(double amount, int debtorNumber, int recipientNumber, Bank recipientBank)
    {
        // copie des deux banques pour la simulation
        Bank debtorBankCopy = new Bank(this);
        Bank recipientBankCopy = new Bank(recipientBank);

        // transfert sur les copies des comptes des copies des banques
        if (debtorBankCopy.hasAccount(debtorNumber) && recipientBankCopy.hasAccount(recipientNumber))
        {
            Account debtor = debtorBankCopy.m_accounts.get(debtorNumber);
            Account recipient = recipientBankCopy.m_accounts.get(recipientNumber);
            return debtor.transfer(amount, recipient);
        }
        return false;
    }

    /**
     * Surcharge de la méthode toString
     * @return "Bank(_accounts_)"
     */
    @Override
    public String toString()
    {
        StringBuilder str = new StringBuilder("Bank(_accounts_ : ");
        for (Account acc : m_accounts)
        {
            str.append(acc);
            str.append(" ");
        }
        str.append(")");
        return str.toString();
    }
}
