import geometry.Point;

import java.util.ArrayList;

/**
 * Classe Stupid...
 * @author Étienne LE QUENTREC
 * @author Romain PERRIN
 */
public class Stupid
{
    //------------------------------------------------------------------------
    // ATTRIBUTS
    //------------------------------------------------------------------------

    private int m_integer;
    private ArrayList<Point> m_points;

    //------------------------------------------------------------------------
    // CONSTRUCTEURS
    //------------------------------------------------------------------------

    /**
     * Constructeur paramétré.
     * @param integer : un entier
     */
    public Stupid(int integer)
    {
        this.m_integer = integer;
        this.m_points = new ArrayList<Point>();
    }

    /**
     * Constructeur par copie.
     * @param other : un autre Stupid
     */
    public Stupid(Stupid other)
    {
        this.m_integer = other.m_integer;
        this.m_points = new ArrayList<Point>(other.m_points);
    }

    //------------------------------------------------------------------------
    // GETTERS & SETTERS
    //------------------------------------------------------------------------

    /**
     * Permet de modifier l'entier.
     * @param newInteger : un entier
     */
    public void setInteger(int newInteger)
    {
        this.m_integer = newInteger;
    }

    //------------------------------------------------------------------------
    // MÉTHODES
    //------------------------------------------------------------------------

    /**
     * Permet d'ajouter un point à la liste des points.
     * @param element : un point
     */
    public void addPoint(Point element)
    {
        m_points.add(element);
    }

    /**
     * Permet de remplacer le ième point.
     * @param position : l'indice du point à remplacer
     * @param newPoint : le nouveau point
     */
    public void changePoint(int position, Point newPoint)
    {
        this.m_points.set(position, newPoint);
    }

    /**
     * Permet de décaler le ième point étant donné un vecteur de translation.
     * @param position : l'indice du point à translater
     * @param vector : le vecteur de translation
     */
    public void movePoint(int position, Point vector)
    {
        Point toMove = this.m_points.get(position);
        toMove.move(vector);
    }


    /**
     * Surcharge de la méthode toString, retourne une chaîne de caractères contenant "Stupid(_integer_, _years_)".
     * @return une chaîne de caractères
     */
    @Override
    public String toString()
    {
        return "Stupid(_integer_:" + m_integer + ", _years_:" + m_points.toString() + ")";
    }
}