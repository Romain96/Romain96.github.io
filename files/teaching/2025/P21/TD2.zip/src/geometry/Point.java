package geometry;

/**
 * La classe Point permet de représenter un point en 2D contenant ses coordonnees (x, y).
 * @author Étienne LE QUENTREC
 * @author Romain PERRIN
 */
public class Point
{
    //------------------------------------------------------------------------
    // ATTRIBUTS
    //------------------------------------------------------------------------

    private double m_x; // abscisse
    private double m_y; // ordonnée

    //------------------------------------------------------------------------
    // CONSTRUCTEURS
    //------------------------------------------------------------------------

    /**
     * Constructeur vide, initialise un point à l'origine (0, 0)
     */
    public Point()
    {
        this.m_x = 0.0;
        this.m_y = 0.0;
    }

    /**
     * Constructeur paramétré, initialise un point aux coordonnées spécifiées.
     * @param x abscisse du point
     * @param y ordonnée du point
     */
    public Point(double x, double y)
    {
        this.m_x = x;
        this.m_y = y;
    }

    //------------------------------------------------------------------------
    // GETTERS & SETTERS
    //------------------------------------------------------------------------

    /**
     * Permet d'obtenir la coordonnée en abscisse du point.
     * @return la coordonnee X du point
     */
    public double getX()
    {
        return this.m_x;
    }

    /**
     * Permet d'obtenir la coordonnée en ordonnée du point.
     * @return la coordonne Y du point
     */
    public double getY()
    {
        return this.m_y;
    }

    //------------------------------------------------------------------------
    // MÉTHODES
    //------------------------------------------------------------------------

    /**
     * Calcule la distance du point avec un autre point.
     * @param other : un autre Point
     * @return la distance euclidienne entre le point courant et le point other
     */
    public double distance(Point other)
    {
        return Math.sqrt( (m_x - other.m_x) * (m_x - other.m_x) + (m_y - other.m_y) * (m_y - other.m_y) );
    }

    /**
     * Surcharge de la méthode to>String, crée une chaîne de caractères affichant les coordonnées du point.
     * @return "Point(_x_,_y_)" avec x et y sont l'abscisse et l'ordonnée respectives du point.
     */
    @Override
    public String toString()
    {
        return "Point(_" + m_x + "_,_" + m_y + "_)";
    }

    /**
     * Decale le point étant donné un vecteur de translation.
     * @param vector : vector de translation
     */
    public void move(Point vector)
    {
        this.m_x += vector.getX();
        this.m_y += vector.getX();
    }
}

