import geometry.Point;
import bank.*;
import date.*;

/**
 * Classe principale.
 * @author Étienne LE QUENTREC
 * @author Romain PERRIN
 */
public class Main
{
    /**
     * Point d'entrée du programme.
     * @param args : arguments en ligne de commande (ignorés)
     */
    public static void main(String[] args)
    {
        // Exercice 1
        Stupid s1 = new Stupid(1);
        s1.addPoint(new Point(1, 1));
        s1.addPoint(new Point(2, 2));
        s1.addPoint(new Point(3, 3));
        Stupid s2 = s1;
        Stupid s3 = new Stupid(s1);
        s1.addPoint(new Point(4, 4));
        s1.changePoint(0, new Point(-1, -1));
        s1.setInteger(2);
        s1.movePoint(1, new Point(0.5, 0.5));
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);

        // Exercice 3
        Bank b1 = new Bank();
        Bank b2 = new Bank();
        int alice = b1.addAccount(100);
        int bob = b1.addAccount(80);
        int charles = b2.addAccount(120);

        System.out.println("Banque b1");
        System.out.println(b1);
        System.out.println("Banque b2");
        System.out.println(b2);

        System.out.println("Simulation du virement de 50€ de Alice à Charles");
        boolean v0 = b1.simulateTransfer(50, alice, charles, b2);
        System.out.println(v0);

        System.out.println("Banque b1");
        System.out.println(b1);
        System.out.println("Banque b2");
        System.out.println(b2);

        System.out.println("Virement de 50€ de Alice à Charles");
        boolean v1 = b1.transfer(50, alice, charles, b2);
        System.out.println("Banque b1");
        System.out.println(b1);
        System.out.println("Banque b2");
        System.out.println(b2);
        System.out.println(v1);

        // Exercice 4
        Date aujourdhui = new Date(9, 2, 2026);  // 9 février 2026
        System.out.println("\nDate d'aujourd'hui : " + aujourdhui);

        Date demain = new Date(10, 2, 2026);	// 10 février 2026
        System.out.println("Date de demain : " + demain);

        System.out.println("aujourdhui.equals(demain) : " + aujourdhui.equals(demain));
        System.out.println("demain.equals(aujourdhui) : " + demain.equals(aujourdhui));
        System.out.println("aujourdhui.equals(aujourdhui) : " + aujourdhui.equals(aujourdhui));
        System.out.println("aujourdhui.isBefore(demain) : " + aujourdhui.isBefore(demain));
        System.out.println("aujourdhui.isBefore(aujourdhui) : " + aujourdhui.isBefore(aujourdhui));
        System.out.println("demain.isBefore(aujourdhui) : " + demain.isBefore(aujourdhui));

        Date dateInvalide = new Date(32, 13, -2026);	 // date invalide
        System.out.println("Date invalide : " + dateInvalide);
    }
}