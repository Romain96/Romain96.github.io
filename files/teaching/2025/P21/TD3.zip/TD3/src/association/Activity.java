package association;

import java.util.ArrayList;

/**
 * This class represents an activity proposed by an association. Members can take part in the activity by registering.
 * @author Romain PERRIN
 */
public class Activity
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private ArrayList<Member> m_registered;
    private int m_minAge;
    private String m_name ;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrizes constructor, instanciates a new Activity without any registered members.
     * @param name : activity name
     * @param minAge : minimum age required for a member to register to the activity
     */
    public Activity (String name, int minAge)
    {
        m_name = name;
        m_minAge = minAge;
        m_registered = new ArrayList<>();
    }

    /**
     * Registers a member to this activity.
     * @param member : reference to the member to register
     * @return true if the member has been registered, false otherwise
     */
    public boolean register (Member member)
    {
        if (member.getAge() < m_minAge)
        {
            return false;
        }
        m_registered.add(member);
        return true;
    }

    /**
     * Returns a human-readable string representing the Activity.
     * @return "m_name : n registered member(s)" with n the number of registered members
     */
    @Override
    public String toString()
    {
        return m_name + " : " + m_registered.size() + " registered member(s)";
    }

    /**
     * Checks if a member is registered for the current activity.
     * @param member : reference to a Member
     * @return true if the member is registered, false otherwise
     */
    public boolean isRegistered (Member member)
    {
        return m_registered.contains(member);
    }
}
