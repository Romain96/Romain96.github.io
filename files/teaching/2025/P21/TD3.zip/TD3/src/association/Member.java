package association;

/**
 * This class represents a member of an association with minimal information.
 * @author Romain PERRIN
 */
public class Member
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private int m_age;
    private String m_firstName;
    private String m_lastName;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instanciates a new Member.
     * @param age : member's age in years (not updated automatically)
     * @param firstName : member's first name
     * @param lastName : member's last name
     */
    public Member (int age, String firstName, String lastName)
    {
        if (age > 0)
        {
            m_age = age;
            m_firstName = firstName;
            m_lastName = lastName;
        }
    }

    //--------------------------------------------------------------------------
    // GETTERS & SETTERS
    //--------------------------------------------------------------------------

    /**
     * Getter for the age attribute.
     * @return the member's current age
     */
    public int getAge ()
    {
        return m_age;
    }

    /**
     * Getter for the first name attribute.
     * @return the member's current first name
     */
    public String getFirstName ()
    {
        return m_firstName;
    }

    /**
     * Getter for the last name attribute.
     * @return the member's current last name
     */
    public String getLastName ()
    {
        return m_lastName;
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Returns a human-readable string representing the Member.
     * @return "m_firstName, m_lastName aged of m_age"
     */
    @Override
    public String toString()
    {
        return  m_firstName + ", " + m_lastName + " aged of " + m_age;
    }
}
