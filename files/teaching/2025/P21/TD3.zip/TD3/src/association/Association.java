package association;

import java.util.ArrayList;

/**
 * This class represents an association. The association can propose various activities and has a list of registered members.
 * @author Romain PERRIN
 */
public class Association
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private ArrayList<Member> m_members;
    private ArrayList<Activity> m_activities;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Default constructor, instanciates a new Association without member or activity.
     */
    public Association()
    {
        m_activities = new ArrayList<>();
        m_members = new ArrayList<>();
    }

    //--------------------------------------------------------------------------
    // GETTERS & SETTERS
    //--------------------------------------------------------------------------

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Adds an activity to the association.
     * @param name : name of the activity
     * @param minAge : minimum age required to take part in this activity
     * @return the activity's code
     */
    public int createActivity (String name, int minAge)
    {
        m_activities.add(new Activity(name, minAge));
        return m_activities.size() - 1;
    }

    /**
     * Registers a new member to the association.
     * @param firstName : member's first name
     * @param lastName : member's last name
     * @param age : member's age in years
     * @return the member's ID
     */
    public int registerMember (String firstName, String lastName, int age)
    {
        m_members.add(new Member(age, firstName, lastName));
        return m_members.size() - 1;
    }

    /**
     * Registers a member of the association to a specific activity proposed by said association.
     * @param activityNum : activity's ID
     * @param memberNum : member's ID
     * @return true if the member has been registered to the activity, false otherwise
     */
    public boolean registerMemberToActivity (int activityNum, int memberNum)
    {
        if (activityNum >= 0 && activityNum < m_activities.size() && memberNum >= 0 && memberNum < m_members.size())
        {
            return m_activities.get(activityNum).register(m_members.get(memberNum));
        }
        return false;
    }

    /**
     * Returns a human-readable string representing the association.
     * @return a string containing the activities and registered members of the association
     */
    @Override
    public String toString()
    {
        return "Activities : " + m_activities.toString() + " registered members : " + m_members.size();
    }

}
