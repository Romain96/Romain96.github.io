package bank;

import java.util.ArrayList;
import java.util.Optional;

/**
 * This class represents a customer in a bank.
 * @author Romain PERRIN
 */
public class BankCustomer
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private String m_firstName;
    private String m_lastName;
    private ArrayList<Account> m_accounts;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instanciates a new BankCustomer without any account.
     * @param firstName : the customer's first name
     * @param lastName : the customer's last name (family name)
     */
    public BankCustomer (String firstName, String lastName)
    {
        m_firstName = firstName;
        m_lastName = lastName;
        m_accounts = new ArrayList<Account>();
    }

    //--------------------------------------------------------------------------
    // GETTERS & SETTERS
    //--------------------------------------------------------------------------

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Creates a new account for the current customer.
     * @param initialBalance : the account's initial balance, must be positive
     * @return the account ID used to access the new account
     * @see Account
     */
    public int createAccount (double initialBalance)
    {
        m_accounts.add(new Account(initialBalance));
        return m_accounts.size() - 1;
    }

    /**
     * Checks whether the customer has a given account.
     * @param number : account number
     * @return true if the customer has the account indicated by number, false otherwise
     */
    public boolean hasAccount (int number)
    {
        return number >= 0 && number < m_accounts.size();
    }

    /**
     * Transfers a certain amount of money from the given account of the current customer to a given account of a target customer.
     * @param amount : amount to transfer, must be strictly positive
     * @param sourceNumber : current customer's source account ID
     * @param target : a reference to the recipient customer
     * @param targetNumber : the ID of the recipient customer's account
     * @return true if the transfer took place, false otherwise
     */
    public boolean transfer (double amount, int sourceNumber, BankCustomer target, int targetNumber)
    {
        if (hasAccount(sourceNumber) && target != null && target.hasAccount(targetNumber))
        {
            return m_accounts.get(sourceNumber).transfer(amount, target.m_accounts.get(targetNumber));
        }
        return false;
    }

    /**
     * Returns a human-readable string representing the account.
     * @param number : the account ID
     * @return a String representing the account or an empty string if the account does not exist
     */
    public String getAccountInfo (int number)
    {
        if (hasAccount(number))
        {
            return m_accounts.get(number).toString();
        }
        return "";
    }

    /**
     * Returns the current balance of a given account.
     * @param number : the account ID
     * @return an Optional containing the current balance if the account exists, empty otherwise
     */
    public Optional<Double> getAccountBalance (int number)
    {
        if (hasAccount(number))
        {
            return Optional.of(m_accounts.get(number).getBalance());
        }
        return Optional.empty();
    }

    /**
     * Returns a human-readable string representing the customer.
     * @return "m_firstName m_lastName has n account(s)" with n the number of accounts
     */
    public String toString()
    {
        return m_firstName + " " + m_lastName+ " has " + m_accounts.size() + " account(s)";
    }
}
