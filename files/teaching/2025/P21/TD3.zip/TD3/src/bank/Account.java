package bank;

/**
 * This class represents a basic bank account with the impossibility to have a negative balance.
 * @author Romain PERRIN
 */
public class Account
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private double m_balance;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instanciates a new Account with the given initial balance.
     * @param initialBalance : initial balance, cannot ne negative
     */
    public Account (double initialBalance)
    {
        m_balance = initialBalance >= 0 ? initialBalance : 0;
    }

    /**
     * Default constructor, instanciates a new Account with an initial balance of 0.
     */
    public Account ()
    {
        m_balance = 0;
    }

    //--------------------------------------------------------------------------
    // GETTERS & SETTERS
    //--------------------------------------------------------------------------

    /**
     * Getter for the account balance.
     * @return the Account's current balance
     */
    public double getBalance ()
    {
        return m_balance;
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Processes a transfer between two Accounts.
     * If the recipient does not exist or the amount is invalid, the transfer does not take place.
     * @param amount : transfer amount, must be strictly positive
     * @param recipient: recipient Account reference, must not be null
     * @return true if the transfer took place, false otherwise
     */
    public boolean transfer (double amount, Account recipient)
    {
        if( amount > 0 && amount <= m_balance && recipient != null)
        {
            m_balance -= amount;
            recipient.m_balance += amount;
            return true;
        }
        return false;
    }

    /**
     * Returns a human-readable string representng the Account.
     *@return "Account(balance: _balance_)"
     */
    @Override
    public String toString()
    {
        return "Account(balance:" + m_balance + ")";
    }
}
