package tasks;

import java.util.concurrent.TimeUnit;

/**
 * This class represents a named task necessitating a certain amount of time to be completed.
 * @author Romain PERRIN
 */
public class Task
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private String m_description;
    private int m_duration;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instanciates a new Task.
     * @param description : description of the task
     * @param duration : amount of time needed to complete the task in seconds
     */
    public Task (String description, int duration)
    {
        m_description = description;
        m_duration = duration;
    }

    //--------------------------------------------------------------------------
    // GETTERS & SETTERS
    //--------------------------------------------------------------------------

    /**
     * Getter for the description attribute.
     * @return the current description
     */
    public String getDescription()
    {
        return m_description;
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Processes the task for the required amount of time needed to complete it.
     */
    public void doIt()
    {
        try
        {
            TimeUnit.SECONDS.sleep(m_duration);
        }
        catch(Exception e)
        {
            // we dit not wait for the required time in order to complete the task...
        }
    }

    /**
     * Returns a human-readable string representing the task.
     * @return "Task (m_description)"
     */
    @Override
    public String toString()
    {
        return "Task (" + m_description + ")";
    }
}

