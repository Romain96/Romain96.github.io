package tasks;

import javax.management.remote.rmi.RMIConnectionImpl_Stub;
import java.util.Hashtable;

/**
 * This class represents a list of tasks.
 * @author Romain PERRIN
 * @see Task
 */
public class TasksList
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private Hashtable<String, Task> m_tasks;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Default constructor, instanciates a new TasksList without any task.
     */
    public TasksList()
    {
        m_tasks = new Hashtable<String, Task>();
    }

    //--------------------------------------------------------------------------
    // GETTERS & SETTERS
    //--------------------------------------------------------------------------

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Adds a task to the list of tasks.
     * @param key : the task name or description
     * @param task : a reference to the task
     * @see Task
     */
    public void add (String key, Task task)
    {
        if (!m_tasks.containsKey(key))
        {
            m_tasks.put(key, task);
        }
    }

    /**
     * Processes a given task.
     * @param key : the task name or description
     * @return the processed task's description
     */
    public String doTask (String key)
    {
        Task toDo = m_tasks.get(key);
        if (toDo != null)
        {
            m_tasks.remove(key);
            toDo.doIt();
            return toDo.getDescription();
        }
       return "There is no " + key + " task to do";
    }

    /**
     * Returns a human-readable string representing the TasksList.
     * @return a string representing the list of tasks
     */
    @Override
    public String toString()
    {
        return m_tasks.toString();
    }
}

