import association.*;
import tasks.Task;
import tasks.TasksList;

public class Main
{
    public static void main(String[] args)
    {
        // ex 1 : debug
        // ex 2 : bank
        // ex 3 : association
        int exercice = 1;

        switch(exercice)
        {
            case 1:
                TasksList tasks = new TasksList();
                tasks.add("P21", new Task("Apprendre les questions de cours", 1));
                tasks.add("A21", new Task("Réaliser interface", 1));
                tasks.add("S21", new Task("Recoder le protocol TCP à partir de l'UDP", 1));
                tasks.add("P21", new Task("Finir le diagramme UML", 1));
                tasks.add("perso", new Task("Faire les courses", 1));
                System.out.println(tasks.doTask("A21"));
                System.out.println(tasks.doTask("P21"));
                System.out.println(tasks.doTask("S21"));
                System.out.println(tasks.doTask("P21"));
                System.out.println(tasks.doTask("perso"));
                break;
            case 2:
                bank.BankCustomer pierre = new bank.BankCustomer("Pierre", "Dupont");
                bank.BankCustomer paul= new bank.BankCustomer("Paul", "Martin");
                int accountNumberPierre = pierre.createAccount(100);
                int accountNumberPaul = paul.createAccount(50);
                pierre.transfer(20,accountNumberPierre, paul, accountNumberPaul);
                System.out.println("Compte de Pierre:");
                //System.out.println(pierre.getAccount(accountNumberPierre));
                System.out.println(pierre.getAccountInfo(accountNumberPierre));
                System.out.println("Compte de Paul:");
                //System.out.println(paul.getAccount(accountNumberPaul));
                System.out.println(paul.getAccountInfo(accountNumberPaul));
                System.out.println("Solde de Pierre : ");
                System.out.println(pierre.getAccountBalance(accountNumberPierre));
                System.out.println("Solde de Paul : ");
                System.out.println(paul.getAccountBalance(accountNumberPaul));
                break;
            case 3:
                Association ascpa = new Association();
                ascpa.createActivity("Kayak", 14);
                int numEscalade = ascpa.createActivity("Escalade", 16);
                ascpa.createActivity("Yoga", 18);

                int numEtienne = ascpa.registerMember("Etienne", "Le Quentrec", 30);
                int numBasile = ascpa.registerMember("Basile", "Sauvage", 40);
                System.out.println(ascpa.registerMemberToActivity(numEscalade, numEtienne));
                System.out.println(ascpa);
                break;
            default:
                System.out.println("Le numéro d'exercice n'existe pas");
                break;
        }


    }
}
