package sort;

import java.util.ArrayList;

/**
 * This class provides a generic sort method implementing the Comparable interface.
 * @author Romain PERRIN
 */
public class Sort
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Sorts an arraylist in the increasing order using a bubble sort.
     * @param array : array to sort
     * @return the sorted input array
     * @param <T> type of the array elements
     */
    public static <T extends Comparable<T>> ArrayList<T> sort (ArrayList<? extends T> array)
    {
        ArrayList<T> result = new ArrayList<>(array);
        for (int i = result.size() - 1; i > 0; i--)
        {
            for (int j = 0; j < i; j++)
            {
                if (result.get(j).compareTo(result.get(j + 1)) > 0)
                {
                    T save = result.get(j + 1);
                    result.set(j + 1, result.get(j));
                    result.set(j, save);
                }
            }
        }
        return result;
    }
}
