package optional;

import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * This class represents a custom implementation of a generic Optional.
 * @param <T> generic object
 * @author Romain PERRIN
 */
public class Optional<T>
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private T m_value;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a new null-valued Optional.
     */
    private Optional ()
    {
        this.m_value = null;
    }

    /**
     * Parametrized constructor, instantiates a new valued optional.
     * @param value: value of type T
     */
    private Optional (T value)
    {
        this.m_value = value;
    }

    /**
     * Factory method to instantiates a new empty Optional of type T.
     * @return an empty Optional of type T
     * @param <T> : requested type
     */
    public static <T> Optional<T> empty ()
    {
        return new Optional<T>();
    }

    /**
     * Factory method to instantiates a new valued Optional of type T.
     * @param value : the value to assign to the Optional
     * @return a new valued Optional of type T
     * @param <T> : requested type
     */
    public static <T> Optional<T> of (T value)
    {
        return new Optional<T>(value);
    }

    /**
     * Factory method to instantiates a new nullable valued Optional of type T.
     * @param value : nullable value
     * @return a new nullable valued Optional of type T
     * @param <T> : requested type
     */
    public static <T> Optional<T> ofNullable (T value)
    {
        if (value == null)
        {
            return new Optional<T>();
        }
        return new Optional<T>(value);
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Getter for the value attribute.
     * @return the currently-stored value if not null
     * @throws NoSuchElementException : if value is null
     */
    public T get () throws NoSuchElementException
    {
        if (this.m_value == null)
        {
            throw new NoSuchElementException();
        }
        return this.m_value;
    }

    /**
     * Returns the current value if present, the other one otherwise.
     * @param other : another T object
     * @return the value of this if present, other otherwise
     */
    public T orElse (T other)
    {
        if (this.isPresent())
        {
            return this.m_value;
        }
        return other;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Checks whether a non-null value is stored.
     * @return True if a non-null value is stored, false otherwise
     */
    public boolean isPresent ()
    {
        return this.m_value != null;
    }

    /**
     * Returns a human-readable string representing the Optional.
     * @return Optional(of _value_) or Optional(empty)
     */
    @Override
    public String toString()
    {
        if (this.isPresent())
        {
            return "Optional(of " + this.m_value + ")";
        }
        return "Optional(empty)";
    }

    /**
     * Compares the current object reference to another reference.
     * @param other : another object
     * @return true if both objects are of the same type and of equal values, false otherwise
     */
    @Override
    public boolean equals (Object other)
    {
        if (other.getClass() != this.getClass())
        {
            return false;
        }
        Optional<T> conv = (Optional<T>) other; // downcast
        return this.m_value == conv.m_value;
    }

    /**
     * Returns a hash code representing the instance.
     * @return a hash
     */
    @Override
    public int hashCode()
    {
        return Objects.hash(this.m_value);
    }

    /**
     * Tests a condition based on the Optional value.
     * @param predicate : the condition to test
     * @return this if the condition is valid, empty otherwise
     */
    public Optional<T> filter (Predicate<T> predicate)
    {
        if (this.isPresent() && predicate.test(this.m_value))
        {
            return this;
        }
        return new Optional<>();
    }

    /**
     * Transforms the Optional value into a value of type U.
     * @param mapper function from T -> U
     * @return An optional either empty or containing the mapped value
     * @param <U> return type of the map
     */
    public <U> Optional<U> flatMap (Function<T, Optional<U>> mapper)
    {
        if (this.isPresent())
        {
            return mapper.apply(this.m_value);
        }
        return new Optional<U>();
    }

    /**
     * Performs an action is the Optional contains a value.
     * @param consumer : action to perform
     */
    public void ifPresent (Consumer<T> consumer)
    {
        if (this.isPresent())
        {
            consumer.accept(this.m_value);
        }
    }
}
