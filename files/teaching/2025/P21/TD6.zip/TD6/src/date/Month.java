package date;

/**
 * This class represents a month.
 * @author Romain PERRIN
 */
public class Month implements Comparable<Month>
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private final int m_month;
    private static final String[] m_MONTH_NAMES = {"Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"};

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Month.
     * @param month : month number
     * @throws IllegalArgumentException : if the month is not in the [1,12] range
     */
    public Month (int month) throws IllegalArgumentException
    {
        if (month >= 1 && month <= 12)
        {
            m_month = month;
        }
        else
        {
            throw new IllegalArgumentException("Month should be between 1 and 12 !");
        }
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns a human-readable string representing the Month.
     * @return a string representing the month
     */
    @Override
    public String toString()
    {
        return Month.m_MONTH_NAMES[this.m_month - 1];
    }

    /**
     * Converts the month to an integer.
     * @return the month as an integer
     */
    public int toInt ()
    {
        return m_month;
    }

    /**
     * Returns the number of days in the current month depending on the current year.
     * @param year : current year
     * @return the number of days in the month
     * @see Year
     */
    public int daysNumber (Year year)
    {
        if (m_month == 4 || m_month == 6 || m_month == 9 || m_month == 11)
        {
            return 30;
        }
        else if (m_month == 2)
        {
            return year.isLeapYear() ? 29 : 28;
        }
        return 31;
    }

    /**
     * Compares the current reference with another reference of Month and checks whether the current one is strictly before the other.
     * @param other : another reference of Month
     * @return true if this is strictly inferior to other, false otherwise
     */
    public boolean isBefore (Month other)
    {
        return this.m_month < other.m_month;
    }

    /**
     * Compares the current reference with another reference of Month and checks whether they are equal.
     * @param other : another reference of Month
     * @return true if this == other, false otherwise
     */
    public boolean equals (Month other)
    {
        return this.m_month == other.m_month;
    }

    /**
     * Compares the current reference to another reference.
     * @param other : the reference object with which to compare.
     * @return true if both objects are Month and of equals values
     */
    @Override
    public boolean equals (Object other)
    {
        if (other == null || other.getClass() != this.getClass())
        {
            return false;
        }
        Month m = (Month) other;    // downcast
        return this.m_month == m.m_month;
    }

    /**
     * Returns a hash code representing the current Month.
     * @return a hash
     */
    @Override
    public int hashCode ()
    {
        return m_month;
    }

    /**
     * Compares the current reference with another reference of Month.
     * @param other : another reference of Month
     * @return -1 if this is strictly inferior to other, 0 if this equals other and 1 if this is strictly superior to other
     * @throws NullPointerException : if other is null
     */
    @Override
    public int compareTo (Month other)
    {
        if (other == null)
        {
            throw new NullPointerException();
        }
        if (this.isBefore(other))
        {
            return -1;
        }
        else if (other.isBefore(this))
        {
            return 1;
        }
        return 0;   // this == other
    }
}