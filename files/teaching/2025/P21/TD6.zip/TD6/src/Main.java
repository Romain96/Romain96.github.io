import distance.Distance;
import date.*;
import optional.Optional;
import sort.Sort;

import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Main class.
 * @author Romain PERRIN
 */
public class Main
{
    /**
     * Runs a demo for the first exercise.
     */
    public static void Exercise1 ()
    {
        Distance d = Distance.createKilometerDistance(1.27);
        System.out.println("d : " + d);
        System.out.println("d en mm : " + d.getDistanceInMillimeter());
        System.out.println("d en m : " + d.getDistanceInMeter());
        System.out.println("d en km : " + d.getDistanceInKilometer());
        System.out.println("d en mile : " + d.getDistanceInMile());

        Distance d1 = Distance.createMillimeterDistance(15);
        Distance d2 = Distance.createKilometerDistance(2);
        Distance d3 = Distance.add(d1, d2);
        System.out.println("d1 : " + d1.getDistanceInMillimeter() + " mm");
        System.out.println("d2 : " + d2.getDistanceInKilometer() + " km");
        System.out.println("d3 = d1 + d2 : " + d3.getDistanceInKilometer() + " km");
        System.out.println("d3 = d1 + d2 : " + d3.getDistanceInMile() + " Mile");
        System.out.println("d3 = d1 + d2 : " + d3.getDistanceInMeter() + " m");
        System.out.println("d3 = d1 + d2 : " + d3.getDistanceInMillimeter() + " mm");
    }

    /**
     * Runs a demo for the second exercise.
     */
    public static void Exercise2 ()
    {
        Date d1 = new Date(2026, 3, 30);
        Date d2 = new Date(1982, 5, 12);
        Date d3 = new Date(1792, 7, 14);
        System.out.println(d1.getDateAsText());
        System.out.println(d2.getDateAsText());
        System.out.println(d3.getDateAsText());
    }

    /**
     * Runs a demo for the third exercise.
     */
    public static void Exercise3 ()
    {
        Optional<String> opt_string = Optional.of("Toto");
        Optional<String> opt_string_null = Optional.empty();
        Optional<String> opt_string_nullable_value = Optional.ofNullable("Test");
        Optional<String> opt_string_nullable_null = Optional.ofNullable(null);
        System.out.println(opt_string);
        System.out.println(opt_string_null);
        System.out.println(opt_string_nullable_value);
        System.out.println(opt_string_nullable_null);
        System.out.println("opt_string.orElse('truc') : " + opt_string.orElse("truc"));
        System.out.println("opt_string_null.orElse('truc') : " + opt_string_null.orElse("truc"));

        Optional<Distance> opt_dist = Optional.ofNullable(Distance.createMeterDistance(12.45));
        System.out.println("opt_dist : " + opt_dist);
    }

    /**
     * Runs a demo for the fourth exercise.
     */
    public static void Exercise4 ()
    {
        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(12);
        arr.add(24);
        arr.add(2);
        arr.add(5);
        arr.add(11);
        System.out.println(arr);
        ArrayList<Integer> s_arr = Sort.sort(arr);
        System.out.println(s_arr);

        ArrayList<String> arr2 = new ArrayList<>();
        arr2.add("Alpha");
        arr2.add("alpha");
        arr2.add("Zeta");
        arr2.add("Omicron");
        arr2.add("Beta");
        System.out.println(arr2);
        ArrayList<String> s_arr2 = Sort.sort(arr2);
        System.out.println(s_arr2);
    }

    /**
     * Runs a demo for the fifth exercise.
     */
    public static void Exercise5 ()
    {
        Optional<Integer> opt = Optional.of(42);
        Optional<Integer> n_opt = Optional.empty();

        System.out.println("opt.filter(i == 42) : " + opt.filter(i -> (i == 42)));
        System.out.println("opt.filter(i == 5) : " + opt.filter(i -> (i == 5)));
        System.out.println("n_opt.filter(i == 42) : " + n_opt.filter(i -> (i == 42)));
        System.out.println("n_opt.filter(i == 5) : " + n_opt.filter(i -> (i == 5)));

        System.out.println("opt.flatMap(int -> double * 2.5) : " + opt.flatMap(i -> (Optional.of(i.doubleValue() * 2.5))));
        System.out.println("n_opt.flatMap(int -> double * 2.5) : " + n_opt.flatMap(i -> (Optional.of(i.doubleValue() * 2.5))));

        Consumer<Integer> cons = i -> System.out.println("Consuming " + i);
        System.out.println("opt.ifPresent(cons) : ");
        opt.ifPresent(cons);
        System.out.println("n_opt.ifPresent(cons) : ");
        n_opt.ifPresent(cons);
    }

    /**
     * Main method, program entry point.
     * @param args : command-line arguments
     */
    public static void main(String[] args)
    {
        /*Exercise1();
        Exercise2();
        Exercise3();
        Exercise4();*/
        Exercise5();
    }
}