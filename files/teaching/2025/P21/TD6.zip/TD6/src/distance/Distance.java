package distance;

/**
 * This class stores a distance and provides a unit conversion for said distance.
 * @author Romain PERRIN
 */
public class Distance
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private double m_distance;  // distance en mm

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Distance.
     * @param distance : distance in mm
     */
    private Distance (double distance)
    {
        m_distance = distance;
    }

    /**
     * Factory method for Distance in mm.
     * @param distance : distance in mm
     * @return a new Distance
     */
    public static Distance createMillimeterDistance (double distance)
    {
        return new Distance(distance);
    }

    /**
     * Factory method for Distance in m.
     * @param distance : distance in m
     * @return a new Distance
     */
    public static Distance createMeterDistance (double distance)
    {
        return new Distance(distance * 1000); // 1m = 1 000mm
    }

    /**
     * Factory method for Distance in km.
     * @param distance : distance in km
     * @return a new Distance
     */
    public static Distance createKilometerDistance (double distance)
    {
        return new Distance(distance * 1000000);    // 1km = 1 000m = 1 000 000 mm
    }

    /**
     * Factory method for Distance in mile.
     * @param distance : distance in mile
     * @return a new Distance
     */
    public static Distance createMileDistance (double distance)
    {
        return new Distance(distance * 1.609344 * 1000000);   // 1 mile = 1.609344 m
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Getter for the distance attribute.
     * @return the distance in millimeter
     */
    public double getDistanceInMillimeter ()
    {
        return this.m_distance;
    }

    /**
     * Getter for the distance attribute.
     * @return the distance in meter
     */
    public double getDistanceInMeter ()
    {
        return this.m_distance / 1000;
    }

    /**
     * Getter for the distance attribute.
     * @return the distance in kilometer
     */
    public double getDistanceInKilometer ()
    {
        return this.m_distance / 1000000;
    }

    /**
     * Getter for the distance attribute.
     * @return the distance in mile
     */
    public double getDistanceInMile ()
    {
        return this.m_distance / 1.609344 / 1000000;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds two Distance objects and returns the result as a new Distance.
     * @param d1 : first distance
     * @param d2 : second distance
     * @return : a new Distance
     * @throws NullPointerException : is d1 or d2 is null
     */
    public static Distance add (Distance d1, Distance d2) throws NullPointerException
    {
        if (d1 == null)
        {
            throw new NullPointerException("d1 is null !");
        }
        if (d2 == null)
        {
            throw new NullPointerException("d2 is null !");
        }
        return createMillimeterDistance(d1.m_distance + d2.m_distance);
    }

    /**
     * Returns a human-readable string representing the Distance.
     * @return Distance(_distance_)
     */
    @Override
    public String toString()
    {
        return "Distance(" + this.m_distance + ")";
    }
}
