package distance;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * This class serves as the primary unit test class for the Distance class.
 * @author Romain PERRIN
 * @see Distance
 */
public class DistanceTest
{
    /**
     * Tests the conversions between units in the Distance class.
     */
    @Test
    public void test_conversion ()
    {
        Distance d1 = Distance.createMillimeterDistance(15);
        Distance d2 = Distance.createKilometerDistance(2);
        Distance d3 = Distance.add(d1, d2);
        assertEquals(15, d1.getDistanceInMillimeter(), 0);
        assertEquals(2, d2.getDistanceInKilometer(), 0);
        assertEquals(2000.015, d3.getDistanceInMeter(), 0);
    }
}
