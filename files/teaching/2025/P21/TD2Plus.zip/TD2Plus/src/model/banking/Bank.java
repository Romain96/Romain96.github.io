package model.banking;

import model.world.Country;

import java.util.HashMap;
import java.util.Optional;

/**
 * This class modelises a simplified bank and provides some basic account management.
 * @author Romain PERRIN
 */
public class Bank
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private static int m_counter = 0; // used to assign a unique ID when creating a new Bank

    private int m_id;   // unique bank identifier
    private String m_name;  // Bank name for some flavor
    private Country m_country;  // country the bank is based in
    private HashMap<Integer, Account> m_accounts;    // map between Account IDs and Accounts

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor for Bank. Creates a new Bank with no account.
     * @param name : the name of the bank
     * @param country : the country this bank is based in
     * @see Country
     */
    public Bank (String name, Country country)
    {
        setId(Bank.m_counter++);
        setName(name);
        setCountry(country);
        m_accounts = new HashMap<Integer, Account>();
    }

    /**
     * Copy constructor for Bank.
     * @param other : another instance of Bank
     */
    public Bank (Bank other)
    {
        setId(other.getId());
        setName(other.getName());
        setCountry(other.getCountry());
        m_accounts = new HashMap<Integer, Account>();
        for (Integer key : other.m_accounts.keySet())
        {
            m_accounts.put(key, new Account(other.m_accounts.get(key)));    // deep copy
        }
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    /**
     * Getter for ID.
     * @return the Bank's unique ID
     */
    public int getId ()
    {
        return m_id;
    }

    /**
     * Getter for name.
     * @return the Bank's name
     */
    public String getName ()
    {
        return m_name;
    }

    /**
     * Getter for country.
     * @return the Bank's country
     * @see Country
     */
    public Country getCountry ()
    {
        return m_country;
    }

    /**
     * Setter for ID
     * @param id : the Bank's unique ID
     */
    public void setId (int id)
    {
        m_id = id;
    }

    /**
     * Setter for name.
     * @param name : the Bank's name
     */
    public void setName (String name)
    {
        m_name = name;
    }

    /**
     * Setter for country.
     * @param country : the Bank's country
     * @see Country
     */
    public void setCountry (Country country)
    {
        m_country = country;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Checks whether an account exists in the Bank.
     * @param accountNumber : ID of the Account to check
     * @return true if the Account exists in the current Bank, false otherwise
     */
    public boolean checkAccount (int accountNumber)
    {
        return m_accounts.containsKey(accountNumber);
    }

    /**
     * Opens a new Account in the current Bank.
     * @param initialBalance : initial balance of the new account (>= 0)
     * @return a unique account ID associated with the created account
     * @see Account
     */
    public int openAccount (double initialBalance)
    {
        Account acc = new Account(initialBalance);
        int id = acc.getId();
        m_accounts.put(id, acc);
        return id;
    }

    /**
     * Closes (deletes) an account given its unique ID.
     * @param accountNumber : the account's unique ID
     */
    public void closeAccount (int accountNumber)
    {
        m_accounts.remove(accountNumber);
    }

    /**
     * Returns the current balance of an account given its unique ID.
     * @param accountNumber : the account's unique ID
     * @return the balance of the account if the ID is valid, empty otherwise
     */
    public Optional<Double> checkBalance (int accountNumber)
    {
        if (m_accounts.containsKey(accountNumber))
        {
            return Optional.of(m_accounts.get(accountNumber).getBalance());
        }
        return Optional.empty();
    }

    /**
     * Returns a copy of the account given a valid account ID.
     * @param accountNumber : the account's unique ID
     * @return a copy of the account if the ID is valid, empty otherwise
     */
    public Optional<Account> copyAccount (int accountNumber)
    {
        if (m_accounts.containsKey(accountNumber))
        {
            return Optional.of(new Account(m_accounts.get(accountNumber)));
        }
        return Optional.empty();
    }

    /**
     * Returns the account given a valid account ID.
     * @param accountNumber : the account's unique ID
     * @return a copy of the account if the ID is valid, empty otherwise
     */
    public Optional<Account> getAccount (int accountNumber)
    {
        if (m_accounts.containsKey(accountNumber))
        {
            return Optional.of(m_accounts.get(accountNumber));
        }
        return Optional.empty();
    }

    /**
     * Returns a human-readable Bank.
     * @return a string containing the details of the Bank
     */
    @Override
    public String toString ()
    {
        StringBuilder str = new StringBuilder();
        str.append("Bank\n");
        str.append("ID = ");
        str.append(getId());
        str.append("\nName = ");
        str.append(getName());
        str.append("\nCountry = ");
        str.append(getCountry().getFullName());
        str.append("\nAccounts =\n");
        for (Integer key : m_accounts.keySet())
        {
            str.append(m_accounts.get(key));
            str.append("\n");
        }
        return str.toString();
    }
}
