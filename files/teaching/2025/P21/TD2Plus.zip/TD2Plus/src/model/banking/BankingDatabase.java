package model.banking;

import model.world.Country;

import java.util.HashMap;
import java.util.Optional;

/**
 * This class provides a series of method to manipulate Banks and Accounts.
 * @author Romain PERRIN
 */
public class BankingDatabase
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private HashMap<Integer, Bank> m_banks;    // map bank ID --> Bank

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default empty constructor for BankingSystem, instanciates a BS with no bank.
     */
    public BankingDatabase()
    {
        m_banks = new HashMap<Integer, Bank>();
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Registers a new Bank
     * @param name : the Bank's name
     * @param country : the country the bank is based in
     * @return the Bank's unique ID used to access the bank
     * @see model.world.Country
     */
    public int registerBank (String name, Country country)
    {
        Bank b = new Bank(name, country);
        int id = b.getId();
        if (!m_banks.containsKey(id))
        {
            m_banks.put(id, b);
            return id;
        }
        return -1;  // error
    }

    /**
     * Internal method used to check if a bank exists in the database.
     * @param bankId : ID of the Bank
     * @return true if the bank exists in the database, false otherwise
     */
    private boolean checkBank (int bankId)
    {
        return m_banks.containsKey(bankId);
    }

    /**
     * Internal method destined to process a transfer between two accounts.
     * @param debtor : reference to the debtor Account
     * @param recipient : reference to the recipient Account
     * @param amount : amount to transfer (> 0)
     * @return true if the transfer succedes, false otherwise
     */
    private boolean transfer (Account debtor, Account recipient, double amount)
    {
        if (debtor != null && recipient != null && debtor.getBalance() >= amount)
        {
            debtor.setBalance(debtor.getBalance() - amount);
            recipient.setBalance(recipient.getBalance() + amount);
            return true;
        }
        return false;
    }

    /**
     * Simulates a transfer between two accounts represented by their IBAN.
     * @param deborBankId : ID of the debtor Bank
     * @param debtorAccountId : ID of the debtor Account in the debtor Bank
     * @param recipientBankId : ID of the recipient Bank
     * @param recipientAccountId : ID of the recipient Account in the recipient Bank
     * @param amount : transfer amount (must be > 0)
     * @return true if the transfer is valid, false otherwise
     * @see Bank
     * @see Account
     */
    public boolean simulateTransfer (int deborBankId, int debtorAccountId, int recipientBankId, int recipientAccountId, double amount)
    {
        // finding the debtor and recipient banks by extracting their 16 character bank ID
        if (checkBank(deborBankId) && checkBank(recipientBankId))
        {
            Bank debtorBank = m_banks.get(deborBankId);
            Bank recipientBank = m_banks.get(recipientBankId);
            // copy of both accounts and transfer
            Optional<Account> debtorAccountCopy = debtorBank.copyAccount(debtorAccountId);
            Optional<Account> recipientAccountCopy = recipientBank.copyAccount(recipientAccountId);
            if (debtorAccountCopy.isPresent() && recipientAccountCopy.isPresent())
            {
                return transfer(debtorAccountCopy.get(), recipientAccountCopy.get(), amount);
            }
        }
        return false;
    }

    /**
     * Processes a transfer between two accounts represented by their IBAN.
     * @param deborBankId : ID of the debtor Bank
     * @param debtorAccountId : ID of the debtor Account in the debtor Bank
     * @param recipientBankId : ID of the recipient Bank
     * @param recipientAccountId : ID of the recipient Account in the recipient Bank
     * @param amount : transfer amount (must be > 0)
     * @return true if the transfer is valid, false otherwise
     * @see Bank
     * @see Account
     */
    public boolean transfer (int deborBankId, int debtorAccountId, int recipientBankId, int recipientAccountId, double amount)
    {
        // finding the debtor and recipient banks by extracting their 16 character bank ID
        if (checkBank(deborBankId) && checkBank(recipientBankId))
        {
            Bank debtorBank = m_banks.get(deborBankId);
            Bank recipientBank = m_banks.get(recipientBankId);
            Optional<Account> debtorAccountCopy = debtorBank.getAccount(debtorAccountId);
            Optional<Account> recipientAccountCopy = recipientBank.getAccount(recipientAccountId);
            if (debtorAccountCopy.isPresent() && recipientAccountCopy.isPresent())
            {
                return transfer(debtorAccountCopy.get(), recipientAccountCopy.get(), amount);
            }
        }
        return false;
    }

    /**
     * Opens a new account in the bank.
     * @param bankId : the bank ID
     * @param initialBalance : the initial balance (>= 0)
     * @return either Empty or a new account ID if the account is created
     */
    public Optional<Integer> openAccount (int bankId, double initialBalance)
    {
        if (m_banks.containsKey(bankId))
        {
            return Optional.of(m_banks.get(bankId).openAccount(initialBalance));
        }
        return Optional.empty();
    }

    /**
     * Closes a given account.
     * @param bankId : the bank ID
     * @param accountId : the account ID
     */
    public void closeAccount (int bankId, int accountId)
    {
        if (m_banks.containsKey(bankId))
        {
            m_banks.get(bankId).closeAccount(accountId);
        }
    }

    /**
     * Generates a human-readable string representing the bank.
     * @return a string representing the bank
     */
    @Override
    public String toString ()
    {
        StringBuilder str = new StringBuilder();
        str.append("BankingSystem :\n");
        str.append("list of banks =\n");
        for (Integer key : m_banks.keySet())
        {
            str.append(m_banks.get(key).toString());
            str.append("\n");
        }
        return str.toString();
    }
}
