package model.world;

/**
 * This enum represents the continents of the world.
 * @author Romain PERRIN
 */
public enum Continent
{
    EUROPE,
    ASIA,
    AMERICA,
    AFRICA,
    OCEANIA;
}
