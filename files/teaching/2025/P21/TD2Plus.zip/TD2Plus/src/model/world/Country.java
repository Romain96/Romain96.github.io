package model.world;

/**
 * This class provides a simple way to represent a country.
 * @author Romain PERRIN
 */
public class Country
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_code;  // country code like "FRA" for France
    private String m_shortName; // short common name like "France"
    private String m_fullName;  // full country name like "the French Republic"
    private Continent m_continent;  // continent code

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor for Country, instanciates a country given all basic information.
     * @param code : 3-letter country code like "FRA"
     * @param shortName : shortened common country name like "France"
     * @param fullName : full country name like "the French Republic"
     * @param continent : code for the continent
     * @see Continent
     */
    public Country (String code, String shortName, String fullName, Continent continent)
    {
        setCode(code);
        setShortName(shortName);
        setFullName(fullName);
        setContinent(continent);
    }

    /**
     * Copy constructor for Country, instanciates a deep copy of the given Country instance.
     * @param other : another instance of Country
     */
    public Country (Country other)
    {
        setCode(other.getCode());
        setShortName(other.getShortName());
        setFullName(other.getFullName());
        setContinent(other.getContinent());
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    /**
     * Getter for the country code.
     * @return the 3-letter country code
     */
    public String getCode ()
    {
        return m_code;
    }

    /**
     * Getter for the shortened country name.
     * @return the short version of the country name
     */
    public String getShortName ()
    {
        return m_shortName;
    }

    /**
     * Getter for the full country name.
     * @return the full version of the country name
     */
    public String getFullName ()
    {
        return m_fullName;
    }

    /**
     * Getter for the continent name.
     * @return the name of the country's continent
     * @see Continent
     */
    public Continent getContinent ()
    {
        return m_continent;
    }

    /**
     * Setter for the country code.
     * @param code 3-letter country code
     */
    public void setCode (String code)
    {
        m_code = code;
    }

    /**
     * Setter for the shortened country name.
     * @param shortName : short version of the country name
     */
    public void setShortName (String shortName)
    {
        m_shortName = shortName;
    }

    /**
     * Setter for the full country name.
     * @param fullName : full version of the country name
     */
    public void setFullName (String fullName)
    {
        m_fullName = fullName;
    }

    /**
     * Setter for the country's continent.
     * @param continent : code for the country's continent
     * @see Continent
     */
    public void setContinent(Continent continent)
    {
        m_continent = continent;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------
}
