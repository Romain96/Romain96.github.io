package model.banking;

import java.util.Objects;

/**
 * This class modelises a simplified generic bank account with a balance management.
 * @author Romain PERRIN
 */
public class Account
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private static int m_counter = 0;   // used to generate unique IDs

    private int m_id;  // unique ID
    private double m_balance;   // current account balance

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parameterized constructor for Account : instanciates a new Account with the given initial balance.
     * @param initialBalance : initial balance (must be >= 0)
     */
    public Account (double initialBalance)
    {
        setId(Account.m_counter++);
        setBalance(initialBalance >= 0 ? initialBalance : 0);
    }

    /**
     * Copy constructor for Account : instanciates a new Account as a deep copy of the given Account instance.
     * @param other : another Account to copy
     */
    public Account (Account other)
    {
        if (other != null)
        {
            setId(other.getId());
            setBalance(other.getBalance());
        }
        else
        {
            setId(-1);
            setBalance(0);
        }
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    /**
     * Getter for ID
     * @return the account's unique ID
     */
    public int getId ()
    {
        return m_id;
    }

    /**
     * Getter for balance
     * @return the account's current balance
     */
    public double getBalance ()
    {
        return m_balance;
    }

    /**
     * Setter for ID.
     * @param id : the Account's unique ID
     */
    public void setId (int id)
    {
        m_id = id;
    }

    /**
     * Setter for balance.
     * @param balance : the new balance
     */
    public void setBalance (double balance)
    {
        m_balance = balance;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * A hash code representing the current Account instance based on the BBAN.
     * @return a hash code for the current instance
     */
    @Override
    public int hashCode ()
    {
        return Objects.hash(m_id, m_balance);
    }

    /**
     * Provides a comparison with a generic object.
     * @param obj : the reference object with which to compare.
     * @return true if obj is an instance of Account a both BBAN and balance are identical to the current instance
     */
    @Override
    public boolean equals (Object obj)
    {
        if (obj != null && this.getClass() == obj.getClass())
        {
            Account acc = (Account) obj;    // downcast
            return getId() == acc.getId() && getBalance() == acc.getBalance();
        }
        return false;
    }

    /**
     * Returns a string containing a human-readable content of the current Account instance.
     * @return A human-readable Account for display
     */
    @Override
    public String toString ()
    {
        return "Account : ID = " + getId() + ", balance = " + getBalance() + " €";
    }
}
