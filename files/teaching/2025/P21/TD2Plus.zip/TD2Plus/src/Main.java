import model.banking.BankingDatabase;
import model.world.*;

import java.util.Optional;

/**
 * Main class.
 */
public class Main
{
    /**
     * Main method, program entry point.
     * @param args : command-line arguments (ignored)
     */
    public static void main(String[] args)
    {
        BankingDatabase bs = new BankingDatabase();

        System.out.println("Banking database :");
        System.out.println(bs);

        int bdf = bs.registerBank("Banque de France", new Country("FRA", "France", "République Française", Continent.EUROPE));
        System.out.println("Banking database after one addition :");
        System.out.println(bs);

        int ecb = bs.registerBank("European Central Bank", new Country("EU", "EU", "European Union", Continent.EUROPE));
        System.out.println("Banking database after two additions :");
        System.out.println(bs);

        Optional<Integer> alice = bs.openAccount(bdf, 120.0);
        System.out.println("Banking database after opening Alice's account :");
        System.out.println(bs);

        Optional<Integer> bob = bs.openAccount(bdf, 80.0);
        System.out.println("Banking database after opening Bob's account :");
        System.out.println(bs);

        Optional<Integer> charles = bs.openAccount(bdf, 100.0);
        System.out.println("Banking database after opening Charles' account :");
        System.out.println(bs);

        Optional<Integer> euFund = bs.openAccount(ecb, 1000000.0);
        System.out.println("Banking database after opening the European Fund's account :");
        System.out.println(bs);

        if (alice.isPresent() && bob.isPresent())
        {
            System.out.println("Transfer of 50€ from Alice to Bob : " + bs.transfer(bdf, alice.get(), bdf, bob.get(), 50));
            System.out.println("Banking database after the first transfer :");
            System.out.println(bs);
        }

        if (euFund.isPresent() && charles.isPresent())
        {
            System.out.println("Transfer of 2999.99€ from the EU Fund to Charles : " + bs.transfer(ecb, euFund.get(), bdf, charles.get(), 2999.99));
            System.out.println("Banking database after the second transfer :");
            System.out.println(bs);
        }

        if (bob.isPresent())
        {
            bs.closeAccount(bdf, bob.get());
            System.out.println("Banking database after closing Bob's account :");
            System.out.println(bs);
        }

        if (euFund.isPresent() && bob.isPresent())
        {
            System.out.println("Simulating a transfer of 100€ from the EU Fund to Bob : " + bs.simulateTransfer(ecb, euFund.get(), bdf, bob.get(), 100));
            System.out.println("Banking database after the simulation :");
            System.out.println(bs);
        }

    }
}