// Auteur : Romain PERRIN

package date;

/**
 * La classe Month permet de représenter un mois de l'année et d'en extraire ses caractéristiques.
 * @author Romain PERRIN (romain.perrin@unistra.fr)
 */
public class Month
{
    //-------------------------------------------------------------------------
    // Attributs
    //-------------------------------------------------------------------------

    private int m_month;;  // numéro du mois (1 à 12)

    //-------------------------------------------------------------------------
    // Constructeurs
    //-------------------------------------------------------------------------

    /**
     * Constructeur paramétré de la classe Month
     * @param month : numéro du mois (doit être compris entre 1 et 12)
     */
    public Month(int month)
    {
        this.m_month = (month >= 1 && month <= 12) ? month : 1;
    }

    //-------------------------------------------------------------------------
    // Getters & setters
    //-------------------------------------------------------------------------

    /**
     * Getter pour l'attribut m_month
     * @return le numéro du mois
     */
    public int getMonth()
    {
        return this.m_month;
    }

    //-------------------------------------------------------------------------
    // Méthodes
    //-------------------------------------------------------------------------

    /**
     * Calcule le nombre de jours dans le mois.
     * @param year : l'année (nécessaire pour déterminer si février a 28 ou 29 jours)
     * @return le nombre de jours dans le mois
     */
    public int daysNumber(Year year)
    {
        if (this.m_month == 4 || this.m_month == 6 || this.m_month == 9 || this.m_month == 11)
        {
            return 30;
        }
        else if (this.m_month == 2)
        {
            return year.isLeapYear() ? 29 : 28; // avec l'opérateur ternaire
        }
        else
        {
            return 31;	// cas le plus courant
        }
    }

    /** Permet de vérifier si deux mois sont égaux
     * @param other : l'autre mois à comparer
     * @return true si les deux mois sont égaux, false sinon
     */
    public boolean equals(Month other)
    {
        return this.m_month == other.getMonth();
    }

    /** Permet de vérifier si un mois est antérieur à un autre
     * @param other : l'autre mois à comparer
     * @return true si ce mois est antérieur à l'autre, false sinon
     */
    public boolean isBefore(Month other)
    {
        return this.m_month < other.getMonth();
    }

    /**
     * Permet de convertir le numéro du mois en toutes lettres
     * @return le mois en toutes lettres
     */
    public String getMonthAsText()
    {
        switch (this.m_month)
        {
            case 1: return "Janvier";
            case 2: return "Février";
            case 3: return "Mars";
            case 4: return "Avril";
            case 5: return "Mai";
            case 6: return "Juin";
            case 7: return "Juillet";
            case 8: return "Août";
            case 9: return "Septembre";
            case 10: return "Octobre";
            case 11: return "Novembre";
            case 12: return "Décembre";
            default: return "Mois invalide";
        }
    }

    /** Surcharge de la méthode toString pour afficher le mois
     */
    @Override
    public String toString()
    {
        return "Month(_" + this.getMonth() + "_)";
    }
}