// Auteur : Romain PERRIN

package date;

/**
 * La classe Year permet de représenter une année et d'en extraire ses caractéristiques.
 * @author Romain PERRIN (romain.perrin@unistra.fr)
 */
public class Year
{
    //-------------------------------------------------------------------------
    // Attributs
    //-------------------------------------------------------------------------

    private int m_year;  // numéro de l'année (ex : 2026)

    //-------------------------------------------------------------------------
    // Constructeurs
    //-------------------------------------------------------------------------

    /**
     * Constructeur paramétré de la classe Year
     * @param year : numéro de l'année (doit être un entier positif)
     */
    public Year(int year)
    {
        this.m_year = year;
    }

    //-------------------------------------------------------------------------
    // Getters & setters
    //-------------------------------------------------------------------------

    /**
     * Getter pour l'attribut m_year
     * @return le numéro de l'année
     */
    public int getYear()
    {
        return this.m_year;
    }

    //-------------------------------------------------------------------------
    // Méthodes
    //-------------------------------------------------------------------------

    /**
     * Méthode permettant de déterminer si l'année est bissextile.
     * @return true si l'année est bissextile, false sinon
     */
    public boolean isLeapYear()
    {
        return (this.m_year % 4 == 0 && this.m_year % 100 != 0) || (this.m_year % 400 == 0);
    }

    /**
     * Méthode calculant le nombre de jours dans l'année en tenant compte de si l'année est bissextile ou non.
     * @return le nombre de jours dans l'année (365 ou 366)
     */
    public int daysNumber()
    {
        return this.isLeapYear() ? 366 : 365;	// avec l'opérateur ternaire
    }

    /**
     * Permet de vérifier si deux années sont égales.
     * @param other : l'autre année à comparer
     * @return true si les deux années sont égales, false sinon
     */
    public boolean equals(Year other)
    {
        return this.m_year == other.getYear();
    }

    /**
     * Permet de vérifier si une année est antérieure à une autre.
     * @param other : l'autre année à comparer
     * @return true si cette année est antérieure à l'autre, false sinon
     */
    public boolean isBefore(Year other)
    {
        return this.m_year < other.getYear();
    }

    /** Surcharge de la méthode toString
     */
    @Override
    public String toString()
    {
        return "Year(" + this.getYear() + ")";
    }
}
