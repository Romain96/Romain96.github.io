// Auteur : Romain PERRIN

package date;

/**
 * La classe Date permet de représenter une date composée d'un jour, d'un mois et d'une année.
 * @author Romain PERRIN (romain.perrin@unistra.fr)
 */
public class Date
{
    //-------------------------------------------------------------------------
    // Attributs
    //-------------------------------------------------------------------------

    private int m_day;    // jour du mois
    private Month m_month; // mois de l'année
    private Year m_year;   // année

    //-------------------------------------------------------------------------
    // Constructeurs
    //-------------------------------------------------------------------------

    /**
     * Constructeur paramétré de la classe Date
     * @param day : jour du mois (doit entre 1 et Month.daysNumber(year))
     * @param month : mois de l'année (doit être un entier entre 1 et 12)
     * @param year : année (sans contrainte)
     */
    public Date(int day, int month, int year)
    {
        this.m_year = new Year(year);
        this.m_month = new Month(month);
        this.m_day = (day < 1 || day > this.m_month.daysNumber(this.m_year)) ? 1 : day;
    }

    //-------------------------------------------------------------------------
    // Getters & setters
    //-------------------------------------------------------------------------

    /**
     * Getter pour le jour
     * @return le numéro du jour
     */
    public int getDay()
    {
        return this.m_day;
    }

    /**
     * Getter pour le mois
     * @return le numéro du mois
     */
    public int getMonth()
    {
        return this.m_month.getMonth();
    }

    /**
     * Getter pour l'année
     * @return le numéro de l'année
     */
    public int getYear()
    {
        return this.m_year.getYear();
    }

    //-------------------------------------------------------------------------
    // Méthodes
    //-------------------------------------------------------------------------

    /** Permet de comparer deux dates
     * @param other : la date à comparer avec l'instance courante
     * @return true si les deux dates sont égales, false sinon
     */
    public boolean equals(Date other)
    {
        return this.m_day == other.getDay() && this.m_month.equals(other.m_month) && this.m_year.equals(other.m_year);
    }

    /** Permet de savoir si une date est antérieure à une autre
     * @param other : la date à comparer avec l'instance courante
     * @return true si l'instance courante est antérieure à other, false sinon
     */
    public boolean isBefore(Date other)
    {
        return this.m_year.isBefore(other.m_year)
                || (this.m_year.equals(other.m_year) && this.m_month.isBefore(other.m_month))
                || (this.m_year.equals(other.m_year) && this.m_month.equals(other.m_month) && this.m_day < other.m_day);
    }

    /**
     * Surcharge de la méthode toString
     * @return une chaîne de caractères représentant la date au format "DD Month YYYY"
     */
    @Override
    public String toString()
    {
        return this.m_day + " " + this.m_month.getMonthAsText() + " " + this.m_year.getYear();
    }
}
