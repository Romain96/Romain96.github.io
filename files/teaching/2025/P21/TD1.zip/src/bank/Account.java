// Auteur : Romain PERRIN

package bank;

/**
 * La classe Account permet de simuler un compte bancaire basique.
 * Il est possible de connaître le solde d'un compte ainsi que d'effectuer des virements entre comptes.
 * Il est impossible de modifier le solde autrement que par un virement.
 * @author Romain PERRIN (romain.perrin@unistra.fr)
 */
public class Account
{
    //-------------------------------------------------------------------------
    // Attributs
    //-------------------------------------------------------------------------

    private double m_balance;	// solde du compte

    //-------------------------------------------------------------------------
    // Constructeurs
    //-------------------------------------------------------------------------

    /**
     * Constructeur du compte (constructeur vide)
     * @param initialBalance : solde initial du compte
     */
    public Account(double initialBalance)
    {
        m_balance = initialBalance >= 0 ? initialBalance : 0;
    }

    //-------------------------------------------------------------------------
    // Getters & setters
    //-------------------------------------------------------------------------

    /**
     * Permet de consulter le solde du compte
     * @return le solde actuel du compte
     */
    public double getBalance()
    {
        return m_balance;
    }

    //-------------------------------------------------------------------------
    // Méthodes
    //-------------------------------------------------------------------------

    /**
     * Permet d'effectuer un virement depuis le compte actuel vers le compte indiqué
     * @param amount : montant du virement (doit être strictement positif)
     * @param recipient : compte du destinataire (doit être non null)
     * @return retourne vrai si le virement a eu lieu, faux sinon
     */
    public boolean transfer(double amount, Account recipient)
    {
        // seulement si le montant est strictement positif, le destinataire n'est pas null est le solde excède le montant du virement
        if (amount > 0 && amount <= this.m_balance && recipient != null)
        {
            this.m_balance -= amount;
            recipient.m_balance += amount;
            return true;
        }
        return false;
    }

    /**
     * Retourne le montant du solde sous forme de chaîne de caractères
     * @return "Account(balance: _balance_)"
     */
    @Override
    public String toString()
    {
        return "Account(_balance: " + this.getBalance() + "€_)";
    }
}
