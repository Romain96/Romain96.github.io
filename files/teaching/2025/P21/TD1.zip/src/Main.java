// Auteur : Romain PERRIN

import bank.Account;
import date.*;

/**
 * Point d'entrée du programme de test de la classe Account et de la classe Date.
 * @author Romain PERRIN (romain.perrin@unistra.fr)
 */
public class Main
{
    /**
     * Méthode principale pour le test des classes Account et Date.
     * @param args : arguments (ignorés)
     */
    public static void main(String[] args)
    {
        // Classe Account

        Account alice = new Account(100);   // Alice avec un solde initial de 100
        Account bob = new Account(60);      // Bob avec un solde initial de 60
        Account charles = new Account(120);  // Charles avec un solde initial de 120

        System.out.println("Soldes initiaux :");
        System.out.println("Alice : " + alice);
        System.out.println("Bob : " + bob);
        System.out.println("Charles : " + charles);

        // virement 1 : 20 du compte d’Alice vers celui de Charles
        System.out.println("\nvirement 1 : 20 du compte d’Alice vers celui de Charles");
        boolean v1 = alice.transfer(20, charles);
        System.out.println("virement effectué : " + v1);

        System.out.println("Alice : " + alice);
        System.out.println("Bob : " + bob);
        System.out.println("Charles : " + charles);

        // virement 2 : 10 du compte d’Alice vers celui de Bob
        System.out.println("\nvirement 2 : 10 du compte d’Alice vers celui de Bob");
        boolean v2 = alice.transfer(10, bob);
        System.out.println("virement effectué : " + v2);

        System.out.println("Alice : " + alice);
        System.out.println("Bob : " + bob);
        System.out.println("Charles : " + charles);

        // virement 3 : 30 du compte de Bob vers celui de de Charles
        System.out.println("\nvirement 3 : 30 du compte de Bob vers celui de Charles");
        boolean v3 = bob.transfer(30, charles);
        System.out.println("virement effectué : " + v3);

        System.out.println("Alice : " + alice);
        System.out.println("Bob : " + bob);
        System.out.println("Charles : " + charles);

        // virement 4 : 100 du compte de Bob vers celui de Charles (impossible)
        System.out.println("\nvirement 4 : 100 du compte de Bob vers celui de Charles (impossible)");
        boolean v4 = bob.transfer(100, charles);
        System.out.println("virement effectué : " + v4);

        System.out.println("Alice : " + alice);
        System.out.println("Bob : " + bob);
        System.out.println("Charles : " + charles);

        // virement 5 : −10 du compte de Bob vers celui de Charles (impossible)
        System.out.println("\nvirement 5 : −10 du compte de Bob vers celui de Charles (impossible)");
        boolean v5 = bob.transfer(-10, charles);
        System.out.println("virement effectué : " + v5);

        System.out.println("Alice : " + alice);
        System.out.println("Bob : " + bob);
        System.out.println("Charles : " + charles);

        // virement 6 : 10 du compte de Bob vers celui de null (impossible)
        System.out.println("\nvirement 6 : −10 du compte de Bob vers celui de null (impossible)");
        boolean v6 = bob.transfer(10, null);
        System.out.println("virement effectué : " + v6);

        System.out.println("Alice : " + alice);
        System.out.println("Bob : " + bob);
        System.out.println("Charles : " + charles);

        // Classe Date

        Date aujourdhui = new Date(5, 2, 2026);  // 5 février 2026
        System.out.println("\nDate d'aujourd'hui : " + aujourdhui);

        Date demain = new Date(6, 2, 2026);	// 6 février 2026
        System.out.println("Date de demain : " + demain);

        System.out.println("aujourdhui.equals(demain) : " + aujourdhui.equals(demain));
        System.out.println("demain.equals(aujourdhui) : " + demain.equals(aujourdhui));
        System.out.println("aujourdhui.equals(aujourdhui) : " + aujourdhui.equals(aujourdhui));
        System.out.println("aujourdhui.isBefore(demain) : " + aujourdhui.isBefore(demain));
        System.out.println("aujourdhui.isBefore(aujourdhui) : " + aujourdhui.isBefore(aujourdhui));
        System.out.println("demain.isBefore(aujourdhui) : " + demain.isBefore(aujourdhui));

        Date dateInvalide = new Date(32, 13, -2026);	 // date invalide
        System.out.println("Date invalide : " + dateInvalide);
    }
}