package toBeInherited;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test class for the Quadrangle class.
 * @author Romain PERRIN
 */
public class QuadrangleTest
{
    /**
     * Tests the constructor of Quadrangle.
     */
    @Test
    public void test_constructor ()
    {
        Quadrangle quad = new Quadrangle(1, 2, 3, 4);
        assertEquals(1, quad.getSideLength(0), 0);
        assertEquals(2, quad.getSideLength(1), 0);
        assertEquals(3, quad.getSideLength(2), 0);
        assertEquals(4, quad.getSideLength(3), 0);
    }

    /**
     * Tests the setLength accessor method of a Quadrangle.
     */
    @Test
    public void test_setLength ()
    {
        Quadrangle quad = new Quadrangle(1, 2, 3, 4);
        quad.setSideLength(0, 2);
        assertEquals(2, quad.getSideLength(0), 0);
        assertEquals(2, quad.getSideLength(1), 0);
        assertEquals(3, quad.getSideLength(2), 0);
        assertEquals(4, quad.getSideLength(3), 0);
    }

    /**
     * Tests the getPerimeter method on a Quadrangle.
     */
    @Test
    public void test_perimeter ()
    {
        Quadrangle quad = new Quadrangle(1, 2, 3, 4);
        assertEquals(10, quad.getPerimeter(), 0);
    }
}
