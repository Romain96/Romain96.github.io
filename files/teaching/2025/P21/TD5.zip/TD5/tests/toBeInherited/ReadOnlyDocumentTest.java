package toBeInherited;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test class for the Document class.
 * @author Romain PERRIN
 */
public class ReadOnlyDocumentTest
{
    /**
     * Tests the constructor of a ReadOnlyDocument.
     */
    @Test
    public void test_constructor ()
    {
        Document doc = new Document();
        ReadOnlyDocument rdoc = new ReadOnlyDocument(doc);
        assertEquals("", rdoc.getData());
    }
}
