package toBeInherited;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test class for the Quadrangle class.
 * @author Romain PERRIN
 */
public class DiamondTest
{
    /**
     * Tests the constructor of Diamond.
     */
    @Test
    public void test_constructor ()
    {
        Diamond d = new Diamond(2);
        assertEquals(2, d.getLength(), 0);
    }

    /**
     * Tests the setLength accessor method of Diamond.
     */
    @Test
    public void test_setLength ()
    {
        Diamond d = new Diamond(2);
        d.setLength(3);
        assertEquals(3, d.getLength(), 0);
    }

    /**
     * Tests the getPerimeter method of a Diamond.
     */
    @Test
    public void test_perimeter ()
    {
        Diamond d = new Diamond(2);
        assertEquals(8, d.getPerimeter(), 0);
    }
}
