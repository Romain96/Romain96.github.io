package toBeInherited;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test class for the OverdraftAccount class.
 * @author Romain PERRIN
 */
public class OverdraftAccountTest
{
    /**
     * Tests the constructor on an OverdraftAccount.
     */
    @Test
    public void test_constructor ()
    {
        double initialBalance = 10;
        double overdraft = 50;
        OverdraftAccount acc = new OverdraftAccount(initialBalance, overdraft);
        assertEquals(initialBalance, acc.getBalance(), 0);
        assertEquals(overdraft, acc.getMaximalOverdraft(), 0);
    }

    /**
     * Tests the transfer method on an OverdraftAccount.
     */
    @Test
    public void test_transfer ()
    {
        OverdraftAccount sender = new OverdraftAccount(20, 10);
        OverdraftAccount receiver = new OverdraftAccount(10, 0);
        sender.transfer(25, receiver);
        assertEquals(-5, sender.getBalance(), 0);
        assertEquals(35, receiver.getBalance(), 0);
    }
}

