package toBeInherited;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test class for the Document class.
 * @author Romain PERRIN
 */
public class DocumentTest
{
    /**
     * Tests the constructor of a Document.
     */
    @Test
    public void test_constructor ()
    {
        Document doc = new Document();
        assertEquals("", doc.getData());
    }

    /**
     * Tests the append method on a Document.
     */
    @Test
    public void test_append ()
    {
        Document doc = new Document();
        doc.append("data");
        assertEquals("data", doc.getData());
    }
}
