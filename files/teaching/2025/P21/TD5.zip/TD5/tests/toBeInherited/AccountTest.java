package toBeInherited;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * Unit test class for the Account class.
 * @author Romain PERRIN
 */
public class AccountTest
{
    /**
     * Tests the constructor of Account.
     */
    @Test
    public void test_constructor ()
    {
        double initialBalance = 10;
        Account acc = new Account(initialBalance);
        assertEquals(initialBalance, acc.getBalance(), 0);
    }

    /**
     * Tests the transfer method between two Account.
     */
    @Test
    public void test_transfer ()
    {
        Account sender = new Account(20);
        Account receiver = new Account(10);
        sender.transfer(7, receiver);
        assertEquals(13, sender.getBalance(), 0);
        assertEquals(17, receiver.getBalance(), 0);
    }
}
