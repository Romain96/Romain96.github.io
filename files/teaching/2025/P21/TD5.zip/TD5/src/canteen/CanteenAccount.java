package canteen;

/**
 * This class modelises a canteen account and provides a way to compute meal prices from a number of consumed meals.
 * @author Romain PERRIN
 */
public class CanteenAccount
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private double m_mealPrice;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new CanteenAccount.
     * @param mealPrice : single meal price
     */
    public CanteenAccount (double mealPrice)
    {
        this.m_mealPrice = mealPrice;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the price of buying a given amount of meals for lunch.
     * @param mealNumber : the number of meals to buy
     * @return the price of mealNumber meals
     */
    public double buyLunch (int mealNumber)
    {
        return this.m_mealPrice * mealNumber;
    }

    /**
     * Returns a human-readable string representing the CanteenAccount.
     * @return CanteenAccount(mealPrice : _mealPrice_)
     */
    @Override
    public String toString()
    {
        return "CanteenAccount(mealPrice : " + this.m_mealPrice + ")";
    }
}
