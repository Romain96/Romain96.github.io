package canteen;

import java.util.ArrayList;

/**
 * This class computes the revenues for all paid meals taken at the canteen as a function of the number of meals per student.
 * @author Romain PERRIN
 */
public class CanteenRevenue
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private ArrayList<CanteenAccount> m_students;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new CanteenRevenue from a list of CanteenAccount.
     * @param students : list of students
     */
    public CanteenRevenue (ArrayList<CanteenAccount> students)
    {
        this.m_students = students;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the number of students who paid for meals.
     * @return the number of students
     */
    public int getStudentNumber ()
    {
        return this.m_students.size();
    }

    /**
     * Computes the total revenue for the canteen given an array containing the number of meals bought per student.
     * @param mealNumber : the number of meals bought per student (must be of the same size as m_students)
     * @return the total revenue for the canteen
     */
    public double lunchRevenue (int[] mealNumber)
    {
        double totalPrice = 0;
        for (int i = 0; i < this.m_students.size(); i++)
        {
            totalPrice += this.m_students.get(i).buyLunch(mealNumber[i]);
        }
        return totalPrice;
    }

    /**
     * Returns a human-readable string representing the CanteenRevenue
     * @return CanteenRevenue(students : _students_)
     */
    @Override
    public String toString ()
    {
        return "CanteenRevenue(students : " + this.m_students + ")";
    }
}
