package canteen;

/**
 * This class represents a special CanteenAccount which benefits from a discount on the first n meals.
 * @author Romain PERRIN
 */
public class DiscountCanteenAccount extends CanteenAccount
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private double m_discountPrice;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new DiscountCanteenAccount.
     * @param mealPrice : standard meal price
     * @param discountMealPrice : discount meal price
     */
    public DiscountCanteenAccount (double mealPrice, double discountMealPrice)
    {
        super(mealPrice);
        this.m_discountPrice = discountMealPrice;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the price of buying a given amount of meals.
     * @param mealNumber : the number of meals to buy
     * @return the price of mealNumber meals
     */
    @Override
    public double buyLunch(int mealNumber)
    {
        if (mealNumber <= 3)
        {
            return this.m_discountPrice * mealNumber;   // n discount
        }
        return super.buyLunch(mealNumber - 3) + 3 * this.m_discountPrice;   // 3 discount + (n-3) standard
    }

    /**
     * Returns a human-readable string representing a DiscountCanteenAccount.
     * @return DiscountCanteenAccount(discountPrice : _discountPrice_)
     */
    @Override
    public String toString()
    {
        return "DiscountCanteenAccount(discountPrice : " + this.m_discountPrice + ")";
    }
}
