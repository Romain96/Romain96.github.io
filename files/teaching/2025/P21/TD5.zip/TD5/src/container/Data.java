package container;

import java.util.ArrayList;

/**
 * This abstract class modelises the different storage methods in an array.
 * @author Romain PERRIN
 */
public abstract class Data
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    protected ArrayList<String> m_data;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds data to the structure.
     * @param data : non-null string data
     */
    public abstract void add (String data);

    /**
     * Tests whether the container contains a given value.
     * @param data : the value to test
     * @return true if the container contains data, false otherwise
     */
    public boolean contains (String data)
    {
        return m_data.contains(data);
    }

    /**
     * Returns a human-readable string representing the Data.
     * @return Data(_data_)
     */
    @Override
    public String toString ()
    {
        return "Data(" + this.m_data + ")";
    };
}
