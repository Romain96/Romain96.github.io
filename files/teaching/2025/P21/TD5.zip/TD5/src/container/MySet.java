package container;

import java.util.ArrayList;

/**
 * This class modelises a custom set of data.
 * @author Romain PERRIN
 */
public class MySet extends Data
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a new empty MySet.
     */
    public MySet ()
    {
        this.m_data = new ArrayList<>();
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds data to the set.
     * @param data : non-null string data
     */
    @Override
    public void add (String data)
    {
        if (data != null && !this.m_data.contains(data))
        {
            this.m_data.add(data);
        }
    }

    /**
     * Returns a human-readable string representing the MySet.
     * @return MySet(data : _data_)
     */
    @Override
    public String toString()
    {
        return "MySet(data : " + this.m_data + ")";
    }
}
