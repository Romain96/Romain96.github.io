package container;

import java.util.ArrayList;

/**
 * This class modelises a custom list of data.
 * @author Romain PERRIN
 */
public class MyList extends Data
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a new empty MyList.
     */
    public MyList ()
    {
        this.m_data = new ArrayList<>();
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds data to the list.
     * @param data : non-null string data
     */
    @Override
    public void add(String data)
    {
        if (data != null)
        {
            this.m_data.add(data);
        }
    }

    /**
     * Returns the size of the list.
     * @return the list size
     */
    public int size ()
    {
        return this.m_data.size();
    }

    /**
     * Returns the i-th element of the list.
     * @param i : the element's index
     * @return the i-th element
     */
    public String get (int i)
    {
        return this.m_data.get(i);
    }

    /**
     * Returns a human-readable string representing the MyList.
     * @return MyList(data : _data_)
     */
    @Override
    public String toString()
    {
        return "MyList(data : " + this.m_data + ")";
    }
}
