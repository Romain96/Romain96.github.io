package file;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * This class modelises the FileAccess.
 * @author Romain PERRIN
 */
public class FileAccess
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_path;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized, constructor, instantiates a new FileAccess from a path.
     * @param path : path to the file
     */
    public FileAccess (String path)
    {
        this.m_path = path;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Reads the data in a given file.
     * @param code : access permission code
     * @return the read data
     * @throws IOException : if failing to open the file
     * @throws Exception : if the access code is invalid
     * @see PermissionMode
     */
    public String read (PermissionMode code) throws IOException, Exception
    {
        if (code == PermissionMode.READ_ONLY || code == PermissionMode.READ_WRITE || code == PermissionMode.READ_EXECUTE || code == PermissionMode.READ_WRITE_EXECUTE)
        {
            BufferedReader reader = new BufferedReader(new FileReader(this.m_path));
            String result = reader.readLine();
            reader.close();
            return result;
        }
        else
        {
            throw new Exception(code + " does not allow to read the file !");
        }
    }

    /**
     * Writes (appends) the given text to a file.
     * @param code : access permission mode
     * @param text : string to write
     * @throws IOException : if failing to open the file
     * @throws Exception : if the access code is invalid
     * @see PermissionMode
     */
    public void write (PermissionMode code, String text) throws IOException, Exception
    {
        if (code == PermissionMode.WRITE_ONLY || code == PermissionMode.WRITE_EXECUTE || code == PermissionMode.READ_WRITE || code == PermissionMode.READ_WRITE_EXECUTE)
        {
            FileWriter writer = new FileWriter(this.m_path, true);
            writer.write(text);
            writer.close();
        }
        else
        {
            throw new Exception(code + " does not allow to write to the file !");
        }
    }

    /**
     * Executes the code in a given file.
     * @param code : access permission code
     * @throws Exception : if the code is invalid
     * @see PermissionMode
     */
    public void execute (PermissionMode code) throws Exception
    {
        if (code == PermissionMode.EXECUTE_ONLY || code == PermissionMode.READ_EXECUTE || code == PermissionMode.WRITE_EXECUTE || code == PermissionMode.READ_WRITE_EXECUTE)
        {
            BufferedReader reader = new BufferedReader(new FileReader(this.m_path));
            System.out.println(reader.readLine());
            reader.close();
        }
        else
        {
            throw new Exception(code + " does not allow to execute the file !");
        }
    }
}
