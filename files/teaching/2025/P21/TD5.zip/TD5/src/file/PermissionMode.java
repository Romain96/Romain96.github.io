package file;

/**
 * This enum represents the different access codes allowed to be used when opening a file (read, write, execute).
 * @author Romain PERRIN
 */
public enum PermissionMode
{
    NONE,
    EXECUTE_ONLY,
    WRITE_ONLY,
    WRITE_EXECUTE,
    READ_ONLY,
    READ_EXECUTE,
    READ_WRITE,
    READ_WRITE_EXECUTE
}
