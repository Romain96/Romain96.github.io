package toBeInherited;

/**
 * This class modelises a specialized Document, the ReadOnlyDocument.
 * It only allows to write data, no data appending method being provided.
 * @author Romain PERRIN
 */
public class ReadOnlyDocument
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private final Document m_document;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new ReadOnlyDocument.
     * @param document : base document
     */
    public ReadOnlyDocument (Document document)
    {
        this.m_document = document;
    }

    //--------------------------------------------------------------------------
    // ACCESSORS
    //--------------------------------------------------------------------------

    /**
     * Getter for the data.
     * @return the current data
     */
    public String getData ()
    {
        return this.m_document.getData();
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Saves the data into the given file.
     * @param filePath : path to a file
     * @throws RuntimeException : IO exception when writing
     */
    public void save (String filePath) throws RuntimeException
    {
        this.m_document.save(filePath);
    }

    /**
     * Returns a human-readable string representing the ReadOnlyDocument.
     * @return 'ReadOnlyDocument(data : _data_)'
     */
    @Override
    public String toString()
    {
        return "ReadOnlyDocument(data : " + this.m_document.getData() + ")";
    }
}
