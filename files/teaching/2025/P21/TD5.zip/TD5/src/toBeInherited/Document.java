package toBeInherited;

import java.io.FileWriter;
import java.io.IOException;

/**
 * This class modelises a document data stored as strings.
 * It allows to append and save data into files.
 * @author Romain PERRIN
 */
public class Document
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private StringBuilder m_data;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a new empty Document.
     */
    public Document ()
    {
        this.m_data = new StringBuilder();
    }

    //--------------------------------------------------------------------------
    // ACCESSORS
    //--------------------------------------------------------------------------

    /**
     * Getter for the data attribute.
     * @return the currently stored data
     */
    public String getData ()
    {
        return this.m_data.toString();
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Appends the given data to the Document.
     * @param newData : new data to append
     */
    public void append (String newData)
    {
        this.m_data.append(newData);
    }

    /**
     * Saves the stored data to a given file.
     * @param filePath : path to the output file
     * @throws RuntimeException : error when writing to the file
     */
    public void save (String filePath) throws RuntimeException
    {
        try
        {
            FileWriter output = new FileWriter(filePath, true);
            output.append(this.m_data);
            output.close();
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     * Returns a human-readable string representing the Document.
     * @return Document(data : _data_)
     */
    @Override
    public String toString ()
    {
        return "Document(data : " + this.m_data.toString() + ")";
    }
}
