package toBeInherited;

/**
 * This class modelises a simple bank account with a balance.
 * It allows the transfer of money but forbids a negative balance.
 * @author Romain PERRIN
 */
public class Account
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private double m_balance;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Account with a given balance.
     * @param initialBalance : initial account balance, must be >= 0
     */
    public Account (double initialBalance)
    {
        this.m_balance = initialBalance >= 0 ? initialBalance : 0;
    }

    /**
     * Default constructor, instantiates a new Account with a balance of 0.
     */
    public Account ()
    {
        this.m_balance = 0;
    }

    //--------------------------------------------------------------------------
    // ACCESSORS
    //--------------------------------------------------------------------------

    /**
     * Getter for the balance attribute.
     * @return the account's current balance
     */
    public double getBalance ()
    {
        return m_balance;
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Checks whether a transfer from the current Account to the recipient Account is valid.
     * For the transfer to be valid, the recipient must not be a null reference, the current Account
     * must have a current balance of at least the amount of the transfer and the amount must be strictly positive.
     * @param amount : the amount to transfer from this to recipient
     * @param recipient : a reference to another Account
     * @return true if the transfer is valid, false otherwise
     */
    public boolean transferIsValid (double amount, Account recipient)
    {
        return amount > 0 && recipient != null && this.getBalance() >= amount;
    }

    /**
     * Processes the transfer from this Account to the recipient Account (if valid).
     * @param amount : the amount to transfer
     * @param recipient : a reference to another Account
     * @return true if the transfer has been completed, false otherwise
     */
    public boolean transfer (double amount, Account recipient)
    {
        boolean validity = this.transferIsValid(amount, recipient);
        if (validity)
        {
            this.m_balance -= amount;
            recipient.m_balance += amount;
        }
        return validity;
    }

    /**
     * Returns a human-readable string representing the Account.
     * @return 'Account(balance : _balance_)'
     */
    @Override
    public String toString ()
    {
        return "Account(balance : " + this.m_balance + ")";
    }
}
