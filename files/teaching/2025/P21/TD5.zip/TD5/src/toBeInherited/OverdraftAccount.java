package toBeInherited;

/**
 * This class modelises a subclass of Account, the OverdraftAccount.
 * It functions the same as a classic Account but allows to define a maximal overdraft, enabling a negative balance.
 * @author Romain PERRIN
 */
public class OverdraftAccount extends Account
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private double m_maximalOverdraft;

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new OverdraftAccount.
     * @param initialBalance : the initial balance
     * @param maximalOverdraft : the maximal overdraft allowed
     */
    public OverdraftAccount (double initialBalance, double maximalOverdraft)
    {
        super (initialBalance);
        this.m_maximalOverdraft = maximalOverdraft;
    }

    //--------------------------------------------------------------------------
    // ACCESSORS
    //--------------------------------------------------------------------------

    /**
     * Getter for the maximal overdraft attribute.
     * @return the OverdraftAccount's current maximal overdraft
     */
    public double getMaximalOverdraft ()
    {
        return this.m_maximalOverdraft;
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Checks whether a transfer from the current Account to the recipient Account is valid.
     * For a transfer to be valid, the recipient must not be null, the current Account must have a current balance
     * of at least the amount (accounting for the potential overdraft) and the amount must be strictly positive.
     * @param amount : the amount to transfer from this to recipient
     * @param recipient : a reference to another Account
     * @return true if the transfer is valid, false otherwise
     */
    @Override
    public boolean transferIsValid(double amount, Account recipient)
    {
        return amount > 0 && recipient != null && amount <= this.getBalance() + this.m_maximalOverdraft;
    }

    /**
     * Returns a human-readable string representing the OverdraftAccount.
     * @return 'OverdraftAccount(balance : _balance_, maximalOverdraft : _maximalOverdraft_)'
     */
    @Override
    public String toString()
    {
        return "OverdraftAccount(balance : " + this.getBalance() + ", maximalOverdraft : " + this.m_maximalOverdraft + ")";
    }
}
