package toBeInherited;

/**
 * This interface is used to compute the perimeter of geometrical shapes.
 * @author Romain PERRIN
 */
public interface PerimeterInterface
{
    double getPerimeter();
}
