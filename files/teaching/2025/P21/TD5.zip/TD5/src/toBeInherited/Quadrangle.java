package toBeInherited;

import java.util.Arrays;

/**
 * This class modelises the concept of quadrangle i.e. a polygon having 4 sides with modifiable values.
 * @author Romain PERRIN
 */
public class Quadrangle implements PerimeterInterface
{
    //--------------------------------------------------------------------------
    // ATTRIBUTES
    //--------------------------------------------------------------------------

    private double[] m_sidesLength = {0, 0, 0, 0};

    //--------------------------------------------------------------------------
    // CONSTRUCTORS
    //--------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Quadrangle with given sides' lengths
     * @param length1 : length of the first side
     * @param length2 : length of the second side
     * @param length3 : length of the third side
     * @param length4 : length of the fourth side
     */
    public Quadrangle (double length1, double length2, double length3, double length4)
    {
        m_sidesLength[0] = length1;
        m_sidesLength[1] = length2;
        m_sidesLength[2] = length3;
        m_sidesLength[3] = length4;
    }

    //--------------------------------------------------------------------------
    // ACCESSORS
    //--------------------------------------------------------------------------

    /**
     * Setter for the side length.
     * @param sideIndex : index of the side (in [0,3])
     * @param length : length of the side
     * @throws IndexOutOfBoundsException : if sideIndex is outside [0,3]
     */
    public void setSideLength (int sideIndex, double length) throws IndexOutOfBoundsException
    {
        if (sideIndex < 0 || sideIndex > 3)
        {
            throw new IndexOutOfBoundsException("The side index should be between 0 and 3.");
        }
        this.m_sidesLength[sideIndex] = length;
    }

    /**
     * Getter for the side index.
     * @param sideIndex : index of the side (in [0,3])
     * @return the length of the given side index
     * @throws IndexOutOfBoundsException : if sideIndex is outside [0,3]
     */
    public double getSideLength (int sideIndex) throws IndexOutOfBoundsException
    {
        if (sideIndex < 0 || sideIndex > 3)
        {
            throw new IndexOutOfBoundsException("The side index should be between 0 and 3.");
        }
        return this.m_sidesLength[sideIndex];
    }

    //--------------------------------------------------------------------------
    // METHODS
    //--------------------------------------------------------------------------

    /**
     * Computes and returns the Quadrangle's perimeter (sum of all sides).
     * @return the Quadrangle perimeter
     */
    @Override
    public double getPerimeter ()
    {
        return Arrays.stream(this.m_sidesLength).sum();
    }

    /**
     * Returns a human-readable string representing the Quadrangle.
     * @return Quadrangle(_length1_, _length2_, _length3_, _length4_)
     */
    @Override
    public String toString()
    {
        return "Quadrangle(" + this.m_sidesLength[0] + ", " + this.m_sidesLength[1] + ", " + this.m_sidesLength[2] + ", " + this.m_sidesLength[3] + ")";
    }
}
