package toBeInherited;

/**
 * This class represents a diamond, a quadrangle with four equal sides.
 * @author Romain PERRIN
 */
public class Diamond implements PerimeterInterface
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private double m_length;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    public Diamond (double length)
    {
        this.m_length = length;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Getter for length attribute.
     * @return the sides' length
     */
    public double getLength ()
    {
        return m_length;
    }

    /**
     * Setter for the length attribute.
     * @param length : new sides' length
     */
    public void setLength (double length)
    {
        this.m_length = length;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Computes the perimeter of the diamond.
     * @return the perimeter
     */
    @Override
    public double getPerimeter()
    {
        return this.m_length * 4;
    }

    /**
     * Returns a human-readable string representing the diamond.
     * @return Diamond(_length_)
     */
    @Override
    public String toString()
    {
        return "Diamond(" + this.m_length + ")";
    }
}
