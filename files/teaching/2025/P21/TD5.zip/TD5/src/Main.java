import canteen.CanteenAccount;
import canteen.CanteenRevenue;
import canteen.DiscountCanteenAccount;
import container.MyList;
import container.MySet;
import file.FileAccess;
import file.PermissionMode;
import toBeInherited.*;

import java.util.ArrayList;

/**
 * Main class.
 * @author Romain PERRIN
 */
public class Main
{
    /**
     * Runs a demo of the first exercise.
     */
    public static void Exercise1 ()
    {
        Account a1 = new Account(100);
        Account a2 = new Account(20);
        OverdraftAccount a3 = new OverdraftAccount(50, 100);
        System.out.println(a1 + "\n" + a2 + "\n" + a3);
        System.out.println("transfer a2 -> a1 (+20) : " + a2.transfer(20, a1));
        System.out.println(a1 + "\n" + a2 + "\n" + a3);
        System.out.println("transfer a3 -> a1 (+100) : " + a3.transfer(100, a1));
        System.out.println(a1 + "\n" + a2 + "\n" + a3);
        System.out.println("transfer a2 -> a3 (+10) : " + a2.transfer(10, a3));
        System.out.println(a1 + "\n" + a2 + "\n" + a3);
        System.out.println("transfer a3 -> a2 (+75) : " + a3.transfer(75, a2));
        System.out.println(a1 + "\n" + a2 + "\n" + a3);

        Document doc = new Document();
        doc.append("data 1");
        doc.append("\ndata 2");
        System.out.println("doc : " + doc.getData());
        ReadOnlyDocument rdoc = new ReadOnlyDocument(doc);
        doc.append("\ndata3");
        System.out.println("rdoc : " + rdoc.getData());

        Quadrangle q1 = new Quadrangle(1, 1, 1, 1);
        System.out.println("q1 : " + q1 + "\nq1.getPerimeter() : " + q1.getPerimeter());
        Diamond q2 = new Diamond(1);
        System.out.println("q2 : " + q2 + "\nq2.getPerimeter() : " + q2.getPerimeter());
    }

    /**
     * Runs a demo of the second exercise.
     */
    public static void Exercise2 ()
    {
        MyList l = new MyList();
        l.add("Bob");
        l.add("Alice");
        l.add("Bob");
        l.add("Charles");
        System.out.println(l);
        System.out.println("l.contains('Bob') : " + l.contains("Bob"));
        System.out.println("l.contains('Alice') : " + l.contains("Alice"));
        System.out.println("l.contains('Charles') : " + l.contains("Charles"));
        System.out.println("l.contains('Lucie') : " + l.contains("Lucie"));
        System.out.println("l.get(0) : " + l.get(0));
        System.out.println("l.get(1) : " + l.get(1));
        System.out.println("l.get(2) : " + l.get(2));
        System.out.println("l.get(3) : " + l.get(3));

        MySet s = new MySet();
        s.add("Bob");
        s.add("Alice");
        s.add("Bob");
        s.add("Charles");
        System.out.println(s);
        System.out.println("s.contains('Bob') : " + s.contains("Bob"));
        System.out.println("s.contains('Alice') : " + s.contains("Alice"));
        System.out.println("s.contains('Charles') : " + s.contains("Charles"));
        System.out.println("s.contains('Lucie') : " + s.contains("Lucie"));
    }

    /**
     * Runs a demo for the third exercise.
     */
    public static void Exercice3 ()
    {
        double mealPrice = 3.00;
        double discountMealPrice = 1.00;
        ArrayList<CanteenAccount> students = new ArrayList<>(4);
        students.add(new CanteenAccount(mealPrice));
        students.add(new DiscountCanteenAccount(mealPrice, discountMealPrice));
        students.add(new CanteenAccount(mealPrice));
        students.add(new DiscountCanteenAccount(mealPrice, discountMealPrice));
        int[] lunchesBought = new int[4];
        lunchesBought[0] = 6;   // 6 * mealPrice
        lunchesBought[1] = 2;   // 2 * discountMealPrice
        lunchesBought[2] = 4;   // 4 * mealPrice
        lunchesBought[3] = 8;   // 3 * discountMealPrice + 5 * mealPrice
        for (int i = 0; i < 4; i++)
        {
            System.out.println("Student : " + students.get(i) + ", bought meals : " + lunchesBought[i]);
        }
        // canteen revenue : (6 + 4 + 5 = 15) mealPrice + (2 + 3 = 5) discountMealPrice (= 50€)
        CanteenRevenue revenue = new CanteenRevenue(students);
        System.out.println("Canteen revenue : " + revenue.lunchRevenue(lunchesBought));
    }

    /**
     * Runs a demo for the fourth exercise.
     * @throws Exception : IO exception when opening the file
     */
    public static void Exercise4 () throws Exception
    {
        FileAccess fa = new FileAccess("fichier");
        System.out.println("écriture seule : ");
        try
        {
            fa.write(PermissionMode.WRITE_ONLY, "c'est bientôt terminé\n");
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("lecture seule : " + fa.read(PermissionMode.READ_ONLY));
        System.out.println("Exec fichier : ");
        fa.execute(PermissionMode.READ_EXECUTE);
    }

    /**
     * Main method
     * @param args : command-line arguments
     * @throws Exception : runtime exception depending on the exercise (see Exercice1-4 methods).
     */
    public static void main (String[] args) throws Exception
    {
        Exercise1();
        Exercise2();
        Exercice3();
        Exercise4();
    }
}