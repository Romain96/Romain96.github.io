package comparableImplementations;

import org.junit.Test;
import org.junit.Assert.*;
import static org.junit.Assert.assertSame;

import java.util.ArrayList;

/**
 * Unit tests for the Comparable implementations in the comparableImplementations package.
 * @author Romain PERRIN
 */
public class ComparableTests
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    @Test
    public void test_sortChickenFoxViper ()
    {
        ChickenFoxViper chicken = new ChickenFoxViper(0);
        ChickenFoxViper fox = new ChickenFoxViper(1);
        ChickenFoxViper viper = new ChickenFoxViper(2);
        ArrayList<ChickenFoxViper> list = new ArrayList<ChickenFoxViper>(4);
        list.add(chicken);
        list.add(viper);
        list.add(fox);
        list.add(viper);
        list.sort(null);
        assertSame(chicken, list.getFirst());
        assertSame(fox, list.get(1));
        assertSame(viper, list.get(2));
        assertSame(viper, list.get(3));
    }

    @Test
    public void test_sortMyInteger1 ()
    {
        MyInteger1 one = new MyInteger1(1);
        MyInteger1 two = new MyInteger1(2);
        MyInteger1 three = new MyInteger1(3);
        MyInteger1 four = new MyInteger1(4);
        ArrayList<MyInteger1> list = new ArrayList<MyInteger1>();
        list.add(three);
        list.add(four);
        list.add(one);
        list.add(two);
        list.sort(null);
        assertSame(one, list.getFirst());
        assertSame(two, list.get(1));
        assertSame(three, list.get(2));
        assertSame(four, list.get(3));
    }

    @Test
    public void test_sortMyInteger2 ()
    {
        MyInteger2 one = new MyInteger2(1);
        MyInteger2 two = new MyInteger2(2);
        MyInteger2 three = new MyInteger2(3);
        MyInteger2 four = new MyInteger2(4);
        ArrayList<MyInteger2> list = new ArrayList<MyInteger2>();
        list.add(four);
        list.add(three);
        list.add(one);
        list.add(two);
        list.sort(null);
        assertSame(four, list.getFirst());
        assertSame(three, list.get(1));
        assertSame(two, list.get(2));
        assertSame(one, list.get(3));
    }

    @Test
    public void test_sortMyInteger3 ()
    {
        MyInteger3 one = new MyInteger3(1);
        MyInteger3 two = new MyInteger3(2);
        MyInteger3 three = new MyInteger3(3);
        MyInteger3 four = new MyInteger3(4);
        ArrayList<MyInteger3> list = new ArrayList<MyInteger3>();
        list.add(four);
        list.add(three);
        list.add(one);
        list.add(two);
        list.sort(null);
        assertSame(three, list.getFirst());
        assertSame(four, list.get(1));
        assertSame(one, list.get(2));
        assertSame(two, list.get(3));
    }
}
