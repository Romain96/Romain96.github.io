package date;

import org.junit.Test;
import org.junit.Assert.*;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import java.util.ArrayList;

/**
 * Unit test class for Year, Month and Date of the date package.
 * @author Romain PERRIN
 */
public class DateTests
{
    @Test
    public void test_sortYear ()
    {
        Year y1 = new Year(2020);
        Year y2 = new Year(2021);
        Year y3 = new Year(2025);
        Year y4 = new Year(2026);
        ArrayList<Year> list = new ArrayList<Year>();
        list.add(y4);
        list.add(y3);
        list.add(y1);
        list.add(y2);
        list.sort(null);
        assertSame(y1, list.getFirst());
        assertSame(y2, list.get(1));
        assertSame(y3, list.get(2));
        assertSame(y4, list.get(3));
    }

    @Test
    public void test_sortMonth () throws Exception
    {
        Month m1 = new Month(3);
        Month m2 = new Month(4);
        Month m3 = new Month(8);
        Month m4 = new Month(11);
        ArrayList<Month> list = new ArrayList<Month>();
        list.add(m4);
        list.add(m3);
        list.add(m1);
        list.add(m2);
        list.sort(null);
        assertSame(m1, list.getFirst());
        assertSame(m2, list.get(1));
        assertSame(m3, list.get(2));
        assertSame(m4, list.get(3));
    }

    @Test
    public void test_sortDate () throws Exception
    {
        Date d1 = new Date(2020, 11, 5);
        Date d2 = new Date(2020, 12, 6);
        Date d3 = new Date(2026, 3, 18);
        Date d4 = new Date(2026, 3, 19);
        ArrayList<Date> list = new ArrayList<Date>();
        list.add(d4);
        list.add(d3);
        list.add(d1);
        list.add(d2);
        list.sort(null);
        assertSame(d1, list.getFirst());
        assertSame(d2, list.get(1));
        assertSame(d3, list.get(2));
        assertSame(d4, list.get(3));
    }

    @Test
    public void test_equalsDate () throws Exception
    {
        Date d1 = new Date(2026, 3, 18);
        Date d2 = new Date(2026, 3, 18);
        Date d3 = new Date(2026, 3, 19);
        assertTrue(d1.equals(d2));
        assertFalse(d1.equals(d3));
        assertFalse(d2.equals(d3));
    }

    @Test
    public void test_equalsYear ()
    {
        Year d1 = new Year(2026);
        Year d2 = new Year(2026);
        Year d3 = new Year(2025);
        assertTrue(d1.equals(d2));
        assertFalse(d1.equals(d3));
        assertFalse(d2.equals(d3));
    }

    @Test
    public void test_equalsMonth () throws Exception
    {
        Month d1 = new Month(3);
        Month d2 = new Month(3);
        Month d3 = new Month(4);
        assertTrue(d1.equals(d2));
        assertFalse(d1.equals(d3));
        assertFalse(d2.equals(d3));
    }

    @Test
    public void test_isBeforeDate () throws Exception
    {
        Date d1 = new Date(2026, 3, 18);
        Date d2 = new Date(2026, 3, 18);
        Date d3 = new Date(2026, 3, 19);
        assertFalse(d1.isBefore(d2));
        assertTrue(d1.isBefore(d3));
        assertTrue(d2.isBefore(d3));
    }

    @Test
    public void test_isBeforeMonth () throws Exception
    {
        Month d1 = new Month(3);
        Month d2 = new Month(3);
        Month d3 = new Month(4);
        assertFalse(d1.isBefore(d2));
        assertTrue(d1.isBefore(d3));
        assertTrue(d2.isBefore(d3));
    }

    @Test
    public void test_isBeforeYear ()
    {
        Year d1 = new Year(2025);
        Year d2 = new Year(2025);
        Year d3 = new Year(2026);
        assertFalse(d1.isBefore(d2));
        assertTrue(d1.isBefore(d3));
        assertTrue(d2.isBefore(d3));
    }
}
