package dialog.output;

import java.io.FileWriter;
import java.io.IOException;

/**
 * This class represents the dialog output using a file.
 * @author Romain PERRIN
 */
public class FileOutput implements TextOutput
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_filePath;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new FileOutput.
     * @param filePath : path to the output file
     */
    public FileOutput (String filePath)
    {
        m_filePath = filePath;
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns a human-readable string representing the class.
     * @return a string
     */
    @Override
    public String toString ()
    {
        return "FileOutput";
    }

    /**
     * Writes the given text to the given file (at initialization).
     * @param text : text to write
     * @throws RuntimeException : in case of writing error
     */
    @Override
    public void write (String text)
    {
        try
        {
            FileWriter output = new FileWriter(m_filePath, true);
            output.append(text);
            output.close();
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
}
