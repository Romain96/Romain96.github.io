package dialog.output;

import javax.swing.*;
import java.awt.*;

/**
 * This class modelises a very simple GUI to display a simple text.
 * @author Romain PERRIN
 */
public class GraphicalOutput extends JFrame implements TextOutput
{
    private JTextArea m_text;
    private JButton m_special;

    /**
     * Default constructor, instantiates a new GraphicalOutput
     */
    public GraphicalOutput()
    {
        setTitle("Best dialog ever");
        setSize(new Dimension(800, 600));
        setResizable(false);
        m_text = new JTextArea("test");
        m_special = new JButton("Erase text");
        m_special.addActionListener(e -> m_text.setText("test"));
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(m_text);
        panel.add(m_special);
        setContentPane(panel);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void write(String text)
    {
        m_text.append(text);
        repaint();
    }
}
