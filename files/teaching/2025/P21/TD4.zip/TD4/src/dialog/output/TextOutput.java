package dialog.output;

/**
 * This interface represents the dialog output.
 * @author Romain PERRIN
 */
public interface TextOutput
{
    /**
     * Writes the text to the designated output.
     * @param text : text to write
     */
    void write (String text);
}
