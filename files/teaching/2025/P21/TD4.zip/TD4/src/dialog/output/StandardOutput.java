package dialog.output;

/**
 * This class modelises a write operation on the standard output.
 * @author Romain PERRIN
 */
public class StandardOutput implements TextOutput
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a new StandardOutput.
     */
    public StandardOutput ()
    {

    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns a human-readable string representing the class.
     * @return a string
     */
    @Override
    public String toString ()
    {
        return "StandardOutput";
    }

    /**
     * Writes the given text on the standard output.
     * @param text : text to write
     */
    @Override
    public void write (String text)
    {
        System.out.print(text);
    }
}
