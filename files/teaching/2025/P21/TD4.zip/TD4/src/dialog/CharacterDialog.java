package dialog;

import dialog.output.TextOutput;

/**
 * This class represents a character dialog with the user interaction.
 * @author Romain PERRIN
 */
public class CharacterDialog
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_firstName;
    private TextOutput m_output;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new CharacterDialog.
     * @param firstName : the character's name
     * @param output : an output file
     */
    public CharacterDialog (String firstName, TextOutput output)
    {
        m_firstName = firstName;
        m_output = output;
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Writes a string representing the action of meeting someone.
     */
    public void meetSomeone ()
    {
        m_output.write("Hello ! How are you ?\n");
    }

    /**
     * Writes a string representing the action of introducing oneself.
     */
    public void introduceYourself ()
    {
        m_output.write("My name is " + m_firstName + ".\n");
    }

    /**
     * Writes a string representing the action of attacking someone.
     */
    public void attack ()
    {
        m_output.write("Attack !\n");
    }

    /**
     * Returns a human-readable string representing the class.
     * @return a string
     */
    @Override
    public String toString ()
    {
        return m_firstName;
    }
}
