import date.Date;
import dialog.CharacterDialog;
import dialog.output.FileOutput;
import dialog.output.GraphicalOutput;
import dialog.output.StandardOutput;
import palindrome.*;
import comparableImplementations.*;

import java.util.Scanner;

/**
 * Main class.
 * @author Romain PERRIN
 */
public class Main
{
    /**
     * Exercise 1 : palindrome
     */
    public static void Exercise1 ()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Type a word to check for palindrome :");
        CharSequence input = scan.nextLine();
        System.out.println("The word '" + input + "' is a palindrome : " + CharSequencePalindrome.isPalindrome(input) + ".");
    }

    /**
     * Exercice 2 : Comparable interface
     */
    public static void Exercise2 ()
    {
        System.out.println("See src/comparableImplementations/*.java");
        System.out.println("Run tests/comparableImplementations/ComparableTests.java");
        ChickenFoxViper chicken = new ChickenFoxViper(0);
        ChickenFoxViper fox = new ChickenFoxViper(1);
        ChickenFoxViper viper = new ChickenFoxViper(2);
        ChickenFoxViper unknkown = new ChickenFoxViper(3);
        System.out.println("ChickenFoxViper(0) = " + chicken);
        System.out.println("ChickenFoxViper(1) = " + fox);
        System.out.println("ChickenFoxViper(2) = " + viper);
        System.out.println("ChickenFoxViper(3) = " + unknkown);
        MyInteger1 int1 = new MyInteger1(1);
        MyInteger2 int2 = new MyInteger2(1);
        MyInteger3 int3 = new MyInteger3(1);
        System.out.println("MyInteger1(1) = " + int1);
        System.out.println("MyInteger2(1) = " + int2);
        System.out.println("MyInteger3(1) = " + int3);
    }

    /**
     * Exercise 3 : Dialog
     */
    public static void Exercise3 ()
    {
        CharacterDialog dialog1 = new CharacterDialog("Jean", new StandardOutput());
        dialog1.introduceYourself();
        dialog1.meetSomeone();
        dialog1.attack();
        CharacterDialog dialog2 = new CharacterDialog("Jeanne", new FileOutput("dialog.txt"));
        dialog2.introduceYourself();
        dialog2.meetSomeone();
        dialog2.attack();
        CharacterDialog dialog3 = new CharacterDialog("Lucie", new GraphicalOutput());
        dialog3.introduceYourself();
        dialog3.meetSomeone();
        dialog3.attack();
    }

    /**
     * Exercice 4 : Date
     * @throws IllegalArgumentException : if date is not valid
     */
    public static void Exercise4 () throws IllegalArgumentException
    {
        Date today;
        while (true)
        {
            Scanner scan = new Scanner(System.in);
            System.out.print("Enter the year : ");
            int year = scan.nextInt();
            System.out.print("Enter the month : ");
            int month = scan.nextInt();
            System.out.print("Enter the day : ");
            int day = scan.nextInt();
            try
            {
                today = new Date(year, month, day);
                System.out.print("According to the user, today's date is " + today);
                break;
            }
            catch (Exception e)
            {
                System.out.println("Invalid date parameters : " + e.getMessage());
            }
        }
    }

    /**
     * Main method
     * @param args : command-line arguments (ignored)
     * @throws IllegalArgumentException : depending on the exercice run
     */
    public static void main (String[] args) throws IllegalArgumentException
    {
        Exercise1();
        Exercise2();
        Exercise3();
        Exercise4();
    }
}