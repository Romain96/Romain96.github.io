package date;

/**
 * This class represents a year given as a number.
 * @author Romain PERRIN
 */
public class Year implements Comparable<Year>
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private final int m_year;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Year.
     * @param year : the year number
     */
    public Year (int year)
    {
        m_year = year;
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Checks whether the current year is a leap year (366 days instead of 365).
     * @return true if the current year is a leap year, false otherwise
     */
    public boolean isLeapYear ()
    {
        return (m_year % 4 == 0 && m_year % 100 != 0) || (m_year % 400 == 0);
    }

    /**
     * Converts the Year into an integer representing it.
     * @return the year as an integer
     */
    public int toInt ()
    {
        return m_year;
    }

    /**
     * Returns the number of days in the current year.
     * @return the number of days
     */
    public int daysNumber ()
    {
        return isLeapYear() ? 366 : 365;
    }

    /**
     * Compares the current year to another reference and checks whether the current year is strictly inferior to the other one.
     * @param other : another reference of Year
     * @return true if this is strictly inferior to other, false otherwise
     */
    public boolean isBefore (Year other)
    {
        return this.m_year < other.m_year;
    }

    /**
     * Compares the current year to another reference and checks whether the two are equal.
     * @param other : another reference of Year
     * @return true if this == other, false otherwise
     */
    public boolean equals (Year other)
    {
        return this.m_year == other.m_year;
    }

    /**
     * Returns a human-readable string representing the Year object.
     * @return a string representing the Year
     */
    @Override
    public String toString()
    {
        return "Year ( " + m_year + " )";
    }

    /**
     * Compares the current reference to another reference.
     * @param other : the reference object with which to compare.
     * @return true if both objects are Year and of the same value
     */
    @Override
    public boolean equals (Object other)
    {
        if (other == null || other.getClass() != this.getClass())
        {
            return false;
        }
        Year y = (Year) other;  // downcast
        return this.m_year == y.m_year;
    }

    /**
     * Returns a hash of the current Year.
     * @return a hash based on the year
     */
    @Override
    public int hashCode()
    {
        return m_year;
    }

    /**
     * Compares the current reference to another reference.
     * @param other : another reference of Year
     * @return -1 if this is strictly inferior to other, 0 if this equals other and 1 if this is strictly superior to other
     * @throws NullPointerException : if other is null
     */
    @Override
    public int compareTo (Year other)
    {
        if (other == null)
        {
            throw new NullPointerException();
        }
        if (this.isBefore(other))
        {
            return -1;
        }
        else if (other.isBefore(this))
        {
            return 1;
        }
        return 0;   // this == other
    }
}
