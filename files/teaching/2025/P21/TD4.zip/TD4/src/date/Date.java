package date;

import java.util.Objects;

/**
 * This class represents a date composed of a day, a month and a year.
 * @author Romain PERRIN
 */
public class Date implements Comparable<Date>
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private final int m_day;
    private final Month m_month;
    private final Year m_year;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Date.
     * @param year : numerical year
     * @param month : numerical month (1-12)
     * @param day : numerical day (1-31*)
     * @throws IllegalArgumentException : is the day of month is invalid
     */
    public Date (int year, int month, int day) throws IllegalArgumentException
    {
        m_year = new Year(year);
        m_month = new Month(month);
        if (day >= 1 && day <= m_month.daysNumber(m_year))
        {
            m_day = day;
        }
        else
        {
            throw new IllegalArgumentException("Day should be between 1 and " + m_month.daysNumber(m_year) + " for this year.");
        }
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns a human-readable string representing the Date.
     * @return a string representing the date
     */
    @Override
    public String toString()
    {
        return "Date ( " + m_year.toInt() + "/" + m_month.toInt() + "/" + m_day + " )";
    }

    /**
     * Returns a hash code representing the Date.
     * @return a hash
     */
    @Override
    public int hashCode()
    {
        return Objects.hash(m_day, m_month.toInt(), m_year.toInt());
    }

    /**
     * Checks whether a date is equal to another.
     * @param other : the reference object with which to compare.
     * @return true if both reference are Date of equal values.
     */
    @Override
    public boolean equals (Object other)
    {
        if (other == null || other.getClass() != this.getClass())
        {
            return false;
        }
        Date d = (Date) other;  // downcast
        return this.m_year.equals(d.m_year) && this.m_month.equals(d.m_month) && m_day == d.m_day;
    }

    /**
     * Compares two references of Date and checks whether the current one represents a Date strictly before the second.
     * @param other : another reference of Date
     * @return true if this is strictly inferior to other, false otherwise
     */
    public boolean isBefore (Date other)
    {
        return this.m_year.isBefore(other.m_year)
                || (this.m_year.equals(other.m_year) && this.m_month.isBefore(other.m_month))
                || (this.m_year.equals(other.m_year) && this.m_month.equals(other.m_month) && this.m_day < other.m_day);
    }

    /**
     * Compares two references of Date.
     * @param other : another Date
     * @return -1 if this is strictly inferior to other, 0 if this equals other and 1 if this is strictly superior to other
     * @throws NullPointerException : if other is null
     */
    @Override
    public int compareTo (Date other)
    {
        if (other == null)
        {
            throw new NullPointerException();
        }
        if (this.isBefore(other))
        {
            return -1;
        }
        else if (other.isBefore(this))
        {
            return 1;
        }
        return 0;   // this == other
    }
}
