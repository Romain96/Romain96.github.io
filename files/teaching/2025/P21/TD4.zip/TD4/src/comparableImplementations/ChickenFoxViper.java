package comparableImplementations;

/**
 * This class modelises the game of chicken-fox-viper.
 * The chicken eats the viper, the fox eats the chicken and the viper eats the fox.
 * @author Romain PERRIN
 */
public class ChickenFoxViper implements Comparable<ChickenFoxViper>
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private int m_animalNumber;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    public ChickenFoxViper (int animalNumber)
    {
        m_animalNumber = animalNumber;
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------


    /**
     * Returns a human-readable string representing the current animal.
     * @return the current animal in a string
     */
    @Override
    public String toString()
    {
        return switch (m_animalNumber)
        {
            case 0 -> "chicken";
            case 1 -> "fox";
            case 2 -> "viper";
            default -> "unknown animal";
        };
    }

    /**
     * The relation is "this eats the other".
     * @param other : the compared animal
     * @return 0 if both references are identical, -1 if this gets eaten by other and 1 if this eats other
     */
    @Override
    public int compareTo (ChickenFoxViper other)
    {
        if (other == null)
        {
            throw new NullPointerException();
        }
        int diff = this.m_animalNumber - other.m_animalNumber;
        if (diff == 0)
        {
            return 0;
        }
        else if (diff == 1 || diff == -2)
        {
            return 1;
        }
        return -1;
    }
}
