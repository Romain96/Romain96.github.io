package comparableImplementations;

/**
 * Second comparable integer implementation.
 * @author Romain PERRIN
 */
public class MyInteger2 implements Comparable<MyInteger2>
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private int m_integer;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new MyInteger2
     * @param integer : integer to store
     */
    public MyInteger2 (int integer)
    {
        m_integer = integer;
    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    /**
     * Getter for the integer attribute.
     * @return the current value of integer
     */
    public int getInteger ()
    {
        return m_integer;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns a human-readable string representing the integer.
     * @return a string representing the integer
     */
    @Override
    public String toString ()
    {
        return "MyInteger2 ( " + m_integer + " )";
    }

    /**
     * Compares this reference to another reference.
     * @param other : other reference
     * @return -2 if this is strictly inferior to other, 0 if this equals other and 2 if this is strictly superior to other
     */
    @Override
    public int compareTo(MyInteger2 other)
    {
        if (other == null)
        {
            throw  new NullPointerException();
        }
        if (this.m_integer > other.m_integer)
        {
            return -2;
        }
        else if (this.m_integer < other.m_integer)
        {
            return 2;
        }
        return 0;   // this == other
    }
}
