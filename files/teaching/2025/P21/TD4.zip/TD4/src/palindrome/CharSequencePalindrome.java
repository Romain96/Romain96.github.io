package palindrome;

/**
 * This class represents an implementation of the concept of palindrome using a CharSequence.
 * @author Romain PERRIN
 * @see CharSequence
 */
public class CharSequencePalindrome
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    public CharSequencePalindrome ()
    {

    }

    //-------------------------------------------------------------------------
    // GETTERS & SETTERS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Checks whether a word is a palindrome.
     * @param word : a single word
     * @return true if the word is a palindrome, false otherwise
     */
    public static boolean isPalindrome (CharSequence word)
    {
        for (int i = 0; i < word.length() / 2; i++)
        {
            if (word.charAt(i) != word.charAt(word.length() - i - 1))
            {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns a human-readable string representing the class.
     * @return a string representing the class
     */
    @Override
    public String toString()
    {
        return "CharSequencePalindrome";
    }
}
