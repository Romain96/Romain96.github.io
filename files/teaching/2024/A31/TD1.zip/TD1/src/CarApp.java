import cars.Car;
import cars.CarFactory;

/**
 * Main class for the cars package demo.
 */
public class CarApp
{
    public static void main (String[] args)
    {
        Car subaru = CarFactory.createSubaru(100, 0);
        System.out.println("Subaru créée : " + subaru);
        Car jeep = CarFactory.createJeep(100, 0);
        System.out.println("Jeep créée : " + jeep);
        Car fiatMultipla = CarFactory.createFiatMultipla(100, 0);
        System.out.println("Fiat Multipla créée : " + fiatMultipla);

        subaru.refuel();
        System.out.println("Plein de la Subaru effectué " + subaru);
        jeep.refuel();
        System.out.println("Plein de la Jeep effectué : " + jeep);
        fiatMultipla.refuel();
        System.out.println("Plein de la Fiat Multipla effectué : " + fiatMultipla);

        System.out.println(subaru.honk());
        System.out.println(subaru.accelerate());
        System.out.println("Il reste " + subaru.getFuel() + "L d'essence");
        System.out.println(jeep.honk());
        System.out.println(jeep.accelerate());
        System.out.println("Il reste " + jeep.getFuel() + "L d'essence");
        System.out.println(fiatMultipla.honk());
        System.out.println(fiatMultipla.accelerate());
        System.out.println("Il reste " + fiatMultipla.getFuel() + "L d'essence");
    }
}
