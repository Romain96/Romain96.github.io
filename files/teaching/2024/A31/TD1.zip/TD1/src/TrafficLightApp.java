import trafficLights.*;

/**
 * Main class for TrafficLight demo.
 * @author Romain PERRIN
 */
public class TrafficLightApp
{
    /**
     * Main method for TrafficLight demo.
     * @param args : command-line arguments
     */
    public static void main (String[] args)
    {
        TrafficLight tl = new TrafficLight(false, TrafficLightColor.GREEN, new FrenchStrategy());
        System.out.println("création du feu : " + tl);
        tl.switchState();
        System.out.println("allumer le feu : " + tl);
        for (int i = 0; i < 5; i++)
        {
            tl.switchColor();
            System.out.println("passer à la couleur suivante : " + tl);
        }
        tl.setStrategy(new GermanStrategy(tl.getColor()));
        for (int i = 0; i < 5; i++)
        {
            tl.switchColor();
            System.out.println("passer à la couleur suivante : " + tl);
        }
    }
}