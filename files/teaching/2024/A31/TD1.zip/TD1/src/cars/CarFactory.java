package cars;

/**
 * This class implements the DP Factory and provides methods to instantiates Car objects.
 * @author Romain PERRIN
 * @see Car
 * @see Subaru
 * @see Jeep
 * @see FiatMultipla
 */
public class CarFactory
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    private CarFactory() {}

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Factory method to instantiates a new Subaru.
     * @param fuelMax : maximum amount of fuel in the trunk (in L).
     * @param fuel : current amount of fuel in the trunk (in L).
     * @return a new Car
     */
    public static Car createSubaru (double fuelMax, double fuel)
    {
        return new Subaru(fuelMax, fuel);
    }

    /**
     * Factory method to instantiates a new Jeep.
     * @param fuelMax : maximum amount of fuel in the trunk (in L).
     * @param fuel : current amount of fuel in the trunk (in L).
     * @return a new Car
     */
    public static Car createJeep (double fuelMax, double fuel)
    {
        return new Jeep(fuelMax, fuel);
    }

    /**
     * Factory method to instantiates a new Fiat Multipla.
     * @param fuelMax : maximum amount of fuel in the trunk (in L).
     * @param fuel : current amount of fuel in the trunk (in L).
     * @return a new Car
     */
    public static Car createFiatMultipla (double fuelMax, double fuel)
    {
        return new FiatMultipla(fuelMax, fuel);
    }
}
