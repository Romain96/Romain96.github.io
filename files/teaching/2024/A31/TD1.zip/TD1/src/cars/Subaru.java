package cars;

/**
 * This class represents a concrete Car object, a Subaru.
 * @author Romain PERRIN
 */
public class Subaru extends Car
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Subaru.
     * @param fuelMax : maximaum amount of fuel in the tank (in L).
     * @param fuel : current amount of fuel in the tank (in L).
     */
    public Subaru (double fuelMax, double fuel)
    {
        super (fuelMax, fuel);
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Accelerates the Subaru by removing 50L of fuel.
     * @return a string representing the acceleration noise.
     */
    @Override
    public String accelerate()
    {
        setFuel(getFuel() - 50);
        return "ZRRRRRRROUMMMMMMMMMM !";
    }

    /**
     * Honks for fun !
     * @return a string representing the honking noise.
     */
    @Override
    public String honk() {
        return "Turlututu !";
    }

    /**
     * Returns a human-readable string representing the Subaru.
     * @return Subaru(_fuel_/_fuelMax_)
     */
    @Override
    public String toString()
    {
        return "Subaru(" + getFuel() + "/" + getFuelMax() + ")";
    }
}
