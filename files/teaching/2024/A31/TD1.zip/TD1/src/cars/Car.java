package cars;

/**
 * This class represents the abstraction on the concept of car.
 * @author Romain PERRIN
 */
public abstract class Car
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private double m_fuelMax;
    private double m_fuel;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Car.
     * @param fuelMax : maximum amount of fuel in the tank (in L).
     * @param fuel : current level of fuel in the tank (in L).
     */
    public Car (double fuelMax, double fuel)
    {
        this.m_fuelMax = fuelMax;
        this.m_fuel = fuel;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Getter for the maximum fuel amount.
     * @return the current maximal fuel amount in the tank.
     */
    public double getFuelMax ()
    {
        return this.m_fuelMax;
    }

    /**
     * Getter for the fuel amount.
     * @return the current amount of fuel in the tank.
     */
    public double getFuel ()
    {
        return this.m_fuel;
    }

    /**
     * Setter for the maximum fuel amount in the tank.
     * @param fuelMax : new maximum fuel amount in the tank.
     */
    public void setFuelMax (double fuelMax)
    {
        this.m_fuelMax = fuelMax;
    }

    /**
     * Setter for the fuel amount in the tank.
     * @param fuel : new fuel amount in the trunk
     */
    public void setFuel (double fuel)
    {
        this.m_fuel = fuel;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Accelerates the car by removing some fuel.
     * @return a String representing the accelerating noise.
     */
    public abstract String accelerate ();

    /**
     * Honks for fun !
     * @return a String representing the car's own honk noise.
     */
    public abstract String honk ();

    /**
     * Refuels the car.
     */
    public void refuel ()
    {
        setFuel(getFuelMax());
    }

    /**
     * Returns a human-readable string representing the object.
     * @return Car(_fuel_/_fuelMax_)
     */
    @Override
    public String toString()
    {
        return "Car(" + getFuel() + "/" + getFuelMax() + ")";
    }
}
