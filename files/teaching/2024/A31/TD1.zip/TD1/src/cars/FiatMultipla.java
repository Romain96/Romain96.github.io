package cars;

/**
 * This class represents a concrete Car object, a Fiat Multipla.
 * @author Romain PERRIN
 */
public class FiatMultipla extends Car
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new FiatMultipla.
     * @param fuelMax : maximum amount of fuel in the tank (in L).
     * @param fuel : current amount of fuel in the tank (in L).
     */
    public FiatMultipla (double fuelMax, double fuel)
    {
        super(fuelMax, fuel);
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Accelerates the Fiat Multipla by removing 5L of fuel.
     * @return a string representing the Fiat Multipla's own accelerating noise.
     */
    @Override
    public String accelerate()
    {
        setFuel(getFuel() - 5);
        return "... mmmm ... !";
    }

    /**
     * Honks for fun !
     * @return a string representing the Fiat Multipla's own honking noise.
     */
    @Override
    public String honk()
    {
        return "Pu pu !";
    }

    /**
     * Returns a human-readable string representing the Fiat Multipla.
     * @return FiatMultipla(_fuel_/_fuelMax_)
     */
    @Override
    public String toString()
    {
        return "FiatMultipla(" + getFuel() + "/" + getFuelMax() + ")";
    }
}
