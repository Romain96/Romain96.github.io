package cars;

/**
 * This class represents a concrete Car object, a Jeep.
 * @author Romain PERRIN
 */
public class Jeep extends Car
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Jeep.
     * @param fuelMax : maximum amount of fuel in the tank (in L).
     * @param fuel : current amount of fuel in the tank (in L).
     */
    public Jeep (double fuelMax, double fuel)
    {
        super(fuelMax, fuel);
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Accelerates the Jeep by removing 10L of fuel.
     * @return a string representing the Jeep's own accelerating noise.
     */
    @Override
    public String accelerate()
    {
        setFuel(getFuel() - 10);
        return "Buuuuuup Buuuuuup !";
    }

    /**
     * Honks for fun !
     * @return a string representing the honking noise.
     */
    @Override
    public String honk()
    {
        return "Jiiiiiiiiionnnnnn !";
    }

    /**
     * Returns a human-readable string representing the Jeep.
     * @return Jeep(_fuel_/_fuelMax_)
     */
    @Override
    public String toString()
    {
        return "Jeep(" + getFuel() + "/" + getFuelMax() + ")";
    }
}
