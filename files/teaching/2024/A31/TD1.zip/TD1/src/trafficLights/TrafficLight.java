package trafficLights;

public class TrafficLight
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private boolean m_state;
    private TrafficLightColor m_color;
    private TrafficLightStrategy m_strategy;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new TrafficLight.
     * @param state : whether the traffic light is active or inactive
     * @param color : default color
     * @param strategy : color switching strategy
     * @see TrafficLightColor
     */
    public TrafficLight (boolean state, TrafficLightColor color, TrafficLightStrategy strategy)
    {
        this.m_state = state;
        this.m_color = color;
        this.m_strategy = strategy;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Getter for the state attribute.
     * @return the current TrafficLight state.
     */
    public boolean getState ()
    {
        return this.m_state;
    }

    /**
     * Getter for the color attribute.
     * @return the current TrafficLight color
     */
    public TrafficLightColor getColor ()
    {
        return this.m_color;
    }

    /**
     * Sets the color switching strategy
     * @param strategy : new strategy
     * @see TrafficLightStrategy
     */
    public void setStrategy (TrafficLightStrategy strategy)
    {
        this.m_strategy = strategy;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Switches the traffic light on/off
     */
    public void switchState ()
    {
        this.m_state = !this.m_state;
    }

    /**
     * Advances to the next color in the cycle.
     */
    public void switchColor ()
    {
        this.m_color = this.m_strategy.nextColor(this.m_color);
    }

    /**
     * Returns a human-readable string representing the TrafficLight.
     * @return TrafficLight(active: _active_, color: _color_)
     */
    @Override
    public String toString()
    {
        return "TrafficLight(active :" + this.m_state + ", color :" + this.m_color + ", strategy :" + this.m_strategy + ")";
    }
}
