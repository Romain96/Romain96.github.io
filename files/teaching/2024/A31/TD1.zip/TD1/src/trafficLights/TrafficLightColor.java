package trafficLights;

/**
 * This enum represents the different colors displayed by the TrafficLight.
 * @author Romain PERRIN
 */
public enum TrafficLightColor
{
    GREEN,
    ORANGE,
    RED;
}
