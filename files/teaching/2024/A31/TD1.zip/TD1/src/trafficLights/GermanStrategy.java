package trafficLights;

/**
 * This class implements the German color cycle for the traffic light (Green -> Orange -> Red -> Orange -> Green...).
 * Romain PERRIN
 */
public class GermanStrategy implements TrafficLightStrategy
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private TrafficLightColor m_previousColor;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new GermanStrategy.
     * @param previousColor : previous color in the traffic light
     */
    public GermanStrategy (TrafficLightColor previousColor)
    {
        this.m_previousColor = previousColor;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Getter for the previous color.
     * @return the previous color in the German cycle
     */
    public TrafficLightColor getPreviousColor ()
    {
        return this.m_previousColor;
    }

    /**
     * Setter for the previous color.
     * @param previousColor : the new previous color in the German cycle
     */
    public void setPreviousColor (TrafficLightColor previousColor)
    {
        this.m_previousColor = previousColor;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the next color in the cycle depending on the provided one.
     * @param currentColor : current traffic light color
     * @return the next color in the cycle
     */
    @Override
    public TrafficLightColor nextColor (TrafficLightColor currentColor)
    {
        switch (currentColor)
        {
            case GREEN, RED ->
            {
                setPreviousColor(currentColor);
                return TrafficLightColor.ORANGE;
            }
            case ORANGE ->
            {
                if (getPreviousColor() == TrafficLightColor.GREEN)
                {
                    setPreviousColor(currentColor);
                    return TrafficLightColor.RED;
                }
                else
                {
                    setPreviousColor(currentColor);
                    return TrafficLightColor.GREEN;
                }
            }
        }
        return currentColor;
    }

    /**
     * Returns a human-readable string representing the GermanStrategy
     * @return GermanStrategy
     */
    @Override
    public String toString()
    {
        return "GermanStrategy";
    }
}
