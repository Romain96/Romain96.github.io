import trafficLights.*;
import trafficLights.observer.TrafficLightTextObserver;

/**
 * Main class for TrafficLight demo.
 * @author Romain PERRIN
 */
public class TrafficLightApp
{
    /**
     * Main method for TrafficLight demo.
     * @param args : command-line arguments
     */
    public static void main (String[] args)
    {
        TrafficLight tl = new TrafficLight(false, TrafficLightColor.GREEN, new FrenchStrategy());
        tl.addObserver(new TrafficLightTextObserver());
        System.out.println("création du feu : " + tl);
        tl.switchState();
        for (int i = 0; i < 5; i++)
        {
            tl.switchColor();
        }
        tl.setStrategy(new GermanStrategy(tl.getColor()));
        for (int i = 0; i < 5; i++)
        {
            tl.switchColor();
        }
        tl.switchState();
        tl.switchState();
        tl.setStrategy(new BicolorStrategy());
        for (int i = 0; i < 5; i++)
        {
            tl.switchColor();
        }
    }
}