package trafficLights;

/**
 * This interface represents the color switching strategy used to make the traffic light advance
 * to the next color. Each implementation should implement a specific switching scheme.
 * @author Romain PERRIN
 */
public interface TrafficLightStrategy
{
    /**
     * Returns the next color in the cycle depending on the provided one.
     * @param currentColor : current traffic light color
     * @return the next color in the cycle
     */
    TrafficLightColor nextColor (TrafficLightColor currentColor);
}