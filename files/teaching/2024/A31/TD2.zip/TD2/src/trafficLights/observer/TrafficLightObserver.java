package trafficLights.observer;

import trafficLights.TrafficLightColor;
import trafficLights.TrafficLightStrategy;

/**
 * This interface implements the DP Observer on a TrafficLight.
 * @author Romain PERRIN
 */
public interface TrafficLightObserver
{
    void updateState (boolean state);
    void updateColor (TrafficLightColor color);
    void updateStrategy (TrafficLightStrategy strategy);
}
