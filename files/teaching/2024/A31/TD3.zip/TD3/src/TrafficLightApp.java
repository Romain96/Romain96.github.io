import controller.TrafficLightController;
import model.trafficLights.FrenchStrategy;
import model.trafficLights.TrafficLight;
import model.trafficLights.TrafficLightColor;
import view.TrafficLightGraphicalObserver;
import view.TrafficLightTextObserver;

/**
 * Main class for the traffic light.
 * @author Romain PERRIN
 */
public class TrafficLightApp
{
    /**
     * Main method, demo.
     * @param args : command-line arguments
     */
    public static void main (String[] args)
    {
        TrafficLight tl = new TrafficLight(false, TrafficLightColor.RED, new FrenchStrategy());
        TrafficLightController ctrl = new TrafficLightController(tl);
        TrafficLightTextObserver text = new TrafficLightTextObserver();
        TrafficLightGraphicalObserver gui = new TrafficLightGraphicalObserver(ctrl, tl);
        tl.addObserver(text);
        tl.addObserver(gui);
    }
}
