package view;

import controller.TrafficLightController;
import model.trafficLights.TrafficLight;
import model.trafficLights.TrafficLightColor;
import model.trafficLights.TrafficLightStrategy;
import model.trafficLights.observer.TrafficLightObserver;

import javax.swing.*;
import java.awt.*;

/**
 * This class is a concrete graphical implementation of the DP Observer on a traffic light.
 * @author Romain PERRIN
 */
public class TrafficLightGraphicalObserver extends JFrame implements TrafficLightObserver
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private TrafficLightController m_controller;

    private JLabel m_greenLabel;
    private JLabel m_orangeLabel;
    private JLabel m_redLabel;
    private JButton m_runButton;
    private JButton m_switchStateButton;
    private JButton m_frenchStrategyButton;
    private JButton m_germanStrategyButton;
    private JButton m_bicolorStrategyButton;
    private Color m_offColor = Color.GRAY;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized controller, instantiates a new TrafficLightGraphicalObserver
     * @param controller : controller controlling a traffic light
     * @param tl : traffic light controlled by the controller
     */
    public TrafficLightGraphicalObserver (TrafficLightController controller, TrafficLight tl)
    {
        m_controller = controller;

        setTitle("TrafficLight | RP");
        setSize(new Dimension(250, 540));
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        m_greenLabel = new JLabel();
        m_greenLabel.setOpaque(true);
        m_orangeLabel = new JLabel();
        m_orangeLabel.setOpaque(true);
        m_redLabel = new JLabel();
        m_redLabel.setOpaque(true);

        m_runButton = new JButton("Run");
        m_runButton.setFocusPainted(false);
        m_runButton.addActionListener(e -> m_controller.run(5, 1000));

        m_switchStateButton = new JButton("On/Off");
        m_switchStateButton.setFocusPainted(false);
        m_switchStateButton.addActionListener(e -> m_controller.switchState());

        m_frenchStrategyButton = new JButton("Français");
        m_frenchStrategyButton.setFocusPainted(false);
        m_frenchStrategyButton.addActionListener(e -> m_controller.switchToFrenchStrategy());
        m_germanStrategyButton = new JButton("Deutsch");
        m_germanStrategyButton.setFocusPainted(false);
        m_germanStrategyButton.addActionListener(e -> m_controller.switchToGermanStrategy());
        m_bicolorStrategyButton = new JButton("Bicolor");
        m_bicolorStrategyButton.setFocusPainted(false);
        m_bicolorStrategyButton.addActionListener(e -> m_controller.switchToBicolorStrategy());

        setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.ipadx = 150;
        constraints.ipady = 150;

        constraints.gridwidth = 6;
        constraints.gridx = 0;
        constraints.gridy = 0;

        add(m_redLabel, constraints);
        constraints.gridy = 1;
        add(m_orangeLabel, constraints);
        constraints.gridy = 2;
        add(m_greenLabel, constraints);

        constraints.gridwidth = 3;
        constraints.gridy = 3;
        constraints.ipadx = 0;
        constraints.ipady = 0;
        add(m_runButton, constraints);
        constraints.gridx = 3;
        add(m_switchStateButton, constraints);

        constraints.gridwidth = 2;
        constraints.gridy = 4;
        constraints.gridx = 0;
        add(m_frenchStrategyButton, constraints);
        constraints.gridx = 2;
        add(m_germanStrategyButton, constraints);
        constraints.gridx = 4;
        add(m_bicolorStrategyButton, constraints);

        updateState(tl.getState());
        updateColor(tl.getColor());
        updateStrategy(tl.getStrategy());

        setVisible(true);
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Updates the graphical interface to display the new traffic light state.
     * @param state : current traffic light state
     */
    @Override
    public void updateState(boolean state)
    {
        if (state)
        {
            m_runButton.setEnabled(true);
            m_greenLabel.setBackground(m_offColor);
            m_orangeLabel.setBackground(m_offColor);
            m_redLabel.setBackground(Color.RED);
        }
        else
        {
            m_runButton.setEnabled(false);
            m_greenLabel.setBackground(m_offColor);
            m_orangeLabel.setBackground(m_offColor);
            m_redLabel.setBackground(m_offColor);
        }
    }

    /**
     * Updates the graphical interface to display the new traffic light color.
     * @param color : current traffic light color
     */
    @Override
    public void updateColor(TrafficLightColor color)
    {
        switch (color)
        {
            case GREEN ->
            {
                m_greenLabel.setBackground(Color.GREEN);
                m_orangeLabel.setBackground(m_offColor);
                m_redLabel.setBackground(m_offColor);
            }
            case ORANGE ->
            {
                m_greenLabel.setBackground(m_offColor);
                m_orangeLabel.setBackground(Color.ORANGE);
                m_redLabel.setBackground(m_offColor);
            }
            case RED ->
            {
                m_greenLabel.setBackground(m_offColor);
                m_orangeLabel.setBackground(m_offColor);
                m_redLabel.setBackground(Color.RED);
            }
            default ->
            {
                break;
            }
        }
    }

    /**
     * Updates the graphical interface to display the new color switching strategy.
     * @param strategy : current traffic light color switching strategy
     */
    @Override
    public void updateStrategy(TrafficLightStrategy strategy)
    {
        switch (strategy.toString())
        {
            case "FrenchStrategy" ->
            {
                m_frenchStrategyButton.setForeground(Color.BLUE);
                m_germanStrategyButton.setForeground(Color.BLACK);
                m_bicolorStrategyButton.setForeground(Color.BLACK);
            }
            case "GermanStrategy" ->
            {
                m_frenchStrategyButton.setForeground(Color.BLACK);
                m_germanStrategyButton.setForeground(Color.BLUE);
                m_bicolorStrategyButton.setForeground(Color.BLACK);
            }
            case "BicolorStrategy" ->
            {
                m_frenchStrategyButton.setForeground(Color.BLACK);
                m_germanStrategyButton.setForeground(Color.BLACK);
                m_bicolorStrategyButton.setForeground(Color.BLUE);
            }
        }
    }
}
