package view;

import model.trafficLights.TrafficLightColor;
import model.trafficLights.TrafficLightStrategy;
import model.trafficLights.observer.TrafficLightObserver;

/**
 * This class is a concrete implementation of the TrafficLightObserver interface.
 * @author Romain PERRIN
 */
public class TrafficLightTextObserver implements TrafficLightObserver
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Updates the text to display the new traffic light state.
     * @param state : current traffic light state
     */
    @Override
    public void updateState(boolean state)
    {
        System.out.println("Le feu est " + (state ? "allumé." : "éteint."));
    }

    /**
     * Updates the text to display the new traffic light color.
     * @param color : current traffic light color
     */
    @Override
    public void updateColor(TrafficLightColor color)
    {
        System.out.println("Le feu est " + color.toString());
    }

    /**
     * Updates the text to display the new color switching strategy.
     * @param strategy : current traffic light color switching strategy
     */
    @Override
    public void updateStrategy(TrafficLightStrategy strategy)
    {
        System.out.println("Le feu utilise la stratégie " + strategy.toString());
    }
}