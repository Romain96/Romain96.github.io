package model.trafficLights.observer;

import model.trafficLights.TrafficLightColor;
import model.trafficLights.TrafficLightStrategy;

/**
 * This interface implements the DP Observer on a TrafficLight.
 * @author Romain PERRIN
 */
public interface TrafficLightObserver
{
    /**
     * Updates the display depending on the traffic light's state.
     * @param state : current traffic light' state
     */
    void updateState (boolean state);

    /**
     * Updates the display depending on the traffic light's color.
     * @param color : current traffic light's color
     */
    void updateColor (TrafficLightColor color);

    /**
     * Updates the display depending on the traffic light strategy.
     * @param strategy : current traffic light strategy
     */
    void updateStrategy (TrafficLightStrategy strategy);
}