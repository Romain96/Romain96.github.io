package model.trafficLights;

/**
 * This class implements the German color cycle for the traffic light (Green -> Orange -> Red -> Orange -> Green...).
 * Romain PERRIN
 */
public class BicolorStrategy implements TrafficLightStrategy
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new BicolorStrategy
     */
    public BicolorStrategy ()
    {
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the next color in the cycle depending on the provided one.
     * @param currentColor : current traffic light color
     * @return the next color in the cycle
     */
    @Override
    public TrafficLightColor nextColor (TrafficLightColor currentColor)
    {
        switch (currentColor)
        {
            case GREEN ->
            {
                return TrafficLightColor.RED;
            }
            case RED ->
            {
                return TrafficLightColor.GREEN;
            }
            default ->
            {
                return currentColor;
            }
        }
    }

    /**
     * Returns a human-readable string representing the GermanStrategy
     * @return BicolorStrategy
     */
    @Override
    public String toString()
    {
        return "BicolorStrategy";
    }
}