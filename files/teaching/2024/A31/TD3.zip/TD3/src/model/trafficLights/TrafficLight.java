package model.trafficLights;

import model.trafficLights.observer.TrafficLightObserver;

import java.util.ArrayList;

public class TrafficLight
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private boolean m_state;
    private TrafficLightColor m_color;
    private TrafficLightStrategy m_strategy;
    private ArrayList<TrafficLightObserver> m_observers;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new TrafficLight.
     * @param state : whether the traffic light is active or inactive
     * @param color : default color
     * @param strategy : color switching strategy
     * @see TrafficLightColor
     */
    public TrafficLight (boolean state, TrafficLightColor color, TrafficLightStrategy strategy)
    {
        this.m_state = state;
        this.m_color = color;
        this.m_strategy = strategy;
        this.m_observers = new ArrayList<>();
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Getter for the state attribute.
     * @return the current TrafficLight state.
     */
    public boolean getState ()
    {
        return this.m_state;
    }

    /**
     * Getter for the color attribute.
     * @return the current TrafficLight color
     */
    public TrafficLightColor getColor ()
    {
        return this.m_color;
    }

    /**
     * Getter for the strategy attribute.
     * @return the currently used color switching strategy
     */
    public TrafficLightStrategy getStrategy ()
    {
        return this.m_strategy;
    }

    /**
     * Sets the color switching strategy
     * @param strategy : new strategy
     * @see TrafficLightStrategy
     */
    public void setStrategy (TrafficLightStrategy strategy)
    {
        if (strategy instanceof BicolorStrategy && this.m_color == TrafficLightColor.ORANGE)
        {
            this.switchColor();
        }
        this.m_strategy = strategy;
        for (TrafficLightObserver observer : this.m_observers)
        {
            observer.updateStrategy(this.m_strategy);
        }
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds a TrafficLightObserver to the list of observers.
     * @param observer : reference on a TrafficLightObserver
     */
    public void addObserver (TrafficLightObserver observer)
    {
        this.m_observers.add(observer);
    }

    /**
     * Switches the traffic light on/off
     */
    public void switchState ()
    {
        this.m_state = !this.m_state;
        for (TrafficLightObserver observer : this.m_observers)
        {
            observer.updateState(this.m_state);
        }
    }

    /**
     * Advances to the next color in the cycle.
     */
    public void switchColor ()
    {
        this.m_color = this.m_strategy.nextColor(this.m_color);
        for (TrafficLightObserver observer : this.m_observers)
        {
            observer.updateColor(this.m_color);
        }
    }

    /**
     * Returns a human-readable string representing the TrafficLight.
     * @return TrafficLight(active: _active_, color: _color_)
     */
    @Override
    public String toString()
    {
        for (TrafficLightObserver observer : this.m_observers)
        {
            observer.updateStrategy(this.m_strategy);
        }
        return "TrafficLight(active :" + this.m_state + ", color :" + this.m_color + ", strategy :" + this.m_strategy + ")";
    }
}