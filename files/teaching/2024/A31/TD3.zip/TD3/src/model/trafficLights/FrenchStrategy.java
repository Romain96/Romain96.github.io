package model.trafficLights;

/**
 * This class implements the French color cycle for the traffic light (Green -> Orange -> Red -> Green...).
 * Romain PERRIN
 */
public class FrenchStrategy implements TrafficLightStrategy
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a new FrenchStrategy.
     */
    public FrenchStrategy ()
    {
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the next color in the cycle depending on the provided one.
     * @param currentColor : current traffic light color
     * @return the next color in the cycle
     */
    @Override
    public TrafficLightColor nextColor(TrafficLightColor currentColor)
    {
        return switch (currentColor)
        {
            case GREEN -> TrafficLightColor.ORANGE;
            case ORANGE -> TrafficLightColor.RED;
            case RED -> TrafficLightColor.GREEN;
        };
    }

    /**
     * Returns a human-readable string representing the FrenchStrategy
     * @return FrenchStrategy
     */
    @Override
    public String toString()
    {
        return "FrenchStrategy";
    }
}