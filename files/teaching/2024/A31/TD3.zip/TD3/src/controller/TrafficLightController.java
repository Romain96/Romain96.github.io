package controller;

import model.trafficLights.BicolorStrategy;
import model.trafficLights.FrenchStrategy;
import model.trafficLights.GermanStrategy;
import model.trafficLights.TrafficLight;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class is a controller. It controls a single traffic light.
 * @author Romain PERRIN
 */
public class TrafficLightController
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private TrafficLight m_trafficLight;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new TrafficLightController.
     * @param tl : reference to the managed traffic light
     */
    public TrafficLightController (TrafficLight tl)
    {
        this.m_trafficLight = tl;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Sets the color strategy to the French one.
     * @see FrenchStrategy
     */
    public void switchToFrenchStrategy ()
    {
        m_trafficLight.setStrategy(new FrenchStrategy());
    }

    /**
     * Sets the color strategy to the German one.
     * @see GermanStrategy
     */
    public void switchToGermanStrategy ()
    {
        m_trafficLight.setStrategy(new GermanStrategy(m_trafficLight.getColor()));
    }

    /**
     * Sets the color strategy to the Bicolor one.
     * @see BicolorStrategy
     */
    public void switchToBicolorStrategy ()
    {
        m_trafficLight.setStrategy(new BicolorStrategy());
    }

    /**
     * Runs the traffic light for a given number of color switching and time.
     * @param iter : number of iteration (color switching)
     * @param sleep : time in ms
     */
    public void run (Integer iter, Integer sleep)
    {
        Timer timer = new Timer(sleep, null);
        timer.addActionListener(new ActionListener() {
            Integer loop = 0;
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
                if (loop < iter)
                {
                    m_trafficLight.switchColor();
                    loop += 1;
                }
                else
                {
                    timer.stop();
                }
            }
        });
        timer.start();
    }

    /**
     * Switches the traffic light's color
     */
    public void switchColor ()
    {
        m_trafficLight.switchColor();
    }

    /**
     * Switches the traffic light on/off.
     */
    public void switchState ()
    {
        m_trafficLight.switchState();
    }
}
