package fileSystemV1;

import java.io.File;

/**
 * This class models the abstraction of the concept of Path.
 */
public abstract class AbstractPath implements Path
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_name;
    private Folder m_parent;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new AbstractPath.
     * @param name : path name
     */
    public AbstractPath (String name)
    {
        m_name = name;
        m_parent = null;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Returns the path's parent.
     * @return the current path's parent folder
     */
    @Override
    public Folder getParent()
    {
        return m_parent;
    }

    /**
     * Returns the path's name.
     * @return the current path's name
     */
    @Override
    public String getName()
    {
        return m_name;
    }

    /**
     * Sets the path's parent.
     * @param parent : new parent folder
     * @throws Exception : if invalid folder
     */
    @Override
    public void setParent (Folder parent) throws Exception
    {
        m_parent = parent;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the absolute path.
     * @return the current absolute path
     */
    @Override
    public String getAbsolutePath()
    {
        return getParent().getAbsolutePath() + File.separator + getName();
    }
}
