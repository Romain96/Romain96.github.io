package fileSystemV1;

/**
 * This interface contains the basic functions related to the concept of Path.
 * @author Romain PERRIN
 */
public interface Path
{
    /**
     * Returns the path's name.
     * @return the path's name
     */
    String getName ();

    /**
     * Returns the path's size.
     * @return the path's size
     */
    Integer getSize ();

    /**
     * Returns the parent folder.
     * @return the parent folder
     */
    Folder getParent ();

    /**
     * Sets the path's parent folder
     * @param parent : new parent folder
     * @throws Exception : in case of error
     */
    void setParent (Folder parent) throws Exception;

    /**
     * Adds a child.
     * @param child : child to add
     * @throws Exception : in case of error
     */
    void add (Path child) throws Exception;

    /**
     * Returns the absolute path.
     * @return the absolute path
     */
    String getAbsolutePath ();
}
