package fileSystemV1;

/**
 * This class models the concept of File.
 * @author Romain PERRIN
 */
public class File extends AbstractPath
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_content;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * ¨Parametrized constructor, instantiates a new empty file.
     * @param name : file name
     */
    public File (String name)
    {
        super(name);
        m_content = "";
    }

    /**
     * Parametrized constructor, instantiates a new file with a content.
     * @param name : file name
     * @param content : file content
     */
    public File (String name, String content)
    {
        super(name);
        m_content = content;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Returns the file content.
     * @return the current file content
     */
    public String getContent ()
    {
        return m_content;
    }

    /**
     * Sets the file content
     * @param content : new file content
     */
    public void setContent (String content)
    {
        m_content = content;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the file size.
     * @return the current file size
     */
    @Override
    public Integer getSize()
    {
        return m_content.length();
    }

    /**
     * Adds a child.
     * @param child : new child to add
     * @throws Exception : if the action is invalid
     */
    @Override
    public void add(Path child) throws Exception
    {
        throw new Exception("Illegal operation : cannot add a child to a file !");
    }
}
