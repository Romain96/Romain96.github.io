package fileSystemV1;

import java.util.Collection;
import java.util.HashSet;

/**
 * This class models the concept of Folder.
 * @author Romain PERRIN
 */
public class Folder extends AbstractPath
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private Collection<Path> m_children;
    private static final Integer m_FOLDER_SIZE = 4096;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new empty folder.
     * @param name : folder name
     */
    public Folder (String name)
    {
        super(name);
        m_children = new HashSet<>();
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Returns the folder size.
     * @return the current folder size
     */
    @Override
    public Integer getSize()
    {
        return m_FOLDER_SIZE;
    }

    /**
     * Returns the folder's children.
     * @return the folder's current children
     */
    public Collection<Path> getChildren ()
    {
        return m_children;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds a child to the folder's children.
     * @param child : child to add
     * @throws Exception : in case of error
     */
    @Override
    public void add (Path child) throws Exception
    {
        m_children.add(child);
        child.setParent(this);
    }

    /**
     * Deletes a child from the folder's children.
     * @param child : child to remove
     * @throws Exception : in case of error
     */
    public void delete (Path child) throws Exception
    {
        m_children.remove(child);
        child.setParent(null);
    }
}
