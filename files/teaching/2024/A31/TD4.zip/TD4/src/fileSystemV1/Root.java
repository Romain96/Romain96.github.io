package fileSystemV1;

/**
 * This class models the Root special folder.
 * @author Romain PERRIN
 */
public class Root extends Folder
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a Root.
     */
    public Root ()
    {
        super("[Root]");
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Sets the root parent.
     * @param parent : new parent folder
     * @throws Exception : in case of error
     */
    @Override
    public void setParent (Folder parent) throws Exception
    {
        throw new Exception("Root error : cannot move the root to another folder !");
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the root absolute path.
     * @return the root absolute path
     */
    @Override
    public String getAbsolutePath()
    {
        return getName();
    }
}
