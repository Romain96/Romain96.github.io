package fileSystemV2;

import java.util.Collection;

/**
 * This class provides static method to manage paths.
 * @author Romain PERRIN
 */
public class PathService
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Estimates the disk usage, emulates the `ls` command.
     * @param path : root path of the command
     * @return a String emulating the du command
     */
    public static Integer du (Path path)
    {
        Integer size = path.getSize();
        if (path.getChildren() != null)
        {
            for (Path child : path.getChildren())
            {
                size += child.getSize();
            }
        }
        return size;
    }

    /**
     * Lists the files and folders, emulates the `ls` command.
     * @param path : root path of the commmand
     * @return a String containing the result
     */
    public static String ls (Path path)
    {
        String content = "";
        for (Path child : path.getChildren())
        {
            content += child.getName() + " ";
        }
        return content;
    }

    /**
     * Lists the files and folders recursively, emulates the `ls -r` command.
     * @param path : root path of the command
     * @return a String containing the result
     */
    public static String lsRecursive (Path path)
    {
        String content = "";
        Collection<Path> children = path.getChildren();
        if (children == null)
        {
            content += path.getName() + " ";
        }
        else
        {
            for (Path child : children)
            {
                content += lsRecursive(child);
            }
        }
        return content;
    }

    /**
     * Finds the files and folders matching a regex, emulates the `find` command.
     * @param path : root path of the command
     * @param pattern : regex of the command
     * @return a String containing the result
     */
    public static String find (Path path, String pattern)
    {
        String content = "";
        if (path.getChildren() != null)
        {
            for (Path child : path.getChildren())
            {
                if (child.getName().matches("(.*)" + pattern + "(.*)"))
                {
                    content += child.getAbsolutePath() + " ";
                }
                content += find(child, pattern);
            }
        }
        return content;
    }
}
