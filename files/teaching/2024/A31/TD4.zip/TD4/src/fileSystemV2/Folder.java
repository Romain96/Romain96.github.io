package fileSystemV2;

import java.util.Collection;
import java.util.HashSet;

/**
 * This class models the concept of Folder.
 * @author Romain PERRIN
 */
public class Folder extends AbstractPath
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private Collection<Path> m_children;
    private static Integer m_FOLDER_SIZE = 4096;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new enpty Folder.
     * @param name : folder name
     */
    public Folder (String name)
    {
        super(name);
        m_children = new HashSet<>();
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Returns the folder's size.
     * @return the folder's current size
     */
    @Override
    public Integer getSize()
    {
        return m_FOLDER_SIZE;
    }

    /**
     * Returns the folder's children.
     * @return the folder's current children
     */
    @Override
    public Collection<Path> getChildren()
    {
        return m_children;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds a child.
     * @param child : child to add
     * @throws Exception : in case of error
     */
    @Override
    public void add(Path child) throws Exception
    {
        m_children.add(child);
        child.setParent(this);
    }

    /**
     * Removes a child.
     * @param child : child to remove
     * @throws Exception : in case of error
     */
    public void delete (Path child) throws Exception
    {
        m_children.remove(child);
        child.setParent(null);
    }
}
