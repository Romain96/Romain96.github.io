package fileSystemV2;

/**
 * This class models the root special folder.
 * @author Romain PERRIN
 */
public class Root extends Folder
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Default constructor, instantiates a new Root.
     */
    public Root ()
    {
        super("[Root]");
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Sets the root's parent
     * @param parent : new parent folder
     * @throws Exception : in case of error
     */
    @Override
    public void setParent(Folder parent) throws Exception
    {
       throw new Exception("Root error : cannot move Root to another folder !");
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the absolute path of the root.
     * @return the absolute path
     */
    @Override
    public String getAbsolutePath()
    {
        return getName();
    }
}
