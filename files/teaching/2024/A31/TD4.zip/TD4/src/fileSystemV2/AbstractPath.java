package fileSystemV2;

import java.io.File;

/**
 * This class models the abstraction on the concept of Path.
 * @author Romain PERRIN
 */
public abstract class AbstractPath implements Path
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_name;
    private Folder m_parent;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new Path.
     * @param name : path name
     */
    public AbstractPath (String name)
    {
        m_name = name;
        m_parent = null;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Returns the parent folder.
     * @return the path's current parent folder
     */
    public Folder getParent ()
    {
        return m_parent;
    }

    /**
     * Returns the path's name.
     * @return the path's current name
     */
    public String getName ()
    {
        return m_name;
    }

    /**
     * Sets the path's parent folder.
     * @param parent : new parent folder
     * @throws Exception : in case of error
     */
    @Override
    public void setParent (Folder parent) throws Exception
    {
        m_parent = parent;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the path's absolute path.
     * @return the current path's absolute name
     */
    @Override
    public String getAbsolutePath()
    {
        return getParent().getAbsolutePath() + File.separator + getName();
    }
}
