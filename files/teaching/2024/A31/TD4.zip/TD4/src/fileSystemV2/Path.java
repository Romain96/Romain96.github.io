package fileSystemV2;

import java.util.Collection;

/**
 * This interface contains the common methods used in the Path.
 * @author Romain PERRIN
 */
public interface Path
{
    /**
     * Returns the path's name
     * @return the path's name
     */
    String getName();

    /**
     * Returns the path's size.
     * @return the path's size
     */
    Integer getSize();

    /**
     * Returns the path's absolute path.
     * @return the path's absolute path
     */
    String getAbsolutePath();

    /**
     * Returns the path's parent folder.
     * @return the parent's folder
     */
    Folder getParent();

    /**
     * Sets the parent folder.
     * @param parent : new parent folder
     * @throws Exception : in case of error
     */
    void setParent(Folder parent) throws Exception;

    /**
     * Returns the folder's children.
     * @return the folder's children
     */
    Collection<Path> getChildren();

    /**
     * Adds a child.
     * @param child : child to add
     * @throws Exception : in case of error
     */
    void add(Path child) throws Exception;
}