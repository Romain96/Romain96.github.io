package fileSystemV2;

import java.util.Collection;

/**
 * This class models the concept of File.
 * @author Romain PERRIN
 */
public class File extends AbstractPath
{
    //-------------------------------------------------------------------------
    // ATTRIBUTES
    //-------------------------------------------------------------------------

    private String m_content;

    //-------------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------------

    /**
     * Parametrized constructor, instantiates a new empty File.
     * @param name : file name
     */
    public File (String name)
    {
        super(name);
        m_content = "";
    }

    /**
     * Parametrized constructor, instantiates a new File with a content.
     * @param name : file name
     * @param content : file content
     */
    public File (String name, String content)
    {
        super(name);
        m_content = content;
    }

    //-------------------------------------------------------------------------
    // ACCESSORS
    //-------------------------------------------------------------------------

    /**
     * Returns the file content.
     * @return : the file's current content
     */
    public String getContent ()
    {
        return m_content;
    }

    /**
     * Sets the file content.
     * @param content : the file's new content
     */
    public void setContent (String content)
    {
        m_content = content;
    }

    //-------------------------------------------------------------------------
    // METHODS
    //-------------------------------------------------------------------------

    /**
     * Returns the file size.
     * @return the file's current size
     */
    @Override
    public Integer getSize()
    {
        return m_content.length();
    }

    /**
     * Adds a child.
     * @param child : child to add
     * @throws Exception : in case of error
     */
    @Override
    public void add (Path child) throws Exception
    {
        throw new Exception("Illegal operation : cannot add a child to a file !");
    }

    /**
     * Returns the collection of children.
     * @return the current collection of children
     */
    @Override
    public Collection<Path> getChildren()
    {
        return null;
    }
}
