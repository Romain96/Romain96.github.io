import fileSystemV2.*;

/**
 * Main demo class for fileSystemV2.
 * @author Romain PERRIN
 */
public class FileSystemAppV2
{
    /**
     * Main method.
     * @param args : command-line arguments
     */
    public static void main (String[] args)
    {
        try
        {
            Path root = new Root();
            Path home = new Folder("home");
            Path me = new Folder("romain.perrin");
            Path readme = new File("Readme.md", "Home folder of Romain PERRIN");
            Path js = new Folder("JS");
            Path retirement = new File("Retirement", "sleep :)");
            Path books = new File("books.md", "Philip K. Dick integral collection");
            Path swapFile = new File("swapfile");

            root.add(home);
            home.add(me);
            me.add(readme);
            home.add(js);
            js.add(retirement);
            js.add(books);
            root.add(swapFile);

            System.out.println("Size of readme : " + readme.getSize());
            System.out.println("Size of romain.perrin : " + me.getSize());
            System.out.println("Size of root : " + root.getSize());

            System.out.println("Content of js : " + PathService.ls(js));
            System.out.println("Content of home : " + PathService.ls(home));
            System.out.println("Content of root : " + PathService.ls(root));

            System.out.println("Recursive content of js : " + PathService.lsRecursive(js));
            System.out.println("Recursive content of home : " + PathService.lsRecursive(home));
            System.out.println("Recursive content of root : " + PathService.lsRecursive(root));

            System.out.println("Find 'books.md' in home : " + PathService.find(home, "books.md"));
            System.out.println("Find '*re*' in root : " + PathService.find(root, "re"));
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}
