import fileSystemV1.File;
import fileSystemV1.Folder;
import fileSystemV1.Path;
import fileSystemV1.Root;

/**
 * Main demo class for fileSystemV1.
 * @author Romain PERRIN
 */
public class FileSystemAppV1
{
    /**
     * Main method.
     * @param args : command*line arguments
     */
    public static void main (String[] args)
    {
        try
        {
            Path root = new Root();
            Path home = new Folder("home");
            Path me = new Folder("romain.perrin");
            Path readme = new File("Readme", "Home of Romain PERRIN");

            root.add(home);
            home.add(me);
            me.add(readme);

            System.out.println("Path of root : " + root.getAbsolutePath());
            System.out.println("Path of home : " + home.getAbsolutePath());
            System.out.println("Path of me : " + me.getAbsolutePath());
            System.out.println("Path of readme : " + readme.getAbsolutePath());
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}
