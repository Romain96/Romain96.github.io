package labyrinth;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.HashMap;

public class ResourcesLoader
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    public static HashMap<String, BufferedImage> loadResources()
    {
        HashMap<String, BufferedImage> resources = new HashMap<>();

        // loading arrows
        String[] arrows = new String[] {"up", "down", "right", "left", "clockwise", "counterclockwise"};
        for (String arrowName : arrows)
        {
            BufferedImage arrowImage = loadImageFromFile("./img/arrows/" + arrowName + ".png");
            resources.put(arrowName, arrowImage);
        }

        // loading players (for player display)
        String[] players = new String[] {"player1", "player2", "player3", "player4"};
        for (String playerName : players)
        {
            BufferedImage playerImage = loadImageFromFile("./img/players/" + playerName + ".png");
            resources.put(playerName, playerImage);
        }

        // loading player (for board display)
        String[] playersBoard = new String[] {"player1", "player2", "player3", "player4"};
        for (String playerBoardName : playersBoard)
        {
            BufferedImage playerBoardImage = loadImageFromFile("./img/playersBoard/" + playerBoardName + ".png");
            resources.put(playerBoardName + "Board", playerBoardImage);
        }

        // objectives display
        String[] objectiveNames = new String[] {"objective_current", "objective_completed", "end_turn",
                "player1EndTile", "player2EndTile", "player3EndTile", "player4EndTile"};
        for (String objectiveName : objectiveNames)
        {
            BufferedImage objectiveNameImage = loadImageFromFile("./img/tilesInterface/" + objectiveName + ".png");
            resources.put(objectiveName, objectiveNameImage);
        }

        return resources;
    }

    private static BufferedImage loadImageFromFile(String path)
    {
        try
        {
            return ImageIO.read(new File(path));
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
}
