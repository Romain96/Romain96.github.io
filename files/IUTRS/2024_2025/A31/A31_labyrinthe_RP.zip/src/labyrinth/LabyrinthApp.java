package labyrinth;

import labyrinth.controller.LabyrinthController;
import labyrinth.model.LabyrinthGame;
import labyrinth.view.GameView;

public class LabyrinthApp
{
    public static void main(String[] args)
    {
        LabyrinthGame game = new LabyrinthGame();
        LabyrinthController controller = new LabyrinthController(game);
        GameView gameView = new GameView(controller, ResourcesLoader.loadResources());
        controller.setView(gameView);
        game.addObserver(gameView);
        game.getBoard().addObserver(gameView);
    }
}
