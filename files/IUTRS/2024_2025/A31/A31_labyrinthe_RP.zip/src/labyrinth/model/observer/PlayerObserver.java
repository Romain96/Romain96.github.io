package labyrinth.model.observer;

import labyrinth.model.Player;

public interface PlayerObserver
{
    void updateCurrentObjectiveChanged(Player player);
}
