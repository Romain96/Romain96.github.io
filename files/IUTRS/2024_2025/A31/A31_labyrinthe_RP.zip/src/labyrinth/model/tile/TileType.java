package labyrinth.model.tile;

public enum TileType
{
    STRAIGHT,
    CORNER,
    BRANCHING,
    STARTPOS;
}
