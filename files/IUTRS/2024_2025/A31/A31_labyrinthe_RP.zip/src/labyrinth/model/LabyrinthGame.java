package labyrinth.model;

import labyrinth.model.objective.Objective;
import labyrinth.model.objective.ObjectiveLoader;
import labyrinth.model.observer.GameObserver;
import labyrinth.model.tile.Tile;
import labyrinth.model.tile.TileFactory;
import labyrinth.model.tile.TileLoader;
import labyrinth.model.tile.TileType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class LabyrinthGame
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private Player[] _players;
    private Board _board;
    private Tile _spareTile;
    private Integer _playerTurn;
    private Boolean _canInsertTile;
    private ArrayList<GameObserver> _observers;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public LabyrinthGame()
    {
        _players = new Player[4];
        _board = new Board();
        _spareTile = null;
        _playerTurn = 0;
        _canInsertTile = Boolean.TRUE;
        _observers = new ArrayList<>();
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public Player[] getPlayers()
    {
        return _players;
    }

    public Board getBoard()
    {
        return _board;
    }

    public Tile getSpareTile()
    {
        return _spareTile;
    }

    public Integer getPlayerTurn()
    {
        return _playerTurn;
    }

    public Boolean getCanInsertTile()
    {
        return _canInsertTile;
    }

    public ArrayList<GameObserver> getObservers()
    {
        return _observers;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setPlayers(Player[] players)
    {
        _players = players;
    }

    public void setBoard(Board board)
    {
        _board = board;
    }

    public void setSpareTile(Tile spareTile)
    {
        _spareTile = spareTile;
    }

    public void setPlayerTurn(Integer playerTurn)
    {
        _playerTurn = playerTurn;
    }

    public void setCanInsertTile(Boolean canInsertTile)
    {
        _canInsertTile = canInsertTile;
    }

    public void setObservers(ArrayList<GameObserver> observers)
    {
        _observers = observers;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    // to create 4 players
    public void generatePlayers(String player1, String player2, String player3, String player4)
    {
        _players[0] = new Player(1, player1, new Integer[]{0, 0});
        _players[1] = new Player(2, player2, new Integer[]{0, 6});
        _players[2] = new Player(3, player3, new Integer[]{6, 6});
        _players[3] = new Player(4, player3, new Integer[]{6, 0});
    }

    // creates all 50 tiles (49 to be placed and a spare tile to be played)
    // generates all 24 objectives
    // assigns objectives to tiles and distributes 6 objectives to each player
    public void generateTilesAndObjectives()
    {
        // generating tiles templates
        TileLoader tilesLoader = new TileLoader();
        HashMap<TileType, Tile> tilesTemplates = tilesLoader.loadTiles("./img/tiles/index.csv");

        // generating objectives
        ObjectiveLoader objectivesLoader = new ObjectiveLoader();
        ArrayList<Objective> objectives = objectivesLoader.loadObjectives("./img/objectives/index.csv");

        // creating starting tiles, straight tiles, corner tiles and branching tiles
        TileFactory factory = new TileFactory();

        // 12 straight tiles all movable
        ArrayList<Tile> straightTiles = new ArrayList<>();
        for (int i = 0; i < 12; i++)
        {
            Tile t = factory.createStraightTile();
            t.setImage(tilesTemplates.get(TileType.STRAIGHT).getImage());
            straightTiles.add(t);
        }

        // 20 corners, 16 movable and 4 fixed (real board corners and player starting positions)
        ArrayList<Tile> cornerTiles = new ArrayList<>();
        for (int i = 0; i < 16; i++)
        {
            Tile t = factory.createCornerTile();
            t.setImage(tilesTemplates.get(TileType.CORNER).getImage());
            cornerTiles.add(t);
        }

        ArrayList<Tile> startingTiles = new ArrayList<>();
        for (int i = 0; i < 4; i++)
        {
            Tile t = factory.createCornerTile();
            t.setImage(tilesTemplates.get(TileType.CORNER).getImage());
            startingTiles.add(t);
        }

        // 18 branching tiles, 12 movable and 6 fixed
        ArrayList<Tile> branchingTiles = new ArrayList<>();
        for (int i = 0; i < 18; i++)
        {
            Tile t = factory.createBranchingTile();
            t.setImage(tilesTemplates.get(TileType.BRANCHING).getImage());
            branchingTiles.add(t);
        }

        // calling the placeTiles method of the board to create the initial configuration
        Tile spareTile = _board.placeTiles(startingTiles, straightTiles, cornerTiles, branchingTiles, objectives);
        setSpareTile(spareTile);

        // shuffle and distributes to each player
        Collections.shuffle(objectives);
        for (int playerNum = 0; playerNum < 4; playerNum++)
        {
            for (int i = 0; i < 6; i++)
            {
                _players[playerNum].getCurrentObjectives().add(objectives.getFirst());
                objectives.removeFirst();
            }
        }

        // placing the 4 players on the corners
        getBoard().getTile(0, 0).addPlayer(getPlayers()[0]);
        getBoard().getTile(0, 6).addPlayer(getPlayers()[1]);
        getBoard().getTile(6, 6).addPlayer(getPlayers()[2]);
        getBoard().getTile(6, 0).addPlayer(getPlayers()[3]);
    }

    public void rotateSpareTileClockwise()
    {
        getSpareTile().rotateClockwise();
        notifySpareTileRotated();
    }

    public void rotateSpareTileCounterClockwise()
    {
        getSpareTile().rotateCounterClockwise();
        notifySpareTileRotated();
    }

    public void insertSpareTileUp(Integer column)
    {
        Tile spareTile = getBoard().shiftDown(column, getSpareTile());
        setSpareTile(spareTile);
        notifySpareTileChanged();
        Integer playerLine = getPlayers()[getPlayerTurn()].getPositionOnBoard()[0];
        Integer playerColumn = getPlayers()[getPlayerTurn()].getPositionOnBoard()[1];
        notifyAllowedMovementChanged(getBoard().getAllowedMovements(playerLine, playerColumn));
        setCanInsertTile(Boolean.FALSE);
        notifyTileInsertionRestriction();
    }

    public void insertSpareTileDown(Integer column)
    {
        Tile spareTile = getBoard().shiftUp(column, getSpareTile());
        setSpareTile(spareTile);
        notifySpareTileChanged();
        Integer playerLine = getPlayers()[getPlayerTurn()].getPositionOnBoard()[0];
        Integer playerColumn = getPlayers()[getPlayerTurn()].getPositionOnBoard()[1];
        notifyAllowedMovementChanged(getBoard().getAllowedMovements(playerLine, playerColumn));
        setCanInsertTile(Boolean.FALSE);
        notifyTileInsertionRestriction();
    }

    public void insertSpareTileLeft(Integer line)
    {
        Tile spareTile = getBoard().shiftRight(line, getSpareTile());
        setSpareTile(spareTile);
        notifySpareTileChanged();
        Integer playerLine = getPlayers()[getPlayerTurn()].getPositionOnBoard()[0];
        Integer playerColumn = getPlayers()[getPlayerTurn()].getPositionOnBoard()[1];
        notifyAllowedMovementChanged(getBoard().getAllowedMovements(playerLine, playerColumn));
        setCanInsertTile(Boolean.FALSE);
        notifyTileInsertionRestriction();
    }

    public void insertSpareTileRight(Integer line)
    {
        Tile spareTile = getBoard().shiftLeft(line, getSpareTile());
        setSpareTile(spareTile);
        notifySpareTileChanged();
        Integer playerLine = getPlayers()[getPlayerTurn()].getPositionOnBoard()[0];
        Integer playerColumn = getPlayers()[getPlayerTurn()].getPositionOnBoard()[1];
        notifyAllowedMovementChanged(getBoard().getAllowedMovements(playerLine, playerColumn));
        setCanInsertTile(Boolean.FALSE);
        notifyTileInsertionRestriction();
    }

    public void moveCurrentPlayerToTile(Integer newLine, Integer newColumn)
    {
        Player currentPlayer = getPlayers()[getPlayerTurn()];
        Integer oldLine = currentPlayer.getPositionOnBoard()[0];
        Integer oldColumn = currentPlayer.getPositionOnBoard()[1];
        getBoard().getTile(oldLine, oldColumn).removePlayer(currentPlayer);
        getBoard().getTile(newLine, newColumn).addPlayer(currentPlayer);
        currentPlayer.setPositionOnBoard(new Integer[] {newLine, newColumn});
        notifyCurrentPlayerMoved(oldLine, oldColumn, newLine, newColumn);
        setCanInsertTile(Boolean.FALSE);
        notifyTileInsertionRestriction();
        Boolean playerCollectedObjective = collectObjectiveOnTile(newLine, newColumn);
        if (playerCollectedObjective)
        {
            endPlayerTurn();
        }
        else
        {
            notifyAllowedMovementChanged(getBoard().getAllowedMovements(newLine, newColumn));
            Boolean playerWon = checkEndGameCondition(newLine, newColumn);
            if (playerWon)
            {
                notifyPlayerWon();
            }
        }
    }

    public Boolean collectObjectiveOnTile(Integer line, Integer column)
    {
        Tile currentTile = getBoard().getTile(line, column);
        Player currentPlayer = getPlayers()[getPlayerTurn()];
        if (currentTile.hasObjective() && currentPlayer.getNextObjectiveToComplete() != null)
        {
            // they match, the current player collects the objective and ends its turn
            if (currentTile.getObjective().equals(currentPlayer.getNextObjectiveToComplete()))
            {
                currentTile.setObjective(null);
                currentPlayer.completeCurrentObjective();
                getBoard().notifyBoardChanged();
                endPlayerTurn();
                return Boolean.TRUE;
            }
            // they don't match, the player can decide to end its turn or continue to move
            return Boolean.FALSE;
        }
        return Boolean.FALSE;
    }

    public void endPlayerTurn()
    {
        setPlayerTurn((getPlayerTurn() + 1) % 4);
        notifyPlayerTurnEnded();
        setCanInsertTile(Boolean.TRUE);
        notifyTileInsertionRestriction();
        Integer line = getPlayers()[getPlayerTurn()].getPositionOnBoard()[0];
        Integer column = getPlayers()[getPlayerTurn()].getPositionOnBoard()[1];
        notifyAllowedMovementChanged(getBoard().getAllowedMovements(line, column));
    }

    public Boolean checkEndGameCondition(Integer line, Integer column)
    {
        Player currentPlayer = getPlayers()[getPlayerTurn()];
        // the current player must have completed all challenges
        if (currentPlayer.getNextObjectiveToComplete() == null)
        {
            // and has moved to any of the 4 corner tiles
            if (getBoard().getTile(line, column).getType() == TileType.STARTPOS)
            {
                // 1st player and corner tile is the top left one -> player 1 won
                if (currentPlayer.getIndex() == 1 && line == 0 && column == 0)
                {
                    return Boolean.TRUE;
                }
                // 2nd player and corner tile is the top right one -> player 2 won
                else if (currentPlayer.getIndex() == 2 && line == 0 && column == 6)
                {
                    return Boolean.TRUE;
                }
                // 3rd player and corner tile is the bottom right one -> player 3 won
                else if (currentPlayer.getIndex() == 3 && line == 6 && column == 6)
                {
                    return Boolean.TRUE;
                }
                // 4th player and corner tile is the bottom left one -> player 4 won
                else if (currentPlayer.getIndex() == 4 && line == 6 && column == 0)
                {
                    return Boolean.TRUE;
                }
                // else the player is on a corner tile but not its starting one
                return Boolean.FALSE;
            }
            // else the player has moved to a tile not on a corner
            return Boolean.FALSE;
        }
        // else the player still has at least one objective to complete before moving to its starting tile
        return Boolean.FALSE;
    }

    public void addObserver(GameObserver observer)
    {
        _observers.add(observer);
    }

    public void removeAllObservers()
    {
        _observers.clear();
    }

    public void notifyStartGame()
    {
        for (GameObserver observer : _observers)
        {
            observer.updateStartGameView(getBoard(), getPlayers(), getSpareTile());
        }
    }

    public void notifySpareTileChanged()
    {
        for (GameObserver observer : _observers)
        {
            observer.updateSpareTileChanged(getSpareTile());
        }
    }

    public void notifySpareTileRotated()
    {
        for (GameObserver observer : _observers)
        {
            observer.updateSpareTileRotated(getSpareTile());
        }
    }

    public void notifyCurrentPlayerMoved(Integer oldLine, Integer oldColumn, Integer newLine, Integer newColumn)
    {
        for (GameObserver observer : _observers)
        {
            observer.updatePlayerMoved(
                    getPlayerTurn(),
                    getBoard().getTile(oldLine, oldColumn),
                    oldLine, oldColumn,
                    getBoard().getTile(newLine, newColumn),
                    newLine, newColumn
            );
        }
    }

    public void notifyAllowedMovementChanged(ArrayList<Integer[]> movements)
    {
        for (GameObserver observer : _observers)
        {
            observer.updateAllowedMovements(movements);
        }
    }

    public void notifyTileInsertionRestriction()
    {
        for (GameObserver observer : _observers)
        {
            observer.updateCanInsertTile(getCanInsertTile());
        }
    }

    public void notifyPlayerTurnEnded()
    {
        for (GameObserver observer : _observers)
        {
            observer.updatePlayerTurnEnded(getPlayers()[getPlayerTurn()]);
        }
    }

    public void notifyPlayerWon()
    {
        for (GameObserver observer : _observers)
        {
            observer.updatePlayerWon(getPlayers()[getPlayerTurn()]);
        }
    }
}
