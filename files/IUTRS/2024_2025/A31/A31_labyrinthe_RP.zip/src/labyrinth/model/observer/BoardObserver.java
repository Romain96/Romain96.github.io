package labyrinth.model.observer;

import labyrinth.model.tile.Tile;

public interface BoardObserver
{
    void updateBoard(Tile[][] tiles);
}
