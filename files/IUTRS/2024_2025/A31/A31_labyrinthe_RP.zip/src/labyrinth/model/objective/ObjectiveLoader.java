package labyrinth.model.objective;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class ObjectiveLoader
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private String _path;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public ObjectiveLoader()
    {
        _path = null;
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public String getPath()
    {
        return _path;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setPath(String path)
    {
        _path = path;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    public ArrayList<Objective> loadObjectives(String path)
    {
        setPath(path);
        return loadObjectives();
    }

    private ArrayList<Objective> loadObjectives()
    {
        HashMap<String, String> objectivesCSV = loadObjectivesFromCSV();
        return createObjectivesFromMap(objectivesCSV);
    }

    private HashMap<String,String> loadObjectivesFromCSV()
    {
        BufferedReader reader;
        HashMap<String, String> objectivesList = new HashMap<>();
        try
        {
            reader = new BufferedReader(new FileReader(getPath()));
            String line;
            while ((line = reader.readLine()) != null)
            {
                String[] parts = line.split(",");
                objectivesList.put(parts[0], parts[1]);
            }
        }
        catch (FileNotFoundException e)
        {
            throw new RuntimeException("File " + getPath() + " not found !\n" + e);
        }
        catch (IOException e)
        {
            throw new RuntimeException("Error reading line\n" + e);
        }
        return objectivesList;
    }

    private ArrayList<Objective> createObjectivesFromMap(HashMap<String, String> objectivesList)
    {
        ArrayList<Objective> objectives = new ArrayList<>();
        for (String objectivePath : objectivesList.keySet())
        {
            BufferedImage objectiveImage = loadObjectiveImage(objectivePath);
            Objective objective = new Objective(objectivesList.get(objectivePath));
            objective.setImage(objectiveImage);
            objectives.add(objective);
        }
        return objectives;
    }

    private BufferedImage loadObjectiveImage(String path)
    {
        try
        {
            return ImageIO.read(new File("./img/objectives/" + path));
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
}
