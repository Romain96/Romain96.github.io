package labyrinth.model.tile;

public enum TileOrientation
{
    NORTH,
    EAST,
    SOUTH,
    WEST;
}
