package labyrinth.model.tile;

public class TileFactory
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public TileFactory()
    {
        ;
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    public Tile createStraightTile()
    {
        return new StraightTile();
    }

    public Tile createStraightTile(TileOrientation orientation)
    {
        return new StraightTile(orientation);
    }

    public Tile createCornerTile()
    {
        return new CornerTile();
    }

    public Tile createCornerTile(TileOrientation orientation)
    {
        return new CornerTile(orientation);
    }

    public Tile createBranchingTile()
    {
        return new BranchingTile();
    }

    public Tile createBranchingTile(TileOrientation orientation)
    {
        return new BranchingTile(orientation);
    }
}
