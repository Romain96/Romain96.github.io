package labyrinth.model;

import labyrinth.model.objective.Objective;
import labyrinth.model.observer.PlayerObserver;

import java.util.ArrayList;

public class Player
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private Integer _index;
    private String _name;
    private ArrayList<Objective> _currentObjectives;
    private ArrayList<Objective> _completedObjectives;
    private ArrayList<PlayerObserver> _observers;
    private Integer[] _positionOnBoard;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public Player(Integer index, String name, Integer[] positionOnBoard)
    {
        _index = index;
        _name = name;
        _currentObjectives = new ArrayList<>();
        _completedObjectives = new ArrayList<>();
        _observers = new ArrayList<>();
        _positionOnBoard = positionOnBoard;
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public Integer getIndex()
    {
        return _index;
    }

    public String getName()
    {
        return _name;
    }

    public ArrayList<Objective> getCurrentObjectives()
    {
        return _currentObjectives;
    }

    public ArrayList<Objective> getCompletedObjectives()
    {
        return _completedObjectives;
    }

    public ArrayList<PlayerObserver> observers()
    {
        return _observers;
    }

    public Integer[] getPositionOnBoard()
    {
        return _positionOnBoard;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setIndex(Integer index)
    {
        _index = index;
    }

    public void setName(String name)
    {
        _name = name;
    }

    public void setCurrentObjectives(ArrayList<Objective> objectives)
    {
        _currentObjectives = objectives;
    }

    public void setCompletedObjectives(ArrayList<Objective> objectives)
    {
        _completedObjectives = objectives;
    }

    public void setObservers(ArrayList<PlayerObserver> observers)
    {
        _observers = observers;
    }

    public void setPositionOnBoard(Integer[] positionOnBoard)
    {
        _positionOnBoard = positionOnBoard;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    // returns the next objective to complete or null if none is to be completed
    public Objective getNextObjectiveToComplete()
    {
        if (_currentObjectives.isEmpty())
        {
            return null;
        }
        return _currentObjectives.getFirst();
    }

    // removes the first objective in current and puts it in completed
    public void completeCurrentObjective()
    {
        if (!_currentObjectives.isEmpty())
        {
            _completedObjectives.add(_currentObjectives.getFirst());
            _currentObjectives.removeFirst();
            notifyCurrentObjectiveChanged();
        }
    }

    public void addObserver(PlayerObserver observer)
    {
        _observers.add(observer);
    }

    public void removeAllObservers()
    {
        _observers.clear();
    }

    public void notifyCurrentObjectiveChanged()
    {
        for (PlayerObserver observer : _observers)
        {
            observer.updateCurrentObjectiveChanged(this);
        }
    }
}
