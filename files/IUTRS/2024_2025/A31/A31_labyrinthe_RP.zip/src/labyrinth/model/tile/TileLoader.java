package labyrinth.model.tile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.HashMap;

public class TileLoader
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private String _path;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public TileLoader()
    {
        _path = null;
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public String getPath()
    {
        return _path;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setPath(String path)
    {
        _path = path;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    public HashMap<TileType, Tile> loadTiles(String path)
    {
        setPath(path);
        return loadTiles();
    }

    private HashMap<TileType, Tile> loadTiles()
    {
        HashMap<TileType, Tile> tiles = new HashMap<>();
        TileFactory factory = new TileFactory();
        BufferedReader reader;
        try
        {
            reader = new BufferedReader(new FileReader(getPath()));
            String line;

            while ((line = reader.readLine()) != null)
            {
                String[] parts = line.split(",");
                Tile t = null;
                switch (parts[0]) {
                    case "grass", "sand" -> {
                        continue;
                    }
                    case "straight" -> t = factory.createStraightTile();
                    case "corner" -> t = factory.createCornerTile();
                    case "branching" -> t = factory.createBranchingTile();
                }
                if (t != null)
                {
                    BufferedImage image = null;
                    image = loadTileImage(parts[1]);
                    t.setImage(image);
                    tiles.put(t.getType(), t);
                }
            }
        }
        catch (FileNotFoundException e)
        {
            throw new RuntimeException("File " + getPath() + " does not exist !\n" + e);
        }
        catch (IOException e)
        {
            throw new RuntimeException("Error reading line !\n" + e);
        }
        return tiles;
    }

    private BufferedImage loadTileImage(String path)
    {
        try
        {
            return ImageIO.read(new File("./img/tiles/" + path));
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
}
