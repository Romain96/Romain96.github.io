package labyrinth.model.tile;

public class CornerTile extends Tile
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public CornerTile()
    {
        super(TileType.CORNER);
    }

    public CornerTile(TileOrientation orientation)
    {
        super(TileType.CORNER, orientation);
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    @Override
    public Boolean canMoveNorth()
    {
        switch (getOrientation())
        {
            case SOUTH, WEST ->
            {
                return Boolean.TRUE;
            }
            case NORTH, EAST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveSouth()
    {
        switch (getOrientation())
        {
            case NORTH, EAST ->
            {
                return Boolean.TRUE;
            }
            case SOUTH, WEST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveEast()
    {
        switch (getOrientation())
        {
            case NORTH, WEST ->
            {
                return Boolean.TRUE;
            }
            case SOUTH, EAST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveWest()
    {
        switch (getOrientation())
        {
            case SOUTH, EAST ->
            {
                return Boolean.TRUE;
            }
            case NORTH, WEST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }
}
