package labyrinth.model.tile;

import labyrinth.model.Player;
import labyrinth.model.objective.Objective;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class Tile
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private TileType _type;
    private TileOrientation _orientation;
    private BufferedImage _image;
    private Objective _objective;
    private ArrayList<Player> _players;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public Tile(TileType type)
    {
        _type = type;
        _orientation = TileOrientation.NORTH;
        _image = null;
        _objective = null;
        _players = new ArrayList<>();
    }

    public Tile(TileType type, TileOrientation orientation)
    {
        _type = type;
        _orientation = orientation;
        _image = null;
        _objective = null;
        _players = new ArrayList<>();
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public TileType getType()
    {
        return _type;
    }

    public TileOrientation getOrientation()
    {
        return _orientation;
    }

    public BufferedImage getImage()
    {
        return _image;
    }

    public Objective getObjective()
    {
        return _objective;
    }

    public ArrayList<Player> getPlayers()
    {
        return _players;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setType(TileType type)
    {
        _type = type;
    }

    public void setOrientation(TileOrientation orientation)
    {
        _orientation = orientation;
    }

    public void setImage(BufferedImage image)
    {
        _image = image;
    }

    public void setObjective(Objective objective)
    {
        _objective = objective;
    }

    public void setPlayer(ArrayList<Player> players)
    {
        _players = players;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    public Boolean hasObjective()
    {
        return _objective == null ? Boolean.FALSE : Boolean.TRUE;
    }

    public Boolean hasPlayers()
    {
        return _players.isEmpty() ? Boolean.FALSE : Boolean.TRUE;
    }

    public void addPlayer(Player player)
    {
        if (!_players.contains(player))
        {
            _players.add(player);
        }
    }

    public void removePlayer(Player player)
    {
        _players.remove(player);
    }

    public void removeAllPlayers()
    {
        _players.clear();
    }

    public abstract Boolean canMoveNorth();
    public abstract Boolean canMoveSouth();
    public abstract Boolean canMoveEast();
    public abstract Boolean canMoveWest();

    public void rotateClockwise()
    {
        switch(_orientation)
        {
            case NORTH -> _orientation = TileOrientation.EAST;
            case EAST -> _orientation = TileOrientation.SOUTH;
            case SOUTH -> _orientation = TileOrientation.WEST;
            case WEST -> _orientation = TileOrientation.NORTH;
        }
    }

    public void rotateCounterClockwise()
    {
        switch (_orientation)
        {
            case NORTH -> _orientation = TileOrientation.WEST;
            case EAST -> _orientation = TileOrientation.NORTH;
            case SOUTH -> _orientation = TileOrientation.EAST;
            case WEST -> _orientation = TileOrientation.SOUTH;
        }
    }
}
