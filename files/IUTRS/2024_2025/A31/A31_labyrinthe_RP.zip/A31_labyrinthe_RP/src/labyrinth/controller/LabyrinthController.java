package labyrinth.controller;

import labyrinth.model.LabyrinthGame;
import labyrinth.model.Player;
import labyrinth.model.tile.Tile;
import labyrinth.view.GameView;

public class LabyrinthController
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private LabyrinthGame _game;
    private GameView _view;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public LabyrinthController(LabyrinthGame game)
    {
        _game = game;
        _view = null;
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public LabyrinthGame getGame()
    {
        return _game;
    }

    public GameView getView()
    {
        return _view;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setGame(LabyrinthGame game)
    {
        _game = game;
    }

    public void setView(GameView view)
    {
        _view = view;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    // to generate the 4 players and start the game
    public void startGame(String player1, String player2, String player3, String player4)
    {
        getGame().generatePlayers(player1, player2, player3, player4);
        getGame().generateTilesAndObjectives();
        for (Player p : getGame().getPlayers())
        {
            p.addObserver(_view);
        }
        getGame().notifyStartGame();
        Integer line = getGame().getPlayers()[getGame().getPlayerTurn()].getPositionOnBoard()[0];
        Integer column = getGame().getPlayers()[getGame().getPlayerTurn()].getPositionOnBoard()[1];
        getGame().notifyAllowedMovementChanged(getGame().getBoard().getAllowedMovements(line, column));
    }

    // ending turn
    public void endPlayerTurn()
    {
        getGame().endPlayerTurn();
    }

    // tile rotation
    public void rotateSpareTileClockwise()
    {
        getGame().rotateSpareTileClockwise();
    }

    public void rotateSpareTileCounterClockwise()
    {
        getGame().rotateSpareTileCounterClockwise();
    }

    // to insert the spareTile in a row or column
    public void insertSpareTileUp(Integer column)
    {
        getGame().insertSpareTileUp(column);
    }

    public void insertSpareTileDown(Integer column)
    {
        getGame().insertSpareTileDown(column);
    }

    public void insertSpareTileLeft(Integer line)
    {
        getGame().insertSpareTileLeft(line);
    }

    public void insertSpareTileRight(Integer line)
    {
        getGame().insertSpareTileRight(line);
    }

    public void moveToTile(Integer newLine, Integer newColumn)
    {
        getGame().moveCurrentPlayerToTile(newLine, newColumn);
    }

    public void resetGame()
    {
        // resetting players
        getGame().getPlayers()[0].setPositionOnBoard(new Integer[]{0, 0});
        getGame().getPlayers()[0].getCompletedObjectives().clear();
        getGame().getPlayers()[0].getCurrentObjectives().clear();

        getGame().getPlayers()[1].setPositionOnBoard(new Integer[]{0, 6});
        getGame().getPlayers()[1].getCompletedObjectives().clear();
        getGame().getPlayers()[1].getCurrentObjectives().clear();

        getGame().getPlayers()[2].setPositionOnBoard(new Integer[]{6, 6});
        getGame().getPlayers()[2].getCompletedObjectives().clear();
        getGame().getPlayers()[2].getCurrentObjectives().clear();

        getGame().getPlayers()[3].setPositionOnBoard(new Integer[]{6, 0});
        getGame().getPlayers()[3].getCompletedObjectives().clear();
        getGame().getPlayers()[3].getCurrentObjectives().clear();

        // regenerating tiles and objectives
        getGame().setSpareTile(null);
        getGame().getBoard().setTiles(new Tile[7][7]);
        getGame().generateTilesAndObjectives();
        getGame().notifyStartGame();
        Integer line = getGame().getPlayers()[getGame().getPlayerTurn()].getPositionOnBoard()[0];
        Integer column = getGame().getPlayers()[getGame().getPlayerTurn()].getPositionOnBoard()[1];
        getGame().notifyAllowedMovementChanged(getGame().getBoard().getAllowedMovements(line, column));
    }
}
