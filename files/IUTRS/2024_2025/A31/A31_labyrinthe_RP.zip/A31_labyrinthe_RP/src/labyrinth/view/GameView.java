package labyrinth.view;

import labyrinth.ImageUtils;
import labyrinth.controller.LabyrinthController;
import labyrinth.model.Board;
import labyrinth.model.Player;
import labyrinth.model.objective.Objective;
import labyrinth.model.observer.BoardObserver;
import labyrinth.model.observer.GameObserver;
import labyrinth.model.observer.PlayerObserver;
import labyrinth.model.tile.Tile;
import labyrinth.model.tile.TileOrientation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;


public class GameView extends JFrame implements GameObserver, BoardObserver, PlayerObserver
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private LabyrinthController _controller;
    private HashMap<String, BufferedImage> _resources;
    private JButton[][] _tiles;
    private JLabel _spareTileLabel;
    private JPanel _gridPanel;
    private JLabel[][] _playerTiles;    // for each player (4) contains 4 JLabels (1st is avatar, 2nd is current objective, 3ed to 8th are completed/to complete objectives
    private JLabel _infos;

    private Integer _objectiveSize;
    private Integer _tileSize;
    private Integer _spareTileSize;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public GameView(LabyrinthController controller, HashMap<String, BufferedImage> resources)
    {
        super();
        _controller = controller;
        _resources = resources;
        _playerTiles = new JLabel[4][8];
        _tileSize = 75;
        _objectiveSize = 75;
        _spareTileSize = 150;
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        initStartView();
        setVisible(true);
        pack();
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public LabyrinthController getController()
    {
        return _controller;
    }

    public HashMap<String, BufferedImage> getResources()
    {
        return _resources;
    }

    public Integer getTileSize()
    {
        return _tileSize;
    }

    public Integer getObjectiveSize()
    {
        return _objectiveSize;
    }

    public Integer getSpareTileSize()
    {
        return _spareTileSize;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setController(LabyrinthController controller)
    {
        _controller = controller;
    }

    public void setResources(HashMap<String, BufferedImage> resources)
    {
        _resources = resources;
    }

    public void setTileSize(Integer tileSize)
    {
        _tileSize = tileSize;
    }

    public void setObjectiveSize(Integer objectiveSize)
    {
        _objectiveSize = objectiveSize;
    }

    public void setSpareTileSize(Integer spareTileSize)
    {
        _spareTileSize = spareTileSize;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    private void initStartView()
    {
        // top panel with title
        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(new JLabel("Welcome to the Maze game\n\nPlease enter the players' names and press `continue`."));

        // main panel with the 4 players
        JPanel middlePanel = new JPanel(new GridLayout(4, 2));

        middlePanel.add(new JLabel("Player 1"));
        JTextField player1TF = new JTextField("Albert");
        middlePanel.add(player1TF);

        middlePanel.add(new JLabel("Player 2"));
        JTextField player2TF = new JTextField("Julie");
        middlePanel.add(player2TF);

        middlePanel.add(new JLabel("Player 3"));
        JTextField player3TF = new JTextField("Alex");
        middlePanel.add(player3TF);

        middlePanel.add(new JLabel("Player 4"));
        JTextField player4TF = new JTextField("Marie");
        middlePanel.add(player4TF);

        // bottom panel with confirm button
        JPanel bottomPanel = new JPanel(new FlowLayout());
        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(e -> {
            // calls the start game procedure in the controller
            _controller.startGame(
                    player1TF.getText(),
                    player2TF.getText(),
                    player3TF.getText(),
                    player4TF.getText());
        });
        bottomPanel.add(confirmButton);

        // main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(middlePanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void initTiles(JPanel panel, Tile[][] tiles)
    {
        _tiles = new JButton[9][9];

        for (int col = 0; col < 9; col++)
        {
            JButton placeholder = new JButton("");
            placeholder.setMinimumSize(new Dimension(_tileSize,_tileSize));
            placeholder.setMaximumSize(new Dimension(_tileSize,_tileSize));
            placeholder.setPreferredSize(new Dimension(_tileSize,_tileSize));
            placeholder.setOpaque(true);
            placeholder.setVisible(true);
            if (col == 2 || col == 4 || col == 6)
            {
                //placeholder.setText("insert\ntile");
                BufferedImage placeHolderIcon = ImageUtils.scaleImage(_resources.get("down"), _tileSize, _tileSize);
                placeholder.setIcon(new ImageIcon(placeHolderIcon));
                placeholder.setEnabled(true);
                int finalCol = col;
                placeholder.addActionListener(e -> {_controller.insertSpareTileUp(finalCol - 1);});
            }
            else
            {
                placeholder.setEnabled(false);
            }
            _tiles[0][col] = placeholder;
            panel.add(placeholder);
        }

        for (int line = 0; line < 7; line++)
        {
            JButton placeholder1 = new JButton("");
            placeholder1.setMinimumSize(new Dimension(_tileSize,_tileSize));
            placeholder1.setMaximumSize(new Dimension(_tileSize,_tileSize));
            placeholder1.setPreferredSize(new Dimension(_tileSize,_tileSize));
            placeholder1.setOpaque(true);
            placeholder1.setVisible(true);

            if (line == 1 || line == 3 || line == 5)
            {
                //placeholder1.setText("insert\ntile");
                BufferedImage placeHolder1Icon = ImageUtils.scaleImage(_resources.get("left"), _tileSize, _tileSize);
                placeholder1.setIcon(new ImageIcon(placeHolder1Icon));
                placeholder1.setEnabled(true);
                int finalLine = line;
                placeholder1.addActionListener(e -> {_controller.insertSpareTileLeft(finalLine);});
            }
            else
            {
                placeholder1.setEnabled(false);
            }
            _tiles[line + 1][0] = placeholder1;
            panel.add(placeholder1);

            for (int column = 0; column < 7; column++)
            {
                JButton tileButton = new JButton();
                tileButton.setMinimumSize(new Dimension(_tileSize, _tileSize));
                tileButton.setMaximumSize(new Dimension(_tileSize, _tileSize));
                tileButton.setPreferredSize(new Dimension(_tileSize, _tileSize));
                BufferedImage icon = ImageUtils.scaleImage(tiles[line][column].getImage(), _tileSize, _tileSize);
                if (tiles[line][column].hasObjective())
                {
                    BufferedImage objectiveImage = ImageUtils.scaleImage(tiles[line][column].getObjective().getImage(), _tileSize, _tileSize);
                    icon = ImageUtils.superimposeImages(icon, objectiveImage);
                }
                icon = applyImageRotation(icon, tiles[line][column].getOrientation());
                if (line == 0 && column == 0 || line == 0 && column == 6 || line == 6 && column == 0 || line == 6 && column == 6)
                {
                    String playerImageName = "";
                    if (line == 0 && column == 0)
                    {
                        playerImageName = "player1Board";
                    }
                    else if (line == 0 && column == 6)
                    {
                        playerImageName = "player2Board";
                    }
                    else if (line == 6 && column == 0)
                    {
                        playerImageName = "player4Board";
                    }
                    else if (line == 6 && column == 6)
                    {
                        playerImageName = "player3Board";
                    }
                    BufferedImage playerOnTileImage = ImageUtils.scaleImage(_resources.get(playerImageName), _tileSize, _tileSize);
                    icon = ImageUtils.superimposeImages(icon, playerOnTileImage);
                }
                tileButton.setIcon(new ImageIcon(icon));
                tileButton.setVisible(true);
                int finalLine2 = line;
                int finalColumn = column;
                tileButton.addActionListener(e -> {_controller.moveToTile(finalLine2, finalColumn);});
                _tiles[line + 1][column + 1] = tileButton;
                panel.add(_tiles[line + 1][column + 1]);
            }

            JButton placeholder2 = new JButton("");
            placeholder2.setMinimumSize(new Dimension(_tileSize,_tileSize));
            placeholder2.setMaximumSize(new Dimension(_tileSize,_tileSize));
            placeholder2.setPreferredSize(new Dimension(_tileSize,_tileSize));
            placeholder2.setOpaque(true);
            placeholder2.setVisible(true);

            if (line == 1 || line == 3 || line == 5)
            {
                //placeholder2.setText("insert\ntile");
                BufferedImage placeHolder2Icon = ImageUtils.scaleImage(_resources.get("right"), _tileSize, _tileSize);
                placeholder2.setIcon(new ImageIcon(placeHolder2Icon));
                placeholder2.setEnabled(true);
                int finalLine1 = line;
                placeholder2.addActionListener(e -> {_controller.insertSpareTileRight(finalLine1);});
            }
            else
            {
                placeholder2.setEnabled(false);
            }
            _tiles[line + 1][8] = placeholder2;
            panel.add(placeholder2);
        }

        for (int col = 0; col < 9; col++)
        {
            JButton placeholder = new JButton("");
            placeholder.setMinimumSize(new Dimension(_tileSize,_tileSize));
            placeholder.setMaximumSize(new Dimension(_tileSize,_tileSize));
            placeholder.setPreferredSize(new Dimension(_tileSize,_tileSize));
            placeholder.setOpaque(true);
            placeholder.setVisible(true);
            if (col == 2 || col == 4 || col == 6)
            {
                //placeholder.setText("insert\ntile");
                BufferedImage placeHolderIcon = ImageUtils.scaleImage(_resources.get("up"), _tileSize, _tileSize);
                placeholder.setIcon(new ImageIcon(placeHolderIcon));
                placeholder.setEnabled(true);
                int finalCol = col;
                placeholder.addActionListener(e -> {_controller.insertSpareTileDown(finalCol - 1);});
            }
            else
            {
                placeholder.setEnabled(false);
            }
            _tiles[8][col] = placeholder;
            panel.add(placeholder);
        }
    }

    private void initPlayers(JPanel panel, Player[] players)
    {
        for (int i = 0; i < 4; i++)
        {
            JPanel playerPanel = new JPanel();
            playerPanel.setLayout(new BoxLayout(playerPanel, BoxLayout.Y_AXIS));
            //playerPanel.setMinimumSize(new Dimension(750, 100));
            //playerPanel.setMaximumSize(new Dimension(750, 100));
            //playerPanel.setPreferredSize(new Dimension(750, 100));

            // top panel is the name of the player
            JPanel playerNamePanel = new JPanel(new FlowLayout());
            JLabel playerNameLabel = new JLabel("Player n°" + (i+1) + " : " + players[i].getName());
            playerNamePanel.add(playerNameLabel);
            playerPanel.add(playerNamePanel);

            // bottom panel is the display of the player's avatar, current objective and completed objectives
            JPanel playerDisplayPanel = new JPanel(new GridLayout(1, 8, 5, 5));

            // first item is for the player's avatar
            JLabel playerAvatarLabel = new JLabel();
            BufferedImage playerIcon = ImageUtils.scaleImage(_resources.get("player" + (i + 1)), _objectiveSize, _objectiveSize);
            playerAvatarLabel.setIcon(new ImageIcon(playerIcon));
            playerAvatarLabel.setVisible(true);
            playerAvatarLabel.setOpaque(true);
            _playerTiles[i][0] = playerAvatarLabel;
            playerDisplayPanel.add(_playerTiles[i][0]);

            // second item is for the current objective
            JLabel currentObjectiveLabel = new JLabel();
            BufferedImage currentObjectiveIcon = ImageUtils.scaleImage(players[i].getNextObjectiveToComplete().getImage(), _objectiveSize, _objectiveSize);
            currentObjectiveLabel.setIcon(new ImageIcon(currentObjectiveIcon));
            currentObjectiveLabel.setVisible(true);
            _playerTiles[i][1] = currentObjectiveLabel;
            playerDisplayPanel.add(_playerTiles[i][1]);

            // third to eighth items are for the completed and to complete objectives (6 in total)
            // those already completed after (visible)
            int tileIndex = 2;
            for (Objective objectiveCompleted : players[i].getCompletedObjectives())
            {
                JLabel objectiveCompletedLabel = new JLabel();
                objectiveCompletedLabel.setMinimumSize(new Dimension(_objectiveSize, _objectiveSize));
                objectiveCompletedLabel.setMaximumSize(new Dimension(_objectiveSize, _objectiveSize));
                objectiveCompletedLabel.setPreferredSize(new Dimension(_objectiveSize, _objectiveSize));
                BufferedImage objectiveCompletedIcon = ImageUtils.scaleImage(objectiveCompleted.getImage(), _objectiveSize, _objectiveSize);
                objectiveCompletedIcon = ImageUtils.superimposeImages(objectiveCompletedIcon, _resources.get("objective_completed"));
                objectiveCompletedLabel.setIcon(new ImageIcon(objectiveCompletedIcon));
                objectiveCompletedLabel.setVisible(true);
                objectiveCompletedLabel.setOpaque(true);
                _playerTiles[i][tileIndex] = objectiveCompletedLabel;
                playerDisplayPanel.add(_playerTiles[i][tileIndex]);
                tileIndex += 1;
            }

            for (int j = players[i].getCompletedObjectives().size(); j < 6; j++)
            {
                JLabel objectiveToCompleteLabel = new JLabel("");
                objectiveToCompleteLabel.setMinimumSize(new Dimension(_objectiveSize, _objectiveSize));
                objectiveToCompleteLabel.setMaximumSize(new Dimension(_objectiveSize, _objectiveSize));
                objectiveToCompleteLabel.setPreferredSize(new Dimension(_objectiveSize, _objectiveSize));
                BufferedImage objectiveToCompleteIcon = ImageUtils.scaleImage(_resources.get("objective_current"), _objectiveSize, _objectiveSize);
                objectiveToCompleteLabel.setIcon(new ImageIcon(objectiveToCompleteIcon));
                objectiveToCompleteLabel.setVisible(true);
                objectiveToCompleteLabel.setOpaque(true);
                _playerTiles[i][tileIndex] = objectiveToCompleteLabel;
                playerDisplayPanel.add(_playerTiles[i][tileIndex]);
                tileIndex += 1;
            }
            playerPanel.add(playerDisplayPanel);

            panel.add(playerPanel);
        }
    }

    private void initSpareTilePanel(JPanel panel, Tile spareTile)
    {
        BufferedImage spareTileIcon = ImageUtils.scaleImage(spareTile.getImage(), _spareTileSize, _spareTileSize);
        spareTileIcon = applyImageRotation(spareTileIcon, spareTile.getOrientation());
        _spareTileLabel = new JLabel();
        _spareTileLabel.setIcon(new ImageIcon(spareTileIcon));
        _spareTileLabel.setVisible(true);
        _spareTileLabel.setOpaque(true);
        panel.add(_spareTileLabel);

        // two buttons to rotate the spare tile
        JPanel bottomPanel = new JPanel(new GridLayout(1, 2, 5, 5));

        JButton rotateCounterClockwise = new JButton("");
        rotateCounterClockwise.setMinimumSize(new Dimension(_tileSize, _tileSize));
        rotateCounterClockwise.setMaximumSize(new Dimension(_tileSize, _tileSize));
        rotateCounterClockwise.setPreferredSize(new Dimension(_tileSize, _tileSize));
        BufferedImage counterclockwiseIcon = ImageUtils.scaleImage(_resources.get("counterclockwise"), 75, 75);
        rotateCounterClockwise.setIcon(new ImageIcon(counterclockwiseIcon));
        rotateCounterClockwise.addActionListener(e -> {_controller.rotateSpareTileCounterClockwise();});

        JButton rotateClockwise = new JButton("");
        rotateClockwise.setMinimumSize(new Dimension(_tileSize, _tileSize));
        rotateClockwise.setMaximumSize(new Dimension(_tileSize, _tileSize));
        rotateClockwise.setPreferredSize(new Dimension(_tileSize, _tileSize));
        BufferedImage clockwiseIcon = ImageUtils.scaleImage(_resources.get("clockwise"), _tileSize, _tileSize);
        rotateClockwise.setIcon(new ImageIcon(clockwiseIcon));
        rotateClockwise.addActionListener(e -> {_controller.rotateSpareTileClockwise();});

        JButton endTurnButton = new JButton("");
        endTurnButton.setMinimumSize(new Dimension(_tileSize, _tileSize));
        endTurnButton.setMaximumSize(new Dimension(_tileSize, _tileSize));
        endTurnButton.setPreferredSize(new Dimension(_tileSize, _tileSize));
        BufferedImage endTurnIcon = ImageUtils.scaleImage(_resources.get("end_turn"), _tileSize, _tileSize);
        endTurnButton.setIcon(new ImageIcon(endTurnIcon));
        endTurnButton.addActionListener(e -> {_controller.endPlayerTurn();});

        _infos = new JLabel("N/A");

        bottomPanel.add(rotateCounterClockwise);
        bottomPanel.add(rotateClockwise);
        bottomPanel.add(endTurnButton);
        bottomPanel.add(_infos);
        panel.add(bottomPanel);
    }

    private BufferedImage applyImageRotation(BufferedImage image, TileOrientation orientation)
    {
        switch (orientation)
        {
            case NORTH -> {
                return image;
            }
            case EAST -> {
                return ImageUtils.rotateImageClockwise(image);
            }
            case SOUTH -> {
                return ImageUtils.rotateImageClockwise(ImageUtils.rotateImageClockwise(image));
            }
            case WEST -> {
                return ImageUtils.rotateImageCounterClockwise(image);
            }
        }
        return image;
    }

    @Override
    public void updateStartGameView(Board board, Player[] players, Tile spareTile)
    {
        // left panel is for the board
        JPanel leftPanel = new JPanel(new FlowLayout());

        // grid of 7x7 images to display the tiles of the complete board
        _gridPanel = new JPanel(new GridLayout(9, 9, 0, 0));
        _gridPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //_gridPanel.setMinimumSize(new Dimension(700, 700));
        //_gridPanel.setMaximumSize(new Dimension(700, 700));
        //_gridPanel.setPreferredSize(new Dimension(700, 700));
        initTiles(_gridPanel, board.getTiles());
        leftPanel.add(_gridPanel);

        // right panel is for the players and their objectives
        JPanel rightPanel = new JPanel();
        rightPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

        JPanel playersPanel = new JPanel(new GridLayout(4, 1, 0, 0));
        initPlayers(playersPanel, players);

        rightPanel.add(playersPanel);

        // spare tile panel
        JPanel spareTilePanel = new JPanel(new FlowLayout());
        spareTilePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        initSpareTilePanel(spareTilePanel, spareTile);
        _infos.setText("Player " + players[0].getIndex() + "'s turn.");
        rightPanel.add(spareTilePanel);

        // game panel (aka top panel)
        JPanel gamePanel = new JPanel(new FlowLayout());
        gamePanel.add(leftPanel);
        gamePanel.add(rightPanel);

        // main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(gamePanel, BorderLayout.CENTER);

        setContentPane(mainPanel);
        setVisible(true);
        pack();
    }

    @Override
    public void updateSpareTileChanged(Tile spareTile)
    {
        BufferedImage spareTileIcon = ImageUtils.scaleImage(spareTile.getImage(), _spareTileSize, _spareTileSize);
        spareTileIcon = applyImageRotation(spareTileIcon, spareTile.getOrientation());
        if (spareTile.hasObjective())
        {
            BufferedImage objectiveIcon = ImageUtils.scaleImage(spareTile.getObjective().getImage(), _spareTileSize, _spareTileSize);
            spareTileIcon = ImageUtils.superimposeImages(spareTileIcon, objectiveIcon);
        }
        _spareTileLabel.setIcon(new ImageIcon(spareTileIcon));
    }

    @Override
    public void updateSpareTileRotated(Tile spareTile)
    {
        BufferedImage spareTileIcon = ImageUtils.scaleImage(spareTile.getImage(), _spareTileSize, _spareTileSize);
        spareTileIcon = applyImageRotation(spareTileIcon, spareTile.getOrientation());
        if (spareTile.hasObjective())
        {
            BufferedImage objectiveIcon = ImageUtils.scaleImage(spareTile.getObjective().getImage(), _spareTileSize, _spareTileSize);
            spareTileIcon = ImageUtils.superimposeImages(spareTileIcon, objectiveIcon);
        }
        _spareTileLabel.setIcon(new ImageIcon(spareTileIcon));
    }

    @Override
    public void updatePlayerMoved(Integer playerIndex, Tile oldTile, Integer oldLine, Integer oldColumn, Tile newTile, Integer newLine, Integer newColumn)
    {
        // redrawing the old tile without the player on it
        BufferedImage oldTileImage = ImageUtils.scaleImage(oldTile.getImage(), _tileSize, _tileSize);
        oldTileImage = applyImageRotation(oldTileImage, oldTile.getOrientation());
        if (oldTile.hasObjective())
        {
            BufferedImage oldTileObjectiveImage = ImageUtils.scaleImage(oldTile.getObjective().getImage(), _tileSize, _tileSize);
            oldTileImage = ImageUtils.superimposeImages(oldTileImage, oldTileObjectiveImage);
        }
        _tiles[oldLine + 1][oldColumn + 1].setIcon(new ImageIcon(oldTileImage));

        // redrawing the new tile with the player now on it
        BufferedImage newTileImage = ImageUtils.scaleImage(newTile.getImage(), _tileSize, _tileSize);
        newTileImage = applyImageRotation(newTileImage, newTile.getOrientation());
        if (newTile.hasObjective())
        {
            BufferedImage newTileObjectiveImage = ImageUtils.scaleImage(newTile.getObjective().getImage(), _tileSize, _tileSize);
            newTileImage = ImageUtils.superimposeImages(newTileImage, newTileObjectiveImage);
        }
        for (Player player : newTile.getPlayers())
        {
            BufferedImage playerAvatar = ImageUtils.scaleImage(_resources.get("player" + player.getIndex() + "Board"), _tileSize, _tileSize);
            newTileImage = ImageUtils.superimposeImages(newTileImage, playerAvatar);
        }
        _tiles[newLine + 1][newColumn + 1].setIcon(new ImageIcon(newTileImage));
    }

    @Override
    public void updateAllowedMovements(ArrayList<Integer[]> movements)
    {
        // disable all
        disableAllMovements();
        // enable only the one-case movement according to the current tile
        for (Integer[] movement : movements)
        {
            enableMovement(movement[0], movement[1]);
        }
        repaint();
    }

    @Override
    public void updateCanInsertTile(Boolean canInsert)
    {
        // topmost line
        _tiles[0][2].setEnabled(canInsert);
        _tiles[0][4].setEnabled(canInsert);
        _tiles[0][6].setEnabled(canInsert);
        // leftmost column
        _tiles[2][0].setEnabled(canInsert);
        _tiles[4][0].setEnabled(canInsert);
        _tiles[6][0].setEnabled(canInsert);
        // rightmost column
        _tiles[2][8].setEnabled(canInsert);
        _tiles[4][8].setEnabled(canInsert);
        _tiles[6][8].setEnabled(canInsert);
        // bottommost line
        _tiles[8][2].setEnabled(canInsert);
        _tiles[8][4].setEnabled(canInsert);
        _tiles[8][6].setEnabled(canInsert);
        repaint();
    }

    private void enableMovement(Integer line, Integer column)
    {
        if (line >= 0 && line <= 6 && column >= 0 && column <= 6)
        {
            _tiles[line + 1][column + 1].setEnabled(true);
        }
    }

    private void disableAllMovements()
    {
        for (int line = 1; line < 8; line++)
        {
            for (int column = 1; column < 8; column++)
            {
                _tiles[line][column].setEnabled(false);
            }
        }
    }

    @Override
    public void updatePlayerTurnEnded(Player player)
    {
        _infos.setText("Player " + player.getIndex() + "'s turn.");
        repaint();
    }

    @Override
    public void updatePlayerWon(Player player)
    {
        initEndWindow(player.getName() + " (player " + player.getIndex() + ") has won the game !");
    }

    private void initEndWindow(String text)
    {
        JLabel textLabel = new JLabel(text);
        JButton newGameButton = new JButton("New game");
        newGameButton.addActionListener(e -> {_controller.resetGame();});
        JButton exitButton = new JButton("Quit");
        exitButton.addActionListener(e -> {dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));});

        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(textLabel);

        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.add(newGameButton);
        bottomPanel.add(exitButton);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.add(topPanel);
        mainPanel.add(bottomPanel);

        setContentPane(mainPanel);
        pack();
        repaint();
    }

    @Override
    public void updateBoard(Tile[][] tiles)
    {
        for (int line = 0; line < 7; line++)
        {
            for (int column = 0; column < 7; column++)
            {
                BufferedImage icon = ImageUtils.scaleImage(tiles[line][column].getImage(), _tileSize, _tileSize);
                icon = applyImageRotation(icon, tiles[line][column].getOrientation());
                if (tiles[line][column].hasObjective())
                {
                    BufferedImage objectiveImage = ImageUtils.scaleImage(tiles[line][column].getObjective().getImage(), _tileSize, _tileSize);
                    icon = ImageUtils.superimposeImages(icon, objectiveImage);
                }
                if (tiles[line][column].hasPlayers())
                {
                    for (Player player : tiles[line][column].getPlayers())
                    {
                        BufferedImage playerAvatarImage = ImageUtils.scaleImage(_resources.get("player" + player.getIndex() + "Board"), _tileSize, _tileSize);
                        icon = ImageUtils.superimposeImages(icon, playerAvatarImage);
                    }
                }
                _tiles[line + 1][column + 1].setIcon(new ImageIcon(icon));
            }
        }
    }

    @Override
    public void updateCurrentObjectiveChanged(Player player)
    {
        // first item is for the player's avatar
        BufferedImage playerIcon = ImageUtils.scaleImage(_resources.get("player" + player.getIndex()), _objectiveSize, _objectiveSize);
        _playerTiles[player.getIndex() - 1][0].setIcon(new ImageIcon(playerIcon));

        // second item is for the current objective
        BufferedImage currentObjectiveIcon = null;
        if (player.getNextObjectiveToComplete() == null)
        {
            currentObjectiveIcon = ImageUtils.scaleImage(_resources.get("player" + player.getIndex() + "EndTile"), _objectiveSize, _objectiveSize);
        }
        else
        {
            currentObjectiveIcon = ImageUtils.scaleImage(player.getNextObjectiveToComplete().getImage(), _objectiveSize, _objectiveSize);
        }
        _playerTiles[player.getIndex() - 1][1].setIcon(new ImageIcon(currentObjectiveIcon));

        // third to eighth items are for the completed and to complete objectives (6 in total)
        // those already completed after (visible)
        int tileIndex = 2;
        for (Objective objectiveCompleted : player.getCompletedObjectives())
        {
            BufferedImage objectiveCompletedIcon = ImageUtils.scaleImage(objectiveCompleted.getImage(), _objectiveSize, _objectiveSize);
            objectiveCompletedIcon = ImageUtils.superimposeImages(objectiveCompletedIcon, _resources.get("objective_completed"));
            _playerTiles[player.getIndex() - 1][tileIndex++].setIcon(new ImageIcon(objectiveCompletedIcon));
        }

        for (int j = player.getCompletedObjectives().size(); j < 6; j++) {
            BufferedImage objectiveToCompleteIcon = ImageUtils.scaleImage(_resources.get("objective_current"), _objectiveSize, _objectiveSize);
            _playerTiles[player.getIndex() - 1][tileIndex++].setIcon(new ImageIcon(objectiveToCompleteIcon));
        }

        repaint();
    }
}
