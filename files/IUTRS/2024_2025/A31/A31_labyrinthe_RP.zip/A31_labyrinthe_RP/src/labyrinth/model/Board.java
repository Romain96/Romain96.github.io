package labyrinth.model;

import labyrinth.model.objective.Objective;
import labyrinth.model.observer.BoardObserver;
import labyrinth.model.tile.Tile;
import labyrinth.model.tile.TileOrientation;
import labyrinth.model.tile.TileType;

import java.util.ArrayList;
import java.util.Collections;

public class Board
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private Tile[][] _tiles;
    private ArrayList<BoardObserver> _observers;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public Board()
    {
        _tiles = new Tile[7][7];
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
                _tiles[i][j] = null;
            }
        }
        _observers = new ArrayList<>();
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public Tile[][] getTiles()
    {
        return _tiles;
    }

    public ArrayList<BoardObserver> getObservers()
    {
        return _observers;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setTiles(Tile[][] tiles)
    {
        _tiles = tiles;
    }

    public void setObservers(ArrayList<BoardObserver> observers)
    {
        _observers = observers;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    public Tile getTile(Integer line, Integer column)
    {
        if (line >= 0 && line < 7 && column >= 0 && column < 7)
        {
            return _tiles[line][column];
        }
        return null;
    }

    public Tile setTile(Tile tile, Integer line, Integer column)
    {
        Tile original = _tiles[line][column];
        if (line < 7 && column < 7)
        {
            _tiles[line][column] = tile;
            return original;
        }
        return original;
    }

    public void setTileNoReturn(Tile tile, Integer line, Integer column)
    {
        if (line < 7 && column < 7)
        {
            _tiles[line][column] = tile;
        }
    }

    // initializes the board by placing all tiles and assigns the spare tile
    // returns the spare tile
    public Tile placeTiles(
            ArrayList<Tile> startingTiles, ArrayList<Tile> straightTiles,
            ArrayList<Tile> cornerTiles, ArrayList<Tile> branchingTiles,
            ArrayList<Objective> objectives
    )
    {
        Tile t = null;
        assert startingTiles.size() == 4;
        assert straightTiles.size() == 12;
        assert cornerTiles.size() == 16;
        assert branchingTiles.size() == 18;

        // placing corner tiles (each tiles is oriented as if as an upper left corner)
        t = startingTiles.getFirst();
        t.setType(TileType.STARTPOS);
        t.setOrientation(TileOrientation.NORTH);
        setTileNoReturn(t, 0, 0);
        startingTiles.removeFirst();

        t = startingTiles.getFirst();
        t.setType(TileType.STARTPOS);
        t.setOrientation(TileOrientation.EAST);
        setTileNoReturn(t, 0, 6);
        startingTiles.removeFirst();

        t = startingTiles.getFirst();
        t.setType(TileType.STARTPOS);
        t.setOrientation(TileOrientation.SOUTH);
        setTileNoReturn(t, 6, 6);
        startingTiles.removeFirst();

        t = startingTiles.getFirst();
        t.setType(TileType.STARTPOS);
        t.setOrientation(TileOrientation.WEST);
        setTileNoReturn(t, 6, 0);
        startingTiles.removeFirst();

        // placing fixed tiles (12 branching tiles)
        // 1st line, 3rd and 5th columns
        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.NORTH);
        setTileNoReturn(t, 0, 2);
        branchingTiles.removeFirst();

        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.NORTH);
        setTileNoReturn(t, 0, 4);
        branchingTiles.removeFirst();

        // 7th line, 3rd and 5th columns
        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.SOUTH);
        setTileNoReturn(t, 6, 2);
        branchingTiles.removeFirst();

        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.SOUTH);
        setTileNoReturn(t, 6, 4);
        branchingTiles.removeFirst();

        // 1st column, 3rd and 5th lines
        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.WEST);
        setTileNoReturn(t, 2, 0);
        branchingTiles.removeFirst();

        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.WEST);
        setTileNoReturn(t, 4, 0);
        branchingTiles.removeFirst();

        // 7th column, 3rd abd 5th lines
        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.EAST);
        setTileNoReturn(t, 2, 6);
        branchingTiles.removeFirst();

        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.EAST);
        setTileNoReturn(t, 4, 6);
        branchingTiles.removeFirst();

        // center square
        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.WEST);
        setTileNoReturn(t, 2, 2);
        branchingTiles.removeFirst();

        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.NORTH);
        setTileNoReturn(t, 2, 4);
        branchingTiles.removeFirst();

        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.SOUTH);
        setTileNoReturn(t, 4, 2);
        branchingTiles.removeFirst();

        t = branchingTiles.getFirst();
        t.setOrientation(TileOrientation.EAST);
        setTileNoReturn(t ,4, 4);
        branchingTiles.removeFirst();

        // extracting the spare tile
        ArrayList<Tile> remainingTiles = new ArrayList<>();
        while (!straightTiles.isEmpty())
        {
            remainingTiles.add(straightTiles.getFirst());
            straightTiles.removeFirst();
        }while (!cornerTiles.isEmpty())
        {
            remainingTiles.add(cornerTiles.getFirst());
            cornerTiles.removeFirst();
        }
        while (!branchingTiles.isEmpty())
        {
            remainingTiles.add(branchingTiles.getFirst());
            branchingTiles.removeFirst();
        }

        // shuffling tiles
        Collections.shuffle(remainingTiles);

        // extracting the spare tile
        Tile spareTile = remainingTiles.getFirst();
        remainingTiles.removeFirst();

        // assigning objectives to the 24th first free tiles
        for (int i = 0; i < objectives.size(); i++)
        {
            remainingTiles.get(i).setObjective(objectives.get(i));
        }
        // reshuffling to ensure the tiles are randomly-placed
        Collections.shuffle(remainingTiles);

        // placing randomly the remaining tiles
        for (int line = 0; line < 7; line++)
        {
            for (int column = 0; column < 7; column++)
            {
                if (getTile(line, column) == null)
                {
                    setTileNoReturn(remainingTiles.getFirst(), line, column);
                    remainingTiles.removeFirst();
                }
            }
        }

        return spareTile;
    }

    // inserts the spare tile at the left of the given line by pushing all tiles rightward
    public Tile shiftRight(Integer index, Tile insert)
    {
        Tile ejected = _tiles[index][6];    // the rightmost tile in the row is ejected and returned
        // all other tiles in the row are shifted one position to the right
        for (int i = 6; i > 0; i--)
        {
            // shifting players if any
            if (_tiles[index][i - 1].hasPlayers())
            {
                for (Player player : _tiles[index][i - 1].getPlayers())
                {
                    player.setPositionOnBoard(new Integer[] {index, i});
                }
            }
            // moving the tile
            _tiles[index][i] = _tiles[index][i - 1];
        }
        _tiles[index][0] = insert;  // the given tile is inserted in the leftmost position in the row
        // if the ejected tile contains players, they are reintroduced to the leftmost tile in the row
        if (ejected.hasPlayers())
        {
            for (Player player : ejected.getPlayers())
            {
                player.setPositionOnBoard(new Integer[] {index, 0});
                _tiles[index][0].addPlayer(player);
            }
            ejected.removeAllPlayers();
        }
        // notify observers
        notifyBoardChanged();
        return ejected;
    }

    // inserts the spare tile at the right of the given line by pushing all tiles leftward
    public Tile shiftLeft(Integer index, Tile insert)
    {
        Tile ejected = _tiles[index][0];    // the leftmost tile in the row is ejected and returned
        // all other tiles in the row are shifted one position to the left
        for (int i = 0; i < 6; i++)
        {
            // shifting players if any
            if (_tiles[index][i + 1].hasPlayers())
            {
                for (Player player : _tiles[index][i + 1].getPlayers())
                {
                    player.setPositionOnBoard(new Integer[] {index, i});
                }
            }
            // moving the tile
            _tiles[index][i] = _tiles[index][i + 1];
        }
        _tiles[index][6] = insert;  // the given tile is inserted in the rightmost position in the row
        // if the ejected tile contains players, they are reintroduced to the rightmost tile in the row
        if (ejected.hasPlayers())
        {
            for (Player player : ejected.getPlayers())
            {
                player.setPositionOnBoard(new Integer[] {index, 6});
                _tiles[index][6].addPlayer(player);
            }
            ejected.removeAllPlayers();
        }
        // notify observers
        notifyBoardChanged();
        return ejected;
    }

    // inserts the spare tile at the top of the given column by pushing all tiles downward
    public Tile shiftDown(Integer index, Tile insert)
    {
        Tile ejected = _tiles[6][index];    // the lowermost tile in the column is ejected
        // all other tiles in the column are shifted one position to the bottom
        for (int i = 6; i > 0; i--)
        {
            // shifting players if any
            if (_tiles[i - 1][index].hasPlayers())
            {
                for (Player player : _tiles[i - 1][index].getPlayers())
                {
                    player.setPositionOnBoard(new Integer[] {i, index});
                }
            }
            // moving the tile
            _tiles[i][index] = _tiles[i - 1][index];
        }
        _tiles[0][index] = insert;  // the given tile is inserted in the uppermost position in the column
        // if the ejected tile contains players, they are reintroduced to the bottommost tile in the column
        if (ejected.hasPlayers())
        {
            for (Player player : ejected.getPlayers())
            {
                player.setPositionOnBoard(new Integer[] {0, index});
                _tiles[0][index].addPlayer(player);
            }
            ejected.removeAllPlayers();
        }
        // notify observers
        notifyBoardChanged();
        return ejected;
    }

    // inserts the spare tile at the bottom of the given column  by pushing all tiles upward
    public Tile shiftUp(Integer index, Tile insert)
    {
        Tile ejected = _tiles[0][index];    // the uppermost tile in the column is ejected
        // all other tiles in the column are shifted one position to the top
        for (int i = 0; i < 6; i++)
        {
            // shifting players if any
            if (_tiles[i + 1][index].hasPlayers())
            {
                for (Player player : _tiles[i + 1][index].getPlayers())
                {
                    player.setPositionOnBoard(new Integer[] {i, index});
                }
            }
            // moving the tile
            _tiles[i][index] = _tiles[i + 1][index];
        }
        _tiles[6][index] = insert;  // the given tile is inserted in the lowermost position in the column
        // if the ejected tile contains players, they are reintroduced to the topmost tile in the column
        if (ejected.hasPlayers())
        {
            for (Player player : ejected.getPlayers())
            {
                player.setPositionOnBoard(new Integer[] {6, index});
                _tiles[6][index].addPlayer(player);
            }
            ejected.removeAllPlayers();
        }
        // notify observers
        notifyBoardChanged();
        return ejected;
    }

    public ArrayList<Integer[]> getAllowedMovements(Integer line, Integer column)
    {
        ArrayList<Integer[]> movements = new ArrayList<>();
        movements.add(new Integer[] {line, column});

        // can go north if (AND)
        // - not on the border (line > 0)
        // - tile/orientation allows north movement
        // - northern tile/orientation allows south movement
        if (line > 0 && getTile(line, column).canMoveNorth() && getTile(line - 1, column).canMoveSouth())
        {
            movements.add(new Integer[]{line - 1, column});
        }

        // can go south
        // - not on the border (line < 6)
        // - tile/orientation allows south movement
        // - southern tile/orientation allows north movement
        if (line < 6 && getTile(line, column).canMoveSouth() && getTile(line + 1, column).canMoveNorth())
        {
            movements.add(new Integer[]{line + 1, column});
        }

        // can go east
        // - not on the border (column < 6)
        // - tile/orientation allows east movement
        // - eastern tile/orientation allows west movement
        if (column < 6 && getTile(line, column).canMoveEast() && getTile(line, column + 1).canMoveWest())
        {
            movements.add(new Integer[]{line, column + 1});
        }

        // can go west
        // - not on the border (column > 0)
        // - tile/orientation allows west movement
        // - western tile/orientation allows east movement
        if (column > 0 && getTile(line, column).canMoveWest() && getTile(line, column - 1).canMoveEast())
        {
            movements.add(new Integer[]{line, column - 1});
        }

        return movements;
    }

    public void addObserver(BoardObserver observer)
    {
        _observers.add(observer);
    }

    public void removeAllObservers()
    {
        _observers.clear();
    }

    public void notifyBoardChanged()
    {
        for (BoardObserver observer : _observers)
        {
            observer.updateBoard(getTiles());
        }
    }
}
