package labyrinth;

import java.awt.*;
import java.awt.image.BufferedImage;

public class ImageUtils
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    public static BufferedImage copyImage(BufferedImage image)
    {
        BufferedImage res = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
        Graphics g = res.getGraphics();
        g.drawImage(image, 0, 0, null);
        g.dispose();
        return res;
    }

    public static BufferedImage scaleImage(BufferedImage image, int width, int height)
    {
        Image tmp = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage res = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = res.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();
        return res;
    }

    // all images need to be scaled !
    public static BufferedImage superimposeImages(BufferedImage image1, BufferedImage image2)
    {
        BufferedImage merged = copyImage(image1);
        Graphics2D g2d = merged.createGraphics();
        g2d.drawImage(image1, 0, 0, null);
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
        g2d.drawImage(image2, 0,0, null);
        g2d.dispose();
        return merged;
    }

    public static BufferedImage rotateImageClockwise(BufferedImage image)
    {
        BufferedImage rotated = copyImage(image);
        Graphics2D g2d = rotated.createGraphics();
        g2d.rotate(0.5 * Math.PI, image.getWidth()/2., image.getHeight()/2.);
        g2d.drawRenderedImage(image, null);
        g2d.dispose();
        return rotated;
    }

    public static BufferedImage rotateImageCounterClockwise(BufferedImage image)
    {
        BufferedImage rotated = copyImage(image);
        Graphics2D g2d = rotated.createGraphics();
        g2d.rotate(1.5 * Math.PI, image.getWidth()/2., image.getHeight()/2.);
        g2d.drawRenderedImage(image, null);
        g2d.dispose();
        return rotated;
    }
}
