package labyrinth.model.tile;

public class BranchingTile extends Tile
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public BranchingTile()
    {
        super(TileType.BRANCHING);
    }

    public BranchingTile(TileOrientation orientation)
    {
        super(TileType.BRANCHING, orientation);
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    @Override
    public Boolean canMoveNorth()
    {
        switch (getOrientation())
        {
            case EAST, WEST, SOUTH ->
            {
                return Boolean.TRUE;
            }
            case NORTH ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveSouth()
    {
        switch (getOrientation())
        {
            case NORTH, EAST, WEST ->
            {
                return Boolean.TRUE;
            }
            case SOUTH ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveEast()
    {
        switch (getOrientation())
        {
            case NORTH, SOUTH, WEST ->
            {
                return Boolean.TRUE;
            }
            case EAST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveWest()
    {
        switch (getOrientation())
        {
            case NORTH, SOUTH, EAST ->
            {
                return Boolean.TRUE;
            }
            case WEST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }
}
