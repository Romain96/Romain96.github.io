package labyrinth.model.objective;

import java.awt.image.BufferedImage;

public class Objective
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    private static Integer _idgen = 0;
    private Integer _id;
    private String _name;
    private BufferedImage _image;

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public Objective(String name)
    {
        _id = _idgen++;
        _name = name;
        _image = null;
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    public Integer getId()
    {
        return _id;
    }

    public String getName()
    {
        return _name;
    }

    public BufferedImage getImage()
    {
        return _image;
    }

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    public void setId(Integer id)
    {
        _id = id;
    }

    public void setName(String name)
    {
        _name = name;
    }

    public void setImage(BufferedImage image)
    {
        _image = image;
    }

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------
}
