package labyrinth.model.tile;

public class StraightTile extends Tile
{
    //-------------------------------------------------------------------------
    // attributes
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // constructors
    //-------------------------------------------------------------------------

    public StraightTile()
    {
        super(TileType.STRAIGHT);
    }

    public StraightTile(TileOrientation orientation)
    {
        super(TileType.STRAIGHT, orientation);
    }

    //-------------------------------------------------------------------------
    // getters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // setters
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // methods
    //-------------------------------------------------------------------------

    @Override
    public Boolean canMoveNorth()
    {
        switch (getOrientation())
        {
            case NORTH, SOUTH ->
            {
                return Boolean.TRUE;
            }
            case EAST, WEST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveSouth()
    {
        switch (getOrientation())
        {
            case NORTH, SOUTH ->
            {
                return Boolean.TRUE;
            }
            case EAST, WEST ->
            {
                return Boolean.FALSE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveEast()
    {
        switch (getOrientation())
        {
            case NORTH, SOUTH ->
            {
                return Boolean.FALSE;
            }
            case EAST, WEST ->
            {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean canMoveWest()
    {
        switch (getOrientation())
        {
            case NORTH, SOUTH ->
            {
                return Boolean.FALSE;
            }
            case EAST, WEST ->
            {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }
}
