package labyrinth.model.observer;

import labyrinth.model.Board;
import labyrinth.model.Player;
import labyrinth.model.tile.Tile;

import java.util.ArrayList;

public interface GameObserver
{
    void updateStartGameView(Board board, Player[] players, Tile spareTile);
    void updateSpareTileChanged(Tile spareTile);
    void updateSpareTileRotated(Tile spareTile);
    void updatePlayerMoved(Integer playerIndex, Tile oldTile, Integer oldLine, Integer oldColumn, Tile newTile, Integer newLine, Integer newColumn);
    void updateAllowedMovements(ArrayList<Integer[]> movements);
    void updateCanInsertTile(Boolean canInsert);
    void updatePlayerTurnEnded(Player player);
    void updatePlayerWon(Player player);
}
