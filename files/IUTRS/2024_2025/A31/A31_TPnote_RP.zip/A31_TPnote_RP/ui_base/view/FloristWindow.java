package florist.view;

import florist.controller.FloristController;
import florist.model.Florist;
import florist.model.FloristObserver;
import florist.model.FlowerBouquet;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class FloristWindow extends JFrame implements FloristObserver
{

	private JLabel _nbFlowers;
	private JTextArea _listeFlowers;
	private JLabel _messageFlower;
	private JLabel _messageCaisse;
	private FloristController controller;

	// buttons for opening and closing the store
	private JButton boutonOuvrir;
	private JButton boutonFermer;

	// buttons for creating flower bouquets
	private JButton buttonPrepareLilies;
	private JButton buttonPrepareMimosa;
	private JButton buttonPrepareOrchid;
	private JButton buttonPrepareTulips;

	// buttons for selling flower bouquets
	private JButton buttonSellLilies;
	private JButton buttonSellMimosa;
	private JButton buttonSellOrchid;
	private JButton buttonSellTulips;

	// buttons for sorting flower bouquets
	private JButton buttonSortSpecies;
	private JButton boutonSortPrice;

	public FloristWindow(FloristController controller, Florist store)
	{
		super("Florist app");
		setDefaultCloseOperation( EXIT_ON_CLOSE );

		this.controller = controller;

		// 1ère ligne : Nombre de bouquets de fleurs
		JPanel panelNbFlowers = new JPanel(new FlowLayout());
		panelNbFlowers.add( new JLabel("Nombre de bouquets de fleurs : ") );
		_nbFlowers = new JLabel("[TODO]");
		panelNbFlowers.add( _nbFlowers );

		// 2ème ligne : Total de ventes
		JPanel panelCaisse = new JPanel(new FlowLayout());
		panelCaisse.add( new JLabel("Total de vente : ") );
		_messageCaisse = new JLabel("[TODO]");
		panelCaisse.add( _messageCaisse );

		// 3ème ligne : détails du dernier bouquet ajouté
		_messageFlower = new JLabel("[TODO]");
		_messageFlower.setHorizontalAlignment(JLabel.CENTER);

		// Les deux boutons pour l'ouverture et la fermeture de la boutique
		JPanel panelOpenClose = new JPanel(new FlowLayout());
		boutonOuvrir = new JButton("Ouvrir la boutique");
		boutonOuvrir.addActionListener(e -> {this.controller.openStore();});
		boutonFermer = new JButton("Fermer la boutique");
		boutonFermer.addActionListener(e -> {this.controller.closeStore();});
		panelOpenClose.add( boutonOuvrir );
		panelOpenClose.add( boutonFermer );

		// Panneau regroupant tout ce qu'il y a au-dessus de la zone de texte listant les bouquets
		JPanel panelInfos = new JPanel( new GridLayout( 0, 1 ) );
		panelInfos.add( panelNbFlowers );
		panelInfos.add( panelCaisse );
		panelInfos.add( _messageFlower );
		panelInfos.add( panelOpenClose );

		// Zone de texte listant les bouquets
		_listeFlowers = new JTextArea("");
		_listeFlowers.setEditable(false);
		_listeFlowers.setOpaque(false);
		JScrollPane scroll = new JScrollPane(_listeFlowers);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		// 1ère colonne avec 4 boutons pour confectionner les bouquets
		JPanel boutonCookPanel = new JPanel( new GridLayout( 0, 1 ) );
		boutonCookPanel.add( new JLabel("Confectionner :") );
		buttonPrepareLilies = new JButton("Lilas");
		buttonPrepareLilies.addActionListener(e -> {this.controller.createLiliesBouquet();});
		boutonCookPanel.add( buttonPrepareLilies );
		buttonPrepareMimosa = new JButton("Mimosa");
		buttonPrepareMimosa.addActionListener(e -> {this.controller.createMimosasBouquet();});
		boutonCookPanel.add( buttonPrepareMimosa );
		buttonPrepareOrchid = new JButton("Orchidées");
		buttonPrepareOrchid.addActionListener(e -> {this.controller.createOrchidsBouquet();});
		boutonCookPanel.add( buttonPrepareOrchid );
		buttonPrepareTulips = new JButton("Tulipes");
		buttonPrepareTulips.addActionListener(e -> {this.controller.createTulipsBouquet();});
		boutonCookPanel.add( buttonPrepareTulips );

		// 2ème colonne avec 4 boutons pour vendre les bouquets
		JPanel boutonSellPanel = new JPanel( new GridLayout( 0, 1 ) );
		boutonSellPanel.add( new JLabel("Vendre :") );
		buttonSellLilies = new JButton("Lilas");
		buttonSellLilies.addActionListener(e -> {this.controller.sellLiliesBouquet();});
		boutonSellPanel.add( buttonSellLilies );
		buttonSellMimosa = new JButton("Mimosa");
		buttonSellMimosa.addActionListener(e -> {this.controller.sellMimosasBouquet();});
		boutonSellPanel.add( buttonSellMimosa );
		buttonSellOrchid = new JButton("Orchidées");
		buttonSellOrchid.addActionListener(e -> {this.controller.sellOrchidsBouquet();});
		boutonSellPanel.add( buttonSellOrchid );
		buttonSellTulips = new JButton("Tulipes");
		buttonSellTulips.addActionListener(e -> {this.controller.sellTulipsBouquet();});
		boutonSellPanel.add( buttonSellTulips );

		// 3ème colonne avec 2 boutons pour trier les bouquets
		JPanel boutonSortPanel = new JPanel( new GridLayout( 0, 1 ) );
		boutonSortPanel.add( new JLabel("Trier :") );
		buttonSortSpecies = new JButton("Par espèce");
		buttonSortSpecies.addActionListener(e -> {this.controller.sortByType();});
		boutonSortPanel.add( buttonSortSpecies );
		boutonSortPrice = new JButton("Par prix");
		boutonSortPrice.addActionListener(e -> {this.controller.sortByPrice();});
		boutonSortPanel.add( boutonSortPrice );

		// Panneau regroupant les 3 colonnes de boutons
		JPanel panelBoutons = new JPanel();
		panelBoutons.setLayout( new GridLayout( 1, 0 ) );
		panelBoutons.add( boutonCookPanel );
		panelBoutons.add( boutonSellPanel );
		panelBoutons.add( boutonSortPanel );

		// Ajout des 3 panneaux à la fenêtre
		setLayout( new BorderLayout() );
		add( panelInfos, BorderLayout.NORTH );
		add( scroll, BorderLayout.CENTER );
		add( panelBoutons, BorderLayout.SOUTH );

		// Paramétrage et affichage de la fenêtre
		setMinimumSize(new Dimension(450,442));
		pack();
		setVisible( true );

		init(store);
	}

	private void updateFlowerBouquets(ArrayList<FlowerBouquet> bouquets)
	{
		String message = "";
		for (FlowerBouquet bouquet : bouquets)
		{
			message += bouquet.getName() + " (" + bouquet.getPrice() + " €)" + "\n";
		}
		_listeFlowers.setText(message);
	}

	// initial update
	private void init(Florist store)
	{
		_nbFlowers.setText("" + store.getBouquets().size());
		_messageFlower.setText("The store is closed !");
		_messageCaisse.setText("0 €");
		this.updateFlowerBouquets(store.getBouquets());
		this.closeStoreUpdateButtons();
	}

	// to enable buttons for creating, sorting and selling bouquets and for opening the store
	private void openStoreUpdateButtons()
	{
		this.boutonOuvrir.setEnabled(false);
		this.boutonFermer.setEnabled(true);
		this.buttonPrepareLilies.setEnabled(true);
		this.buttonPrepareMimosa.setEnabled(true);
		this.buttonPrepareOrchid.setEnabled(true);
		this.buttonPrepareTulips.setEnabled(true);
		this.buttonSellLilies.setEnabled(true);
		this.buttonSellMimosa.setEnabled(true);
		this.buttonSellOrchid.setEnabled(true);
		this.buttonSellTulips.setEnabled(true);
		this.buttonSortSpecies.setEnabled(true);
		this.boutonSortPrice.setEnabled(true);
	}

	// to disable buttons for creating, sorting and selling bouquets and for closing the store
	private void closeStoreUpdateButtons()
	{
		this.boutonOuvrir.setEnabled(true);
		this.boutonFermer.setEnabled(false);
		this.buttonPrepareLilies.setEnabled(false);
		this.buttonPrepareMimosa.setEnabled(false);
		this.buttonPrepareOrchid.setEnabled(false);
		this.buttonPrepareTulips.setEnabled(false);
		this.buttonSellLilies.setEnabled(false);
		this.buttonSellMimosa.setEnabled(false);
		this.buttonSellOrchid.setEnabled(false);
		this.buttonSellTulips.setEnabled(false);
		this.buttonSortSpecies.setEnabled(false);
		this.boutonSortPrice.setEnabled(false);
	}

	@Override
	public void updateStoreOpened(ArrayList<FlowerBouquet> bouquets)
	{
		_nbFlowers.setText("" + bouquets.size());
		this.updateFlowerBouquets(bouquets);
		_messageFlower.setText("The store is opened !");
		_messageCaisse.setText("0 €");
		this.openStoreUpdateButtons();
	}

	@Override
	public void updateStoreClosed()
	{
		_nbFlowers.setText("0");
		_listeFlowers.setText("");
		_messageFlower.setText("The store is closed !");
		this.closeStoreUpdateButtons();
	}

	@Override
	public void updateBouquetAdded(ArrayList<FlowerBouquet> bouquets, FlowerBouquet addedBouquet)
	{
		this.updateFlowerBouquets(bouquets);
		_messageFlower.setText("Creating one " + addedBouquet.getName() + " in the store.");
		_nbFlowers.setText("" + bouquets.size());
	}

	@Override
	public void updateBouquetSold(ArrayList<FlowerBouquet> bouquets, FlowerBouquet soldBouquet, double total)
	{
		this.updateFlowerBouquets(bouquets);
		_messageFlower.setText("Selling one " + soldBouquet.getName() + " for " + soldBouquet.getPrice() + " €.");
		_nbFlowers.setText("" + bouquets.size());
		_messageCaisse.setText(total + " €");
	}

	@Override
	public void updateBouquetSorted(ArrayList<FlowerBouquet> bouquets)
	{
		this.updateFlowerBouquets(bouquets);
		_messageFlower.setText("Sorting the list of bouquets.");
		_nbFlowers.setText("" + bouquets.size());
	}
}
