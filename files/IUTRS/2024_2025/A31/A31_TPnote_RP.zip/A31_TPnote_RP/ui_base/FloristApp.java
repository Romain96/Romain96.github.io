package florist;

import florist.controller.FloristController;
import florist.model.Florist;
import florist.view.FloristWindow;

public class FloristApp
{
    public static void main(String[] args)
    {
        System.out.println("Hello world !");
        Florist store = new Florist();
        FloristController storeController = new FloristController(store);
        FloristWindow view = new FloristWindow(storeController, store);
        store.addObserver(view);
    }

}
