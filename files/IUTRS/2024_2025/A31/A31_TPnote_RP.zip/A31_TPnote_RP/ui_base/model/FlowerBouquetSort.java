package florist.model;

import java.util.ArrayList;

public interface FlowerBouquetSort
{
    void sortBouquets(ArrayList<FlowerBouquet> bouquets);
}
