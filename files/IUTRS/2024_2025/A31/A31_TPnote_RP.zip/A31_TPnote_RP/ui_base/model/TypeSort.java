package florist.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class TypeSort implements FlowerBouquetSort
{
    @Override
    public void sortBouquets(ArrayList<FlowerBouquet> bouquets)
    {
        Collections.sort(bouquets, Comparator.comparing(FlowerBouquet::getName));
    }
}
