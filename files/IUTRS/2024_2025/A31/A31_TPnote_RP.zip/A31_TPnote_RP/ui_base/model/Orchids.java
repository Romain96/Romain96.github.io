package florist.model;

public class Orchids extends FlowerBouquet
{
    // constructor
    public Orchids()
    {
        super("Orchids", FlowerType.ORCHIDS, 60.40);
    }
}
