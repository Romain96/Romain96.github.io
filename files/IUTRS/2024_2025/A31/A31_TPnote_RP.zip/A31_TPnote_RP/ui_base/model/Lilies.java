package florist.model;

public class Lilies extends FlowerBouquet
{
    // constructor
    public Lilies()
    {
        super("Lilies", FlowerType.LILIES, 29.90);
    }
}
