package florist.model;

public class Tulips extends FlowerBouquet
{
    // constructor
    public Tulips()
    {
        super("Tulips", FlowerType.TULIPS, 20.80);
    }
}
