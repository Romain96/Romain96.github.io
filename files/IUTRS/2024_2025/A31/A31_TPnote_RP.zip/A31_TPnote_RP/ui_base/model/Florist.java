package florist.model;

import java.util.ArrayList;

public class Florist
{
    private boolean opened;
    private ArrayList<FlowerBouquet> bouquets;
    private double totalSales;
    private final ArrayList<FloristObserver> observers;
    private FlowerBouquetSort sortStrategy;
    private FlowerBouquetFactory factory;

    // constructor
    public Florist()
    {
        this.opened = false;
        this.bouquets = new ArrayList<>();
        this.totalSales = 0.0;
        this.observers = new ArrayList<>();
        this.factory = new FlowerBouquetFactory();
    }

    // getters
    public boolean getOpened()
    {
        return this.opened;
    }

    public ArrayList<FlowerBouquet> getBouquets()
    {
        return this.bouquets;
    }

    public double getTotalSales()
    {
        return this.totalSales;
    }

    public FlowerBouquetSort getSortStrategy()
    {
        return sortStrategy;
    }

    public FlowerBouquetFactory getFactory()
    {
        return factory;
    }

    // setters
    public void setOpened(boolean opened)
    {
        this.opened = opened;
    }

    public void setFlowerBouquets(ArrayList<FlowerBouquet> bouquets)
    {
        this.bouquets = bouquets;
    }

    public void setTotalSales(double totalSales)
    {
        this.totalSales = totalSales;
    }

    public void setSortStrategy(FlowerBouquetSort sortStrategy)
    {
        this.sortStrategy = sortStrategy;
    }

    public void setFactory(FlowerBouquetFactory factory)
    {
        this.factory = factory;
    }

    // method - adding an observer
    public void addObserver(FloristObserver observer)
    {
        this.observers.add(observer);
    }

    // method - executing the strategy (+ notification)
    public void sortBouquets()
    {
        this.sortStrategy.sortBouquets(this.getBouquets());
        this.notifyBouquetSorted();
    }

    // methods - opening and closing the store
    public void openStore()
    {
        this.opened = true;
        this.totalSales = 0.0;
        // initial creation of each type of bouquet
        this.bouquets.clear();
        this.bouquets.add(this.factory.createLilies());
        this.bouquets.add(this.factory.createMimosas());
        this.bouquets.add(this.factory.createOrchids());
        this.bouquets.add(this.factory.createTulips());
        this.notifyStoreOpened();
    }

    public void closeStore()
    {
        this.opened = false;
        this.notifyStoreClosed();
    }

    // methods - creating and selling bouquets
    public void createBouquet(FlowerType type)
    {
        FlowerBouquet bouquet = null;
        switch (type)
        {
            case LILIES -> bouquet = this.getFactory().createLilies();
            case MIMOSAS -> bouquet = this.getFactory().createMimosas();
            case ORCHIDS -> bouquet = this.getFactory().createOrchids();
            case TULIPS -> bouquet = this.getFactory().createTulips();
            case UNDEFINED -> {
                System.out.println("Cannot create a bouquet composed of UNDEFINED flower type !");
                return;
            }
        }
        this.getBouquets().add(bouquet);
        this.notifyBouquetCreated(bouquet);
    }

    public void sellBouquet(FlowerType type)
    {
        // removing the first bouquet matching the type from bouquets
        for (int i = 0; i < this.getBouquets().size(); i++)
        {
            if (this.getBouquets().get(i).getType() == type)
            {
                this.setTotalSales(this.getTotalSales() + this.getBouquets().get(i).getPrice());
                FlowerBouquet sold = this.getBouquets().get(i);
                this.getBouquets().remove(i);
                this.notifyBouquetSold(sold);
                return;
            }
        }
    }

    // methods - for FlowerObserver notifications
    public void notifyStoreOpened()
    {
        for (FloristObserver observer : this.observers)
        {
            observer.updateStoreOpened(this.getBouquets());
        }
    }

    public void notifyStoreClosed()
    {
        for (FloristObserver observer : this.observers)
        {
            observer.updateStoreClosed();
        }
    }

    public void notifyBouquetSold(FlowerBouquet bouquet)
    {
        for (FloristObserver observer : this.observers)
        {
            observer.updateBouquetSold(this.getBouquets(), bouquet, this.getTotalSales());
        }
    }

    public void notifyBouquetCreated(FlowerBouquet bouquet)
    {
        for (FloristObserver observer : this.observers)
        {
            observer.updateBouquetAdded(this.getBouquets(), bouquet);
        }
    }

    public void notifyBouquetSorted()
    {
        for (FloristObserver observer : this.observers)
        {
            observer.updateBouquetSorted(this.getBouquets());
        }
    }
}
