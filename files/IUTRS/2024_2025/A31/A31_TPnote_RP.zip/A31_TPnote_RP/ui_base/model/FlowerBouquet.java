package florist.model;

public abstract class FlowerBouquet
{
    private String name;
    private FlowerType type;
    private double price;

    // constructor
    public FlowerBouquet(String name, FlowerType type, double price)
    {
        this.name = name;
        this.type = type;
        this.price = price;
    }

    // getters
    public String getName()
    {
        return this.name;
    }

    public FlowerType getType()
    {
        return this.type;
    }

    public double getPrice()
    {
        return this.price;
    }

    // setters
    public void setName(String name)
    {
        this.name = name;
    }

    public void setType(FlowerType type)
    {
        this.type = type;
    }

    public void setPrice(double price)
    {
        this.price = price;
    }
}
