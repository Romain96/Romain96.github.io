package florist.model;

public class FlowerBouquetFactory
{
    public FlowerBouquet createLilies()
    {
        return new Lilies();
    }

    public FlowerBouquet createMimosas()
    {
        return new Mimosas();
    }

    public FlowerBouquet createOrchids()
    {
        return new Orchids();
    }

    public FlowerBouquet createTulips()
    {
        return new Tulips();
    }
}
