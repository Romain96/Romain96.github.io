package florist.model;

public enum FlowerType
{
    UNDEFINED,
    LILIES,
    MIMOSAS,
    ORCHIDS,
    TULIPS;
}
