package florist.model;

public class Mimosas extends FlowerBouquet
{
    public Mimosas()
    {
        super("Mimosas", FlowerType.MIMOSAS, 15.50);
    }
    // constructor

}
