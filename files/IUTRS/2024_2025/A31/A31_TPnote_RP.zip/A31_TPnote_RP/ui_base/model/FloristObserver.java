package florist.model;

import java.util.ArrayList;

public interface FloristObserver
{
    void updateStoreOpened(ArrayList<FlowerBouquet> bouquets);
    void updateStoreClosed();
    void updateBouquetAdded(ArrayList<FlowerBouquet> bouquets, FlowerBouquet addedBouquet);
    void updateBouquetSold(ArrayList<FlowerBouquet> bouquets, FlowerBouquet soldBouquet, double total);
    void updateBouquetSorted(ArrayList<FlowerBouquet> bouquets);
}
