package florist.controller;

import florist.model.Florist;
import florist.model.FlowerType;
import florist.model.PriceSort;
import florist.model.TypeSort;

public class FloristController
{
    public Florist store;

    // constructor
    public FloristController(Florist store)
    {
        this.store = store;
    }

    // getters
    public Florist getStore()
    {
        return this.store;
    }

    // setters
    public void setStore(Florist store)
    {
        this.store = store;
    }

    // methods

    // opens the store
    public void openStore()
    {
        this.getStore().openStore();
    }

    // closes the store
    public void closeStore()
    {
        this.getStore().closeStore();
    }

    // sort by price
    public void sortByPrice()
    {
        this.getStore().setSortStrategy(new PriceSort());
        this.getStore().sortBouquets();
    }

    // sort by type (item name)
    public void sortByType()
    {
        this.getStore().setSortStrategy(new TypeSort());
        this.getStore().sortBouquets();
    }

    // create bouquet - all 4 types

    public void createLiliesBouquet()
    {
        this.getStore().createBouquet(FlowerType.LILIES);
    }
    public void createMimosasBouquet()
    {
        this.getStore().createBouquet(FlowerType.MIMOSAS);
    }
    public void createOrchidsBouquet()
    {
        this.getStore().createBouquet(FlowerType.ORCHIDS);
    }
    public void createTulipsBouquet()
    {
        this.getStore().createBouquet(FlowerType.TULIPS);
    }

    // sell bouquet - all 4 types

    public void sellLiliesBouquet()
    {
        this.getStore().sellBouquet(FlowerType.LILIES);
    }
    public void sellMimosasBouquet()
    {
        this.getStore().sellBouquet(FlowerType.MIMOSAS);
    }
    public void sellOrchidsBouquet()
    {
        this.getStore().sellBouquet(FlowerType.ORCHIDS);
    }
    public void sellTulipsBouquet()
    {
        this.getStore().sellBouquet(FlowerType.TULIPS);
    }
}
