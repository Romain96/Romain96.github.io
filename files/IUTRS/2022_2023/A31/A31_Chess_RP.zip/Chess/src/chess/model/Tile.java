package chess.model;

import chess.model.piece.Piece;

import java.awt.image.BufferedImage;

public class Tile
{
    private Integer _line;
    private Integer _column;
    private Piece _piece;
    private BufferedImage _image;

    public Tile(Integer line, Integer column)
    {
        _line = line;
        _column = column;
        _piece = null;
        _image = null;
    }

    public Tile(Integer line, Integer column, Piece piece)
    {
        _line = line;
        _column = column;
        _piece = piece;
    }

    public Integer getLine()
    {
        return _line;
    }

    public Integer getColumn()
    {
        return _column;
    }

    public Piece getPiece()
    {
        return _piece;
    }

    public BufferedImage getImage()
    {
        return _image;
    }

    public void setLine(Integer line)
    {
        _line = line;
    }

    public void setColumn(Integer column)
    {
        _column = column;
    }

    public void setPiece(Piece piece)
    {
        _piece = piece;
    }

    public void setImage(BufferedImage image)
    {
        _image = image;
    }
}
