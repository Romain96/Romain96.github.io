package chess.model.piece;

import chess.model.movement.MovementContext;
import chess.model.player.PlayerColor;

public class Bishop extends Piece
{
    public Bishop(PlayerColor color, MovementContext movements)
    {
        super(color, movements);
    }
}
