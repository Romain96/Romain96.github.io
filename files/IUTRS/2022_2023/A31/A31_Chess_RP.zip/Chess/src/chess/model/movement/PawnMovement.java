package chess.model.movement;

import java.util.ArrayList;
import java.util.List;

public class PawnMovement extends PieceMovement
{
    private Boolean _isBlack;

    public PawnMovement(Boolean isBlack)
    {
        super(2);
        _isBlack = isBlack;
    }

    public Boolean getIsBlack()
    {
        return _isBlack;
    }

    public void setIsBlack(Boolean isBlack)
    {
        _isBlack = isBlack;
    }

    @Override
    public List<List<Coordinate>> getSimpleMovements(Coordinate position)
    {
        List<List<Coordinate>> coordinates = new ArrayList<>();
        List<Coordinate> path = new ArrayList<>();
        int offset = 1;
        if (getIsBlack())
        {
            while (offset <= getRepeat())
            {
                if (position.getLine() + offset <= 7)
                {
                    path.add(new Coordinate(position.getLine() + offset, position.getColumn()));
                }
                offset++;
            }
        }
        else
        {
            while (offset <= getRepeat())
            {
                if (position.getLine() - offset >= 0)
                {
                    path.add(new Coordinate(position.getLine() - offset, position.getColumn()));
                }
                offset++;
            }
        }
        coordinates.add(path);
        return coordinates;
    }

    @Override
    public List<List<Coordinate>> getCaptureMovements(Coordinate position)
    {
        List<List<Coordinate>> movements = new ArrayList<>();

        // move to bottom
        if (getIsBlack())
        {
            List<Coordinate> leftCapture = new ArrayList<>();
            List<Coordinate> rightCapture = new ArrayList<>();
            if (position.getLine() < 7)
            {
                if (position.getColumn() > 0)
                {
                    leftCapture.add(new Coordinate(position.getLine() + 1, position.getColumn() - 1));
                }
                if (position.getColumn() < 7)
                {
                    rightCapture.add(new Coordinate(position.getLine() + 1, position.getColumn() + 1));
                }
            }
            movements.add(leftCapture);
            movements.add(rightCapture);
        }
        // move to top
        else
        {
            List<Coordinate> leftCapture = new ArrayList<>();
            List<Coordinate> rightCapture = new ArrayList<>();
            if (position.getLine() > 0)
            {
                if (position.getColumn() > 0)
                {
                    leftCapture.add(new Coordinate(position.getLine() - 1, position.getColumn() - 1));
                }
                if (position.getColumn() < 7)
                {
                    rightCapture.add(new Coordinate(position.getLine() - 1, position.getColumn() + 1));
                }
            }
            movements.add(leftCapture);
            movements.add(rightCapture);
        }

        return movements;
    }
}
