package chess;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImageUtils
{
    public static BufferedImage loadImage(String path) throws IOException
    {
        try
        {
            return ImageIO.read(new File(path));
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    public static BufferedImage scaleImage(BufferedImage image, Integer size)
    {
        Image tmp = image.getScaledInstance(size, size, Image.SCALE_SMOOTH);
        BufferedImage scaled = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = scaled.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();
        return scaled;
    }

    public static BufferedImage superimposeImages(BufferedImage image1, BufferedImage image2)
    {
        BufferedImage merged = new BufferedImage(image1.getWidth(), image1.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = merged.createGraphics();
        g2d.drawImage(image1, 0, 0,null);
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
        g2d.drawImage(image2, 0, 0, null);
        g2d.dispose();
        return merged;
    }

    public static BufferedImage copyImage(BufferedImage image)
    {
        BufferedImage copy = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
        Graphics g = copy.createGraphics();
        g.drawImage(image, 0, 0, null);
        g.dispose();
        return copy;
    }
}
