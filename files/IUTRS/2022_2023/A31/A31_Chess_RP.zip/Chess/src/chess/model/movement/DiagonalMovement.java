package chess.model.movement;

import java.util.ArrayList;
import java.util.List;

public class DiagonalMovement extends PieceMovement
{
    public DiagonalMovement(Integer repeat)
    {
        super(repeat);
    }

    @Override
    public List<List<Coordinate>> getSimpleMovements(Coordinate position)
    {
        List<List<Coordinate>> coordinates = new ArrayList<>();
        List<Coordinate> topLeftPath = new ArrayList<>();
        List<Coordinate> topRightPath = new ArrayList<>();
        List<Coordinate> bottomLeftPath = new ArrayList<>();
        List<Coordinate> bottomRightPath = new ArrayList<>();

        int lineOffset = 1;
        int columnOffset = 1;
        while (lineOffset <= getRepeat() && columnOffset <= getRepeat())
        {
            // top left half diagonal
            if (position.getLine() - lineOffset >= 0 && position.getColumn() - columnOffset >= 0)
            {
                topLeftPath.add(new Coordinate(position.getLine() - lineOffset, position.getColumn() - columnOffset));
            }
            // top right half diagonal
            if (position.getLine() - lineOffset >= 0 && position.getColumn() + columnOffset <= 7)
            {
                topRightPath.add(new Coordinate(position.getLine() - lineOffset, position.getColumn() + columnOffset));
            }
            // bottom left half diagonal
            if (position.getLine() + lineOffset <= 7 && position.getColumn() - columnOffset >= 0)
            {
                bottomLeftPath.add(new Coordinate(position.getLine() + lineOffset, position.getColumn() - columnOffset));
            }
            // bottom right half diagonal
            if (position.getLine() + lineOffset <= 7 && position.getColumn() + columnOffset <= 7)
            {
                bottomRightPath.add(new Coordinate(position.getLine() + lineOffset, position.getColumn() + columnOffset));
            }
            lineOffset++;
            columnOffset++;
        }
        coordinates.add(topLeftPath);
        coordinates.add(topRightPath);
        coordinates.add(bottomLeftPath);
        coordinates.add(bottomRightPath);
        return coordinates;
    }

    @Override
    public List<List<Coordinate>> getCaptureMovements(Coordinate position)
    {
        return getSimpleMovements(position);
    }
}
