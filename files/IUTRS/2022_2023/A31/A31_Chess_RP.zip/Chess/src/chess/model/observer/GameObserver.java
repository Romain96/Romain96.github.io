package chess.model.observer;

import chess.model.Tile;
import chess.model.movement.Coordinate;
import chess.model.player.PlayerColor;

import java.util.List;

public interface GameObserver
{
    void updatePlayerTurn(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player);
    void updateTileSelected(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player, Integer selectLine, Integer selectColumn);
    void updateTileUnselected(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player, Integer selectLine, Integer selectColumn);
    void updateShowAllowedMoves(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player, Coordinate selected, List<Coordinate> allowed, List<Coordinate> capture);
    void updateGameEnded(PlayerColor winner, PlayerColor looser);
    void updatePromotePawn(Integer line, Integer column);
}

