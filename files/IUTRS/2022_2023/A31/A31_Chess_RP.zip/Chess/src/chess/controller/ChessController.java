package chess.controller;

import chess.model.Game;
import chess.model.movement.Coordinate;
import chess.model.player.PlayerColor;
import chess.view.ChessView;

import java.util.Objects;

public class ChessController
{
    private Game _game;

    public ChessController(Game game)
    {
        _game = game;
    }

    public Game getGame()
    {
        return _game;
    }

    public void setGame(Game game)
    {
        _game = game;
    }

    public void startGame(ChessView view)
    {
        getGame().resetGame();
        getGame().removeAllObservers();
        getGame().addObserver(view);
        getGame().getBoard().removeAllObservers();
        getGame().getBoard().addObserver(view);
        // forcing an update of the view
        getGame().getBoard().notifyBoardChanged();
        getGame().setCurrentPlayer(PlayerColor.WHITE);
        getGame().notifyPlayerTurn();
    }

    public void selectTile(Integer line, Integer column)
    {
        // if no piece is currently selected
        if (!getGame().hasSelectedAPiece())
        {
            if (getGame().getBoard().getTile(line, column).getPiece() != null && getGame().getBoard().getTile(line, column).getPiece().getColor() == getGame().getCurrentPlayer())
            {
                // the piece on the selected tile is now the selected piece
                getGame().setSelectedPiece(new Coordinate(line, column));
                getGame().notifyTileSelected();

                // compute the possible movements from the selected piece and updates the view
                getGame().determineAllMovesFromSelectedTile();
            }
        }
        else
        {
            // if the selected tile contains the currently-selected piece, unselect it
            if (Objects.equals(getGame().getSelectedPiece().getLine(), line) && Objects.equals(getGame().getSelectedPiece().getColumn(), column))
            {
                getGame().notifyTileUnselected();
                getGame().setSelectedPiece(new Coordinate(-1, -1));
            }
            else
            {
                // the move if a simple move
                for (Coordinate allowedCoordinate : getGame().getAllowedMoves())
                {
                    if (Objects.equals(allowedCoordinate.getLine(), line) && Objects.equals(allowedCoordinate.getColumn(), column))
                    {
                        movePieceToTile(line, column);
                        getGame().verifyKingIsInCheckmate();
                        return;
                    }
                }
                // the move is a capture move
                for (Coordinate captureCoordinate : getGame().getCaptureMoves())
                {
                    if (Objects.equals(captureCoordinate.getLine(), line) && Objects.equals(captureCoordinate.getColumn(), column))
                    {
                        capturePieceAndMoveToTile(line, column);
                        getGame().verifyKingIsInCheckmate();
                        return;
                    }
                }
            }
        }
    }

    public void movePieceToTile(Integer line, Integer column)
    {
        Integer originalLine = getGame().getSelectedPiece().getLine();
        Integer originalColumn = getGame().getSelectedPiece().getColumn();
        getGame().setSelectedPiece(new Coordinate(-1, -1));
        getGame().moveOrCapturePieceToTile(originalLine, originalColumn, line, column);
    }

    public void capturePieceAndMoveToTile(Integer line, Integer column)
    {
        Integer originalLine = getGame().getSelectedPiece().getLine();
        Integer originalColumn = getGame().getSelectedPiece().getColumn();
        getGame().setSelectedPiece(new Coordinate(-1, -1));
        getGame().moveOrCapturePieceToTile(originalLine, originalColumn, line, column);
    }

    public void promotePawnToQueen(Integer line, Integer column)
    {
        getGame().promotePawnToQueen(line, column);
    }

    public void promotePawnToKnight(Integer line, Integer column)
    {
        getGame().promotePawnToKnight(line, column);
    }

    public void promotePawnToRook(Integer line, Integer column)
    {
        getGame().promotePawnToRook(line, column);
    }

    public void promotePawnToBishop(Integer line, Integer column)
    {
        getGame().promotePawnToBishop(line, column);
    }
}
