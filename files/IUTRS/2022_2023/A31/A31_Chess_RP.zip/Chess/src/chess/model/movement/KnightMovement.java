package chess.model.movement;

import java.util.ArrayList;
import java.util.List;

public class KnightMovement extends PieceMovement
{
    public KnightMovement(Integer repeat)
    {
        super(repeat);
    }

    @Override
    public List<List<Coordinate>> getSimpleMovements(Coordinate position)
    {
        List<List<Coordinate>> coordinates = new ArrayList<>();
        List<Coordinate> topLeftPath = new ArrayList<>();
        List<Coordinate> topRightPath = new ArrayList<>();
        List<Coordinate> bottomLeftPath = new ArrayList<>();
        List<Coordinate> bottomRightPath = new ArrayList<>();
        List<Coordinate> leftTopPath = new ArrayList<>();
        List<Coordinate> leftBottomPath = new ArrayList<>();
        List<Coordinate> rightTopPath = new ArrayList<>();
        List<Coordinate> rightBottomPath = new ArrayList<>();
        // -2 top (-1 left, +1 right)
        if (position.getColumn() > 1)
        {
            if (position.getLine() > 0)
            {
                topLeftPath.add(new Coordinate(position.getLine() - 1, position.getColumn() - 2));
            }
            if (position.getLine() < 7)
            {
                topRightPath.add(new Coordinate(position.getLine() + 1, position.getColumn() - 2));
            }
        }
        // +2 bottom (-1 left, +1 right)
        if (position.getColumn() < 6)
        {
            if (position.getLine() > 0)
            {
                bottomLeftPath.add(new Coordinate(position.getLine() - 1, position.getColumn() + 2));
            }
            if (position.getLine() < 7)
            {
                bottomRightPath.add(new Coordinate(position.getLine() + 1, position.getColumn() + 2));
            }
        }
        // +2 right (-1 top, +1 bottom)
        if (position.getLine() < 6)
        {
            if (position.getColumn() > 0)
            {
                rightTopPath.add(new Coordinate(position.getLine() + 2, position.getColumn() - 1));
            }
            if (position.getColumn() < 7)
            {
                rightBottomPath.add(new Coordinate(position.getLine() + 2, position.getColumn() + 1));
            }
        }
        // -2 left (-1 top, +1 bottom)
        if (position.getLine() > 1)
        {
            if (position.getColumn() > 0)
            {
                leftTopPath.add(new Coordinate(position.getLine() - 2, position.getColumn() - 1));
            }
            if (position.getColumn() < 7)
            {
                leftBottomPath.add(new Coordinate(position.getLine() - 2, position.getColumn() + 1));
            }
        }
        coordinates.add(topLeftPath);
        coordinates.add(topRightPath);
        coordinates.add(bottomLeftPath);
        coordinates.add(bottomRightPath);
        coordinates.add(leftTopPath);
        coordinates.add(leftBottomPath);
        coordinates.add(rightTopPath);
        coordinates.add(rightBottomPath);
        return coordinates;
    }

    @Override
    public List<List<Coordinate>> getCaptureMovements(Coordinate position)
    {
        return getSimpleMovements(position);
    }
}
