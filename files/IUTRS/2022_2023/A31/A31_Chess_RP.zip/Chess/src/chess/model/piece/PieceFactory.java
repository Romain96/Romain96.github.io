package chess.model.piece;

import chess.model.movement.*;
import chess.model.player.PlayerColor;

public class PieceFactory
{
    public PieceFactory()
    {}

    public Piece createPawn(PlayerColor color)
    {
        MovementContext context = new MovementContext();
        context.addStrategy(new PawnMovement(color == PlayerColor.BLACK));
        return new Pawn(color, context);
    }

    public Piece createRook(PlayerColor color)
    {
        MovementContext context = new MovementContext();
        context.addStrategy(new VerticalMovement(7));
        context.addStrategy(new HorizontalMovement(7));
        return new Rook(color, context);
    }

    public Piece createBishop(PlayerColor color)
    {
        MovementContext context = new MovementContext();
        context.addStrategy(new DiagonalMovement(7));
        return new Bishop(color, context);
    }

    public Piece createKnight(PlayerColor color)
    {
        MovementContext context = new MovementContext();
        context.addStrategy(new KnightMovement(0));
        return new Knight(color, context);
    }

    public Piece createQueen(PlayerColor color)
    {
        MovementContext context = new MovementContext();
        context.addStrategy(new VerticalMovement(7));
        context.addStrategy(new HorizontalMovement(7));
        context.addStrategy(new DiagonalMovement(7));
        return new Queen(color, context);
    }

    public Piece createKing(PlayerColor color)
    {
        MovementContext context = new MovementContext();
        context.addStrategy(new VerticalMovement(1));
        context.addStrategy(new HorizontalMovement(1));
        context.addStrategy(new DiagonalMovement(1));
        return new King(color, context);
    }
}
