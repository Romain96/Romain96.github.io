package chess.model;

import chess.Resources;
import chess.model.movement.Coordinate;
import chess.model.movement.PawnMovement;
import chess.model.observer.GameObserver;
import chess.model.piece.*;
import chess.model.player.Player;
import chess.model.player.PlayerColor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Game
{
    private Board _board;
    private Player _blackPlayer;
    private Player _whitePlayer;
    private Resources _resources;
    private PlayerColor _currentPlayer;
    private Coordinate _selectedPiece;
    private List<Coordinate> _allowedMoves;
    private List<Coordinate> _captureMoves;
    private List<GameObserver> _observers;

    public Game()
    {
        _board = null;
        _blackPlayer = new Player(PlayerColor.BLACK, "Black");
        _whitePlayer = new Player(PlayerColor.WHITE, "White");
        _resources = null;
        _currentPlayer = null;
        _selectedPiece = null;
        _allowedMoves = new ArrayList<>();
        _captureMoves = new ArrayList<>();
        _observers = new ArrayList<>();
    }

    public Board getBoard()
    {
        return _board;
    }

    public Player getBlackPlayer()
    {
        return _blackPlayer;
    }

    public Player getWhitePlayer()
    {
        return _whitePlayer;
    }

    public Resources getResources()
    {
        return _resources;
    }

    public Coordinate getSelectedPiece()
    {
        return _selectedPiece;
    }

    public PlayerColor getCurrentPlayer()
    {
        return _currentPlayer;
    }

    public List<Coordinate> getAllowedMoves()
    {
        return _allowedMoves;
    }

    public List<Coordinate> getCaptureMoves()
    {
        return _captureMoves;
    }

    public List<GameObserver> getObservers()
    {
        return _observers;
    }

    public void setBoard(Board board)
    {
        _board = board;
    }

    public void setBlackPlayer(Player blackPlayer)
    {
        _blackPlayer = blackPlayer;
    }

    public void setWhitePlayer(Player whitePlayer)
    {
        _whitePlayer = whitePlayer;
    }

    public void setResources(Resources resources)
    {
        _resources = resources;
    }

    public void setSelectedPiece(Coordinate selectedPiece)
    {
        _selectedPiece = selectedPiece;
    }

    public void setCurrentPlayer(PlayerColor currentPlayer)
    {
        _currentPlayer = currentPlayer;
    }

    public void setAllowedMoves(List<Coordinate> allowedMoves)
    {
        _allowedMoves = allowedMoves;
    }

    public void setCaptureMoves(List<Coordinate> captureMoves)
    {
        _captureMoves = captureMoves;
    }

    public void setObservers(List<GameObserver> observers)
    {
        _observers = observers;
    }

    public void addObserver(GameObserver observer)
    {
        _observers.add(observer);
    }

    public void removeObserver(GameObserver observer)
    {
        _observers.remove(observer);
    }

    public void removeAllObservers()
    {
        _observers.clear();
    }

    public Boolean hasSelectedAPiece()
    {
        if (getSelectedPiece().getLine() == -1 || getSelectedPiece().getColumn() == -1)
        {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    public void resetGame()
    {
        setCurrentPlayer(PlayerColor.WHITE);
        setSelectedPiece(new Coordinate(-1, -1));
        initBoard();
    }

    private void initBoard()
    {
        // assigning images to the board tiles
        setBoard(new Board(8, 8));
        getBoard().initTileImages(getResources());

        // creating black and white pieces with images and placing them on tiles
        PieceFactory factory = new PieceFactory();

        // creating & placing white pieces
        Piece whiteRook1 = factory.createRook(PlayerColor.WHITE);
        whiteRook1.setImage(getResources().getWhitePieces().get("rook"));
        getBoard().getTile(7, 0).setPiece(whiteRook1);
        Piece whiteKnight1 = factory.createKnight(PlayerColor.WHITE);
        whiteKnight1.setImage(getResources().getWhitePieces().get("knight"));
        getBoard().getTile(7, 1).setPiece(whiteKnight1);
        Piece whiteBishop1 = factory.createBishop(PlayerColor.WHITE);
        whiteBishop1.setImage(getResources().getWhitePieces().get("bishop"));
        getBoard().getTile(7, 2).setPiece(whiteBishop1);
        Piece whiteQueen = factory.createQueen(PlayerColor.WHITE);
        whiteQueen.setImage(getResources().getWhitePieces().get("queen"));
        getBoard().getTile(7, 3).setPiece(whiteQueen);
        Piece whiteKing = factory.createKing(PlayerColor.WHITE);
        whiteKing.setImage(getResources().getWhitePieces().get("king"));
        getBoard().getTile(7, 4).setPiece(whiteKing);
        Piece whiteBishop2 = factory.createBishop(PlayerColor.WHITE);
        whiteBishop2.setImage(getResources().getWhitePieces().get("bishop"));
        getBoard().getTile(7, 5).setPiece(whiteBishop2);
        Piece whiteKnight2 = factory.createKnight(PlayerColor.WHITE);
        whiteKnight2.setImage(getResources().getWhitePieces().get("knight"));
        getBoard().getTile(7, 6).setPiece(whiteKnight2);
        Piece whiteRook2 = factory.createRook(PlayerColor.WHITE);
        whiteRook2.setImage(getResources().getWhitePieces().get("rook"));
        getBoard().getTile(7, 7).setPiece(whiteRook2);
        for (int column = 0; column < 8; column++)
        {
            Piece whitePawn = factory.createPawn(PlayerColor.WHITE);
            whitePawn.setImage(getResources().getWhitePieces().get("pawn"));
            getBoard().getTile(6, column).setPiece(whitePawn);
        }

        // creating & placing black pieces
        Piece blackRook1 = factory.createRook(PlayerColor.BLACK);
        blackRook1.setImage(getResources().getBlackPieces().get("rook"));
        getBoard().getTile(0, 0).setPiece(blackRook1);
        Piece blackKnight1 = factory.createKnight(PlayerColor.BLACK);
        blackKnight1.setImage(getResources().getBlackPieces().get("knight"));
        getBoard().getTile(0, 1).setPiece(blackKnight1);
        Piece blackBishop1 = factory.createBishop(PlayerColor.BLACK);
        blackBishop1.setImage(getResources().getBlackPieces().get("bishop"));
        getBoard().getTile(0, 2).setPiece(blackBishop1);
        Piece blackQueen = factory.createQueen(PlayerColor.BLACK);
        blackQueen.setImage(getResources().getBlackPieces().get("queen"));
        getBoard().getTile(0, 3).setPiece(blackQueen);
        Piece blackKing = factory.createKing(PlayerColor.BLACK);
        blackKing.setImage(getResources().getBlackPieces().get("king"));
        getBoard().getTile(0, 4).setPiece(blackKing);
        Piece blackBishop2 = factory.createBishop(PlayerColor.BLACK);
        blackBishop2.setImage(getResources().getBlackPieces().get("bishop"));
        getBoard().getTile(0, 5).setPiece(blackBishop2);
        Piece blackKnight2 = factory.createKnight(PlayerColor.BLACK);
        blackKnight2.setImage(getResources().getBlackPieces().get("knight"));
        getBoard().getTile(0, 6).setPiece(blackKnight2);
        Piece blackRook2 = factory.createRook(PlayerColor.BLACK);
        blackRook2.setImage(getResources().getBlackPieces().get("rook"));
        getBoard().getTile(0, 7).setPiece(blackRook2);
        for (int column = 0; column < 8; column++)
        {
            Piece blackPawn = factory.createPawn(PlayerColor.BLACK);
            blackPawn.setImage(getResources().getBlackPieces().get("pawn"));
            getBoard().getTile(1, column).setPiece(blackPawn);
        }
    }

    public void determineAllMovesFromSelectedTile()
    {
        List<Coordinate> allowed = new ArrayList<>();
        List<Coordinate> capture = new ArrayList<>();

        Integer line = getSelectedPiece().getLine();
        Integer column = getSelectedPiece().getColumn();

        Piece selectedPiece = getBoard().getTile(line, column).getPiece();
        List<List<Coordinate>> allowedMoves = selectedPiece.getAllPossibleMovements(getSelectedPiece());

        // specific case for the pawn where capture and moves are not the same
        if (selectedPiece instanceof Pawn)
        {
            for (List<Coordinate> path : allowedMoves)
            {
                boolean stopPath = false;
                for (Coordinate coord : path)
                {
                    Tile tile = getBoard().getTile(coord.getLine(), coord.getColumn());
                    // if the tile has a piece we are blocked whether it is ours or our opponent's
                    if (tile.getPiece() != null)
                    {
                        stopPath = true;
                    }
                    // the tile is empty
                    else
                    {
                        // we are not blocked so we can move to this tile
                        if (!stopPath)
                        {
                            allowed.add(coord);
                        }
                    }
                }
            }
            assert selectedPiece.getMovements().getStrategies().size() == 1;
            assert selectedPiece.getMovements().getStrategies().getFirst() instanceof PawnMovement;
            for (List<Coordinate> captureCoordinates : ((PawnMovement) selectedPiece.getMovements().getStrategies().getFirst()).getCaptureMovements(getSelectedPiece()))
            {
                for (Coordinate captureCoordinate : captureCoordinates)
                {
                    Tile tile = getBoard().getTile(captureCoordinate.getLine(), captureCoordinate.getColumn());
                    // if the tile has a piece
                    if (tile.getPiece() != null)
                    {
                        // if it is one of our opponent's we can capture it
                        // otherwise nothing since it's not a move but a specific capture-only move
                        if (tile.getPiece().getColor() != getCurrentPlayer())
                        {
                            capture.add(captureCoordinate);
                        }
                    }
                }
            }
        }
        // general case where capture and moves are the same
        else
        {
            for (List<Coordinate> path : allowedMoves)
            {
                boolean stopPath = false;
                for (Coordinate coord : path)
                {
                    Tile tile = getBoard().getTile(coord.getLine(), coord.getColumn());
                    // if the tile has a piece
                    if (tile.getPiece() != null)
                    {
                        // if it is one of ours then we are blocked from this point on
                        if (tile.getPiece().getColor() == getCurrentPlayer())
                        {
                            stopPath = true;
                        }
                        // if it is one of the opponent's
                        else
                        {
                            // if it is the first one we can capture it, then we are blocked from this point on
                            if (!stopPath)
                            {
                                capture.add(coord);
                                stopPath = true;
                            }
                        }
                    }
                    // the tile is empty
                    else
                    {
                        // we are not blocked so we can move to this tile
                        if (!stopPath)
                        {
                            allowed.add(coord);
                        }
                    }
                }
            }
        }

        setAllowedMoves(allowed);
        setCaptureMoves(capture);
        notifyShowAllAllowedMoves(allowed, capture);
    }

    public void moveOrCapturePieceToTile(Integer originLine, Integer originColumn, Integer destinationLine, Integer destinationColumn)
    {
        // if the moved piece is a pawn and it is moved for the first time, restrict its movements to 1 tile instead of 2
        Piece toMove = getBoard().getTile(originLine, originColumn).getPiece();
        if (toMove instanceof Pawn)
        {
            if (!((Pawn) toMove).hasMovedOnce())
            {
                ((Pawn) toMove).restrictMovements();
            }
        }
        Piece targetPiece = getBoard().getTile(destinationLine, destinationColumn).getPiece();
        if (targetPiece != null && targetPiece.getColor() != getCurrentPlayer() && targetPiece instanceof King)
        {
            notifyGameEnded(getNextPlayer(), getCurrentPlayer());
            return;
        }
        getBoard().moveTile(originLine, originColumn, destinationLine, destinationColumn);
        if (toMove instanceof Pawn)
        {
            if (toMove.getColor() == PlayerColor.BLACK && destinationLine == 7 || toMove.getColor() == PlayerColor.WHITE && destinationLine == 0)
            {
                notifyPawnPromotion(destinationLine, destinationColumn);
            }
        }
        setCurrentPlayer(getNextPlayer());
        notifyPlayerTurn();
    }

    public PlayerColor getNextPlayer()
    {
        switch (getCurrentPlayer())
        {
            case BLACK ->
            {
                return PlayerColor.WHITE;
            }
            case WHITE ->
            {
                return PlayerColor.BLACK;
            }
        }
        return null;
    }

    private List<Coordinate> simulateAllMovesFromTile(Board board, Coordinate position)
    {
        List<Coordinate> movements = new ArrayList<>();

        Integer line = position.getLine();
        Integer column = position.getColumn();

        Piece selectedPiece = board.getTile(line, column).getPiece();
        PlayerColor attackerColor = selectedPiece.getColor();
        List<List<Coordinate>> allowedMoves = selectedPiece.getAllPossibleMovements(position);

        // specific case for the pawn where capture and moves are not the same
        if (selectedPiece instanceof Pawn)
        {
            assert selectedPiece.getMovements().getStrategies().size() == 1;
            assert selectedPiece.getMovements().getStrategies().getFirst() instanceof PawnMovement;
            for (List<Coordinate> captureCoordinates : ((PawnMovement) selectedPiece.getMovements().getStrategies().getFirst()).getSimpleMovements(position))
            {
                for (Coordinate captureCoordinate : captureCoordinates)
                {
                    Tile tile = board.getTile(captureCoordinate.getLine(), captureCoordinate.getColumn());
                    // if the tile has a piece
                    if (tile.getPiece() != null)
                    {
                        // if it is one of our opponent's we can capture it
                        // otherwise nothing since it's not a move but a specific capture-only move
                        if (tile.getPiece().getColor() != attackerColor)
                        {
                            movements.add(captureCoordinate);
                        }
                    }
                }
            }
            for (List<Coordinate> captureCoordinates : ((PawnMovement) selectedPiece.getMovements().getStrategies().getFirst()).getCaptureMovements(position))
            {
                for (Coordinate captureCoordinate : captureCoordinates)
                {
                    Tile tile = board.getTile(captureCoordinate.getLine(), captureCoordinate.getColumn());
                    // if the tile has a piece
                    if (tile.getPiece() != null)
                    {
                        // if it is one of our opponent's we can capture it
                        // otherwise nothing since it's not a move but a specific capture-only move
                        if (tile.getPiece().getColor() != attackerColor)
                        {
                            movements.add(captureCoordinate);
                        }
                    }
                }
            }
        }
        // general case where capture and moves are the same
        else
        {
            for (List<Coordinate> path : allowedMoves)
            {
                boolean stopPath = false;
                for (Coordinate coordinate : path)
                {
                    Tile tile = board.getTile(coordinate.getLine(), coordinate.getColumn());
                    // if the tile has a piece
                    if (tile.getPiece() != null)
                    {
                        // if it is one of ours then we are blocked from this point on
                        if (tile.getPiece().getColor() == attackerColor)
                        {
                            stopPath = true;
                        }
                        // if it is one of the opponent's
                        else
                        {
                            // if it is the first one we can capture it, then we are blocked from this point on
                            if (!stopPath)
                            {
                                movements.add(coordinate);
                                stopPath = true;
                            }
                        }
                    }
                }
            }
        }
        return movements;
    }

    public List<Coordinate> getKingMovements(Coordinate position)
    {
        List<Coordinate> allowed = new ArrayList<>();

        Integer line = position.getLine();
        Integer column = position.getColumn();

        Piece selectedPiece = getBoard().getTile(line, column).getPiece();
        PlayerColor kingColor = selectedPiece.getColor();
        List<List<Coordinate>> allowedMoves = selectedPiece.getAllPossibleMovements(new Coordinate(line, column));

        for (List<Coordinate> path : allowedMoves)
        {
            boolean stopPath = false;
            for (Coordinate coordinate : path)
            {
                Tile tile = getBoard().getTile(coordinate.getLine(), coordinate.getColumn());
                // if the tile has a piece
                if (tile.getPiece() != null)
                {
                    // if it is one of ours then we are blocked from this point on
                    if (tile.getPiece().getColor() == kingColor)
                    {
                        stopPath = true;
                    }
                    // if it is one of the opponent's
                    else
                    {
                        // if it is the first one we can capture it, then we are blocked from this point on
                        if (!stopPath)
                        {
                            stopPath = true;
                            allowed.add(coordinate);
                        }
                    }
                }
                // the tile is empty
                else
                {
                    // we are not blocked so we can move to this tile
                    if (!stopPath)
                    {
                        allowed.add(coordinate);
                    }
                }
            }
        }
        return allowed;
    }

    private Coordinate findKingPosition()
    {
        for (Integer line = 0; line < getBoard().getLines(); line++)
        {
            for (Integer column = 0; column < getBoard().getColumns(); column++)
            {
                if (getBoard().getTile(line, column).getPiece() != null)
                {
                    if (getBoard().getTile(line, column).getPiece() instanceof King && getBoard().getTile(line, column).getPiece().getColor() == getCurrentPlayer())
                    {
                        return new Coordinate(line, column);
                    }
                }
            }
        }
        // not found (should not be possible)
        return new Coordinate(-1, -1);
    }

    // verifies if the current player's king is in a checkmate position
    public void verifyKingIsInCheckmate()
    {
        Coordinate kingPosition = findKingPosition();
        // if the king is in a soft checkmate then verifying to possible moves
        if (verifyKingIsInCheckmateInCurrentPosition(getBoard(), kingPosition))
        {
            // if there is a hard checkmate then the player has lost the game
            if (verifyKingIsInCheckmateInAllMovements(kingPosition))
            {
                // no possible movement from the king or any of its allied piece, game lost !
                if (verifyKingIsInCheckmateWithAllAllyMovements(kingPosition))
                {
                    notifyGameEnded(getNextPlayer(), getCurrentPlayer());
                }
            }
            // soft checkmate only, the player has to move its king
        }
        // else all moves are valid, there is no checkmate
    }

    // verifies if the current player's king is in a soft checkmate
    // the current king's position is a checkmate but other moves are not checked (see verifyHardCheckmate instead)
    public Boolean verifyKingIsInCheckmateInCurrentPosition(Board board, Coordinate kingPosition)
    {
        // retrieving all moves (capture moves for pawns) from all pieces not belonging to the current player
        // is at least one piece can capture the king then he is in a soft checkmate position
        PlayerColor kingColor = board.getTile(kingPosition.getLine(), kingPosition.getColumn()).getPiece().getColor();
        for (Integer line = 0; line < board.getLines(); line++)
        {
            for (Integer column = 0; column < board.getColumns(); column++)
            {
                Piece piece = board.getTile(line, column).getPiece();
                if (piece != null && piece.getColor() != kingColor)
                {
                    // all capture moves
                    List<Coordinate> captureMoves = simulateAllMovesFromTile(board, new Coordinate(line, column));
                    // searching for the king position inside
                    for (Coordinate captureMove : captureMoves)
                    {
                        if (Objects.equals(captureMove.getLine(), kingPosition.getLine()) && Objects.equals(captureMove.getColumn(), kingPosition.getColumn()))
                        {
                            return Boolean.TRUE;
                        }
                    }
                }
            }
        }
        return Boolean.FALSE;
    }

    private Board simulateMove(Board board, Piece piece, Coordinate origin, Coordinate destination)
    {
        Board fakeBoard = new Board(board.getLines(), getBoard().getColumns());
        for (int line = 0; line < fakeBoard.getLines(); line++)
        {
            for (int column = 0; column < fakeBoard.getColumns(); column++)
            {
                Tile realTile = board.getTile(line, column);
                Tile fakeTile = new Tile(realTile.getLine(), realTile.getColumn());
                if (realTile.getPiece() != null)
                {
                    fakeTile.setPiece(realTile.getPiece());
                }
                fakeBoard.setTile(line, column, fakeTile);
            }
        }
        fakeBoard.getTile(destination.getLine(), destination.getColumn()).setPiece(piece);
        return fakeBoard;
    }

    // verifies if the current player's king has at least one valid move that would not result in a checkmate
    // does not check the current king's position (see verifySoftCheckmate instead)
    public Boolean verifyKingIsInCheckmateInAllMovements(Coordinate kingPosition)
    {
        int numberOfAllowedMoves = 0;

        // retrieving all allowed moves (non capture) moves from the king
        Piece king = getBoard().getTile(kingPosition.getLine(), kingPosition.getColumn()).getPiece();
        List<Coordinate> kingMoves = getKingMovements(kingPosition);

        for (Coordinate kingMove : kingMoves)
        {
            // moving the king to each of them and checking if there is a soft checkmate for that move
            Board simBoard = simulateMove(getBoard(), king, kingPosition, kingMove);
            // is there is at least one move for which there is no soft checkmate then there is no hard checkmate
            if (!verifyKingIsInCheckmateInCurrentPosition(simBoard, kingMove))
            {
                numberOfAllowedMoves++;
            }
        }

        // hard checkmate, no valid move get the king out of the checkmate
        if (numberOfAllowedMoves == 0)
        {
            return Boolean.TRUE;
        }
        // soft checkmate only, the king can move to avoid a hard checkmate
        return Boolean.FALSE;
    }

    // verify is any allied piece can cover the king to avoid a checkmate
    // this is intended to be called only if both previous methods returned true
    public Boolean verifyKingIsInCheckmateWithAllAllyMovements(Coordinate kingPosition)
    {
        // retrieving the king and its possible movements
        Piece king = getBoard().getTile(kingPosition.getLine(), kingPosition.getColumn()).getPiece();
        List<Coordinate> kingMoves = getKingMovements(kingPosition);

        // for all other allied pieces
        for (int line = 0; line < getBoard().getLines(); line++)
        {
            for (int column = 0; column < getBoard().getColumns(); column++)
            {
                Piece tilePiece = getBoard().getTile(line, column).getPiece();
                if (tilePiece != null && tilePiece.getColor() == king.getColor() && !(tilePiece instanceof King))
                {
                    List<Coordinate> alliedPieceMovements = simulateAllMovesFromTile(getBoard(), new Coordinate(line, column));
                    for (Coordinate alliedPieceMovement : alliedPieceMovements)
                    {
                        Board simBoardAlliedMove = simulateMove(getBoard(), tilePiece, new Coordinate(line, column), alliedPieceMovement);
                        // if this move nullifies the soft checkmate then there is at least one valid move to save the king
                        if (!verifyKingIsInCheckmateInCurrentPosition(simBoardAlliedMove, kingPosition))
                        {
                            return Boolean.FALSE;
                        }
                    }
                }
            }
        }
        return Boolean.TRUE;
    }

    public void promotePawnToQueen(Integer line, Integer column)
    {
        PieceFactory factory = new PieceFactory();
        Piece queen = factory.createQueen(getNextPlayer());
        switch (getNextPlayer())
        {
            case WHITE ->
            {
                queen.setImage(getResources().getWhitePieces().get("queen"));
            }
            case BLACK ->
            {
                queen.setImage(getResources().getBlackPieces().get("queen"));
            }
        }
        getBoard().getTile(line, column).setPiece(queen);
    }

    public void promotePawnToKnight(Integer line, Integer column)
    {
        PieceFactory factory = new PieceFactory();
        Piece knight = factory.createKnight(getNextPlayer());
        switch (getNextPlayer())
        {
            case WHITE ->
            {
                knight.setImage(getResources().getWhitePieces().get("knight"));
            }
            case BLACK ->
            {
                knight.setImage(getResources().getBlackPieces().get("knight"));
            }
        }
        getBoard().getTile(line, column).setPiece(knight);
    }

    public void promotePawnToRook(Integer line, Integer column)
    {
        PieceFactory factory = new PieceFactory();
        Piece rook = factory.createRook(getNextPlayer());
        switch (getNextPlayer())
        {
            case WHITE ->
            {
                rook.setImage(getResources().getWhitePieces().get("rook"));
            }
            case BLACK ->
            {
                rook.setImage(getResources().getBlackPieces().get("rook"));
            }
        }
        getBoard().getTile(line, column).setPiece(rook);
    }

    public void promotePawnToBishop(Integer line, Integer column)
    {
        PieceFactory factory = new PieceFactory();
        Piece bishop = factory.createBishop(getNextPlayer());
        switch (getNextPlayer())
        {
            case WHITE ->
            {
                bishop.setImage(getResources().getWhitePieces().get("bishop"));
            }
            case BLACK ->
            {
                bishop.setImage(getResources().getBlackPieces().get("bishop"));
            }
        }
        getBoard().getTile(line, column).setPiece(bishop);
    }

    public void notifyPlayerTurn()
    {
        for (GameObserver observer : getObservers())
        {
            observer.updatePlayerTurn(getBoard().getTiles(), getBoard().getLines(), getBoard().getColumns(), getCurrentPlayer());
        }
    }

    public void notifyTileSelected()
    {
        for (GameObserver observer : getObservers())
        {
            observer.updateTileSelected(
                    getBoard().getTiles(), getBoard().getLines(), getBoard().getColumns(),
                    getCurrentPlayer(), getSelectedPiece().getLine(), getSelectedPiece().getColumn()
            );
        }
    }

    public void notifyTileUnselected()
    {
        for (GameObserver observer : getObservers())
        {
            observer.updateTileUnselected(
                    getBoard().getTiles(), getBoard().getLines(), getBoard().getColumns(),
                    getCurrentPlayer(), getSelectedPiece().getLine(), getSelectedPiece().getColumn()
            );
        }
    }

    public void notifyShowAllAllowedMoves(List<Coordinate> allowed, List<Coordinate> capture)
    {
        for (GameObserver observer : getObservers())
        {
            observer.updateShowAllowedMoves(getBoard().getTiles(), getBoard().getLines(), getBoard().getColumns(), getCurrentPlayer(), getSelectedPiece(), allowed, capture);
        }
    }

    public void notifyGameEnded(PlayerColor winner, PlayerColor looser)
    {
        for (GameObserver observer : getObservers())
        {
            observer.updateGameEnded(winner, looser);
        }
    }

    public void notifyPawnPromotion(Integer line, Integer column)
    {
        for (GameObserver observer : getObservers())
        {
            observer.updatePromotePawn(line, column);
        }
    }
}
