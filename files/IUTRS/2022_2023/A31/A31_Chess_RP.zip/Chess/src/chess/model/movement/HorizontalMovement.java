package chess.model.movement;

import java.util.ArrayList;
import java.util.List;

public class HorizontalMovement extends PieceMovement
{
    public HorizontalMovement(Integer repeat)
    {
        super(repeat);
    }

    @Override
    public List<List<Coordinate>> getSimpleMovements(Coordinate position)
    {
        List<List<Coordinate>> coordinates = new ArrayList<>();
        List<Coordinate> rightPath = new ArrayList<>();
        List<Coordinate> leftPath = new ArrayList<>();
        int offset = 1;
        while (offset <= getRepeat())
        {
            if (position.getColumn() - offset >= 0)
            {
                leftPath.add(new Coordinate(position.getLine(), position.getColumn() - offset));
            }
            if (position.getColumn() + offset <= 7)
            {
                rightPath.add(new Coordinate(position.getLine(), position.getColumn() + offset));
            }
            offset++;
        }
        coordinates.add(leftPath);
        coordinates.add(rightPath);
        return coordinates;
    }

    @Override
    public List<List<Coordinate>> getCaptureMovements(Coordinate position)
    {
        return getSimpleMovements(position);
    }
}
