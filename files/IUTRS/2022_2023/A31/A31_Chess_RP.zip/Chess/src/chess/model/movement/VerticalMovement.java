package chess.model.movement;

import java.util.ArrayList;
import java.util.List;

public class VerticalMovement extends PieceMovement
{
    public VerticalMovement(Integer repeat)
    {
        super(repeat);
    }

    @Override
    public List<List<Coordinate>> getSimpleMovements(Coordinate position)
    {
        List<List<Coordinate>> coordinates = new ArrayList<>();
        List<Coordinate> topPath = new ArrayList<>();
        List<Coordinate> bottomPath = new ArrayList<>();
        int offset = 1;
        while (offset <= getRepeat())
        {
            if (position.getLine() - offset >= 0)
            {
                topPath.add(new Coordinate(position.getLine() - offset, position.getColumn()));
            }
            if (position.getLine() + offset <= 7)
            {
                bottomPath.add(new Coordinate(position.getLine() + offset, position.getColumn()));
            }
            offset++;
        }
        coordinates.add(topPath);
        coordinates.add(bottomPath);
        return coordinates;
    }

    @Override
    public List<List<Coordinate>> getCaptureMovements(Coordinate position)
    {
        return getSimpleMovements(position);
    }
}
