package chess;

import chess.controller.ChessController;
import chess.model.Game;
import chess.view.ChessView;

import java.io.IOException;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        Resources resources = new Resources("img");
        resources.loadAll();
        Game game = new Game();
        game.setResources(resources);
        ChessController controller = new ChessController(game);
        ChessView view = new ChessView(controller, resources);
        controller.startGame(view);
    }
}