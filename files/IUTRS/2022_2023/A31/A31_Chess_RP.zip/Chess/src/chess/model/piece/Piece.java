package chess.model.piece;

import chess.model.movement.Coordinate;
import chess.model.movement.MovementContext;
import chess.model.movement.MovementStrategy;
import chess.model.player.PlayerColor;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class Piece
{
    private PlayerColor _color;
    private MovementContext _movements;
    private BufferedImage _image;

    public Piece(PlayerColor color, MovementContext movements)
    {
        _color = color;
        _movements = movements;
        _image = null;
    }

    public PlayerColor getColor()
    {
        return _color;
    }

    public MovementContext getMovements()
    {
        return _movements;
    }

    public BufferedImage getImage()
    {
        return _image;
    }

    public void setPlayerColor(PlayerColor color)
    {
        _color = color;
    }

    public void setMovements(MovementContext movements)
    {
        _movements = movements;
    }

    public void setImage(BufferedImage image)
    {
        _image = image;
    }

    public List<List<Coordinate>> getAllPossibleMovements(Coordinate position)
    {
        List<List<Coordinate>> coordinates = new ArrayList<>();
        for (MovementStrategy strategy : getMovements().getStrategies())
        {
           coordinates.addAll(strategy.getSimpleMovements(position));
        }
        return coordinates;
    }
}
