package chess.model.player;

public enum PlayerColor
{
    BLACK,
    WHITE;
}