package chess.model.piece;

import chess.model.movement.MovementContext;
import chess.model.movement.PieceMovement;
import chess.model.player.PlayerColor;

public class Pawn extends Piece
{
    private Boolean _moved;

    public Pawn(PlayerColor color, MovementContext movements)
    {
        super(color, movements);
        _moved = Boolean.FALSE;
    }

    public Boolean getMoved()
    {
        return _moved;
    }

    public void setMoved(Boolean moved)
    {
        _moved = moved;
    }

    public Boolean hasMovedOnce()
    {
        return getMoved();
    }

    public void restrictMovements()
    {
        setMoved(Boolean.TRUE);
        for (PieceMovement moveStrategy : getMovements().getStrategies())
        {
            moveStrategy.setRepeat(1);
        }
    }
}
