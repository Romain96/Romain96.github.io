package chess.view;

import chess.ImageUtils;
import chess.Resources;
import chess.controller.ChessController;
import chess.model.Tile;
import chess.model.movement.Coordinate;
import chess.model.observer.BoardObserver;
import chess.model.observer.GameObserver;
import chess.model.player.PlayerColor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.List;

public class ChessView extends JFrame implements BoardObserver, GameObserver
{
    private ChessController _controller;
    private Resources _resources;
    private JButton[][] _tiles;
    private Integer _tileSize;

    private JPanel _mainPanel;
    private JPanel _boardPanel;

    public ChessView(ChessController controller, Resources resources)
    {
        super();

        _tileSize = 75;
        _controller = controller;
        _resources = resources;

        _mainPanel = new JPanel(new FlowLayout());

        initBoardPanel();
        _mainPanel.add(_boardPanel);

        setContentPane(_mainPanel);

        setTitle("Chess Game by RP");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        pack();
    }

    private void initBoardPanel()
    {
        _boardPanel = new JPanel(new GridLayout(10, 10, 0, 0));

        // 1st and 9th line (2nd to 9th columns) = letters A-H
        // 1st and 10th column (2nd to 9th lines) = digits 8-1
        // other tiles from (2nd line, 2nd column) to (9th line, 9th) column = chess tiles from (1st, 1st) to (8th, 8th)

        // 1st line
        JButton dummy1 = new JButton("");
        dummy1.setMinimumSize(new Dimension(_tileSize, _tileSize));
        dummy1.setMaximumSize(new Dimension(_tileSize, _tileSize));
        dummy1.setPreferredSize(new Dimension(_tileSize, _tileSize));
        dummy1.setVisible(true);
        dummy1.setEnabled(false);
        _boardPanel.add(dummy1);

        for (String letter : new String[] {"letter_A", "letter_B", "letter_C", "letter_D", "letter_E", "letter_F", "letter_G", "letter_H"})
        {
            JButton letterButton = new JButton("");
            letterButton.setMinimumSize(new Dimension(_tileSize, _tileSize));
            letterButton.setMaximumSize(new Dimension(_tileSize, _tileSize));
            letterButton.setPreferredSize(new Dimension(_tileSize, _tileSize));
            BufferedImage letterImage = ImageUtils.scaleImage(_resources.getLetters().get(letter), _tileSize);
            letterButton.setIcon(new ImageIcon(letterImage));
            letterButton.setVisible(true);
            for (ActionListener al : letterButton.getActionListeners())
            {
                letterButton.removeActionListener(al);
            }
            _boardPanel.add(letterButton);
        }

        JButton dummy2 = new JButton("");
        dummy2.setMinimumSize(new Dimension(_tileSize, _tileSize));
        dummy2.setMaximumSize(new Dimension(_tileSize, _tileSize));
        dummy2.setPreferredSize(new Dimension(_tileSize, _tileSize));
        dummy2.setVisible(true);
        dummy2.setEnabled(false);
        _boardPanel.add(dummy2);

        _tiles = new JButton[8][8];

        // 2nd to 9th lines
        String[] digits = new String[]{"digit_8", "digit_7", "digit_6", "digit_5", "digit_4", "digit_3", "digit_2", "digit_1"};
        int index = 0;
        for (int line = 0; line < 8; line++)
        {
            JButton digitButton1 = new JButton("");
            digitButton1.setMinimumSize(new Dimension(_tileSize, _tileSize));
            digitButton1.setMaximumSize(new Dimension(_tileSize, _tileSize));
            digitButton1.setPreferredSize(new Dimension(_tileSize, _tileSize));
            BufferedImage digitImage1 = ImageUtils.scaleImage(_resources.getDigits().get(digits[index]), _tileSize);
            digitButton1.setIcon(new ImageIcon(digitImage1));
            digitButton1.setVisible(true);
            _boardPanel.add(digitButton1);

            for (int column = 0; column < 8; column++)
            {
                JButton tileButton = new JButton("");
                tileButton.setMinimumSize(new Dimension(_tileSize, _tileSize));
                tileButton.setMaximumSize(new Dimension(_tileSize, _tileSize));
                tileButton.setPreferredSize(new Dimension(_tileSize, _tileSize));
                tileButton.setVisible(true);
                int finalLine = line;
                int finalColumn = column;
                tileButton.addActionListener(e -> {_controller.selectTile(finalLine, finalColumn);});
                _tiles[line][column] = tileButton;
                _boardPanel.add(tileButton);
            }

            JButton digitButton2 = new JButton("");
            digitButton2.setMinimumSize(new Dimension(_tileSize, _tileSize));
            digitButton2.setMaximumSize(new Dimension(_tileSize, _tileSize));
            digitButton2.setPreferredSize(new Dimension(_tileSize, _tileSize));
            BufferedImage digitImage2 = ImageUtils.scaleImage(_resources.getDigits().get(digits[index]), _tileSize);
            digitButton2.setIcon(new ImageIcon(digitImage2));
            digitButton2.setVisible(true);
            _boardPanel.add(digitButton2);
            _boardPanel.add(digitButton2);
            index++;
        }

        // 10th line
        JButton dummy3 = new JButton("");
        dummy3.setMinimumSize(new Dimension(_tileSize, _tileSize));
        dummy3.setMaximumSize(new Dimension(_tileSize, _tileSize));
        dummy3.setPreferredSize(new Dimension(_tileSize, _tileSize));
        dummy3.setVisible(true);
        dummy3.setEnabled(false);
        _boardPanel.add(dummy3);

        for (String letter : new String[] {"A", "B", "C", "D", "E", "F", "G", "H"})
        {
            JButton letterButton = new JButton("");
            letterButton.setMinimumSize(new Dimension(_tileSize, _tileSize));
            letterButton.setMaximumSize(new Dimension(_tileSize, _tileSize));
            letterButton.setPreferredSize(new Dimension(_tileSize, _tileSize));
            BufferedImage letterImage = ImageUtils.scaleImage(_resources.getLetters().get("letter_" + letter), _tileSize);
            letterButton.setIcon(new ImageIcon(letterImage));
            letterButton.setVisible(true);
            for (ActionListener al : letterButton.getActionListeners())
            {
                letterButton.removeActionListener(al);
            }
            _boardPanel.add(letterButton);
        }

        JButton dummy4 = new JButton("");
        dummy4.setMinimumSize(new Dimension(_tileSize, _tileSize));
        dummy4.setMaximumSize(new Dimension(_tileSize, _tileSize));
        dummy4.setPreferredSize(new Dimension(_tileSize, _tileSize));
        dummy4.setVisible(true);
        dummy4.setEnabled(false);
        _boardPanel.add(dummy4);
    }

    @Override
    public void updateBoard(Tile[][] tiles, Integer lines, Integer columns)
    {
        for (int line = 0; line < lines; line++)
        {
            for (int column = 0; column < columns; column++)
            {
                BufferedImage tileImage = ImageUtils.scaleImage(tiles[line][column].getImage(), _tileSize);
                if (tiles[line][column].getPiece() != null)
                {
                    BufferedImage pieceImage = ImageUtils.scaleImage(tiles[line][column].getPiece().getImage(), _tileSize);
                    tileImage = ImageUtils.superimposeImages(tileImage, pieceImage);
                }
                _tiles[line][column].setIcon(new ImageIcon(tileImage));
            }
        }
        repaint();
    }

    @Override
    public void updatePlayerTurn(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player)
    {
        for (int line = 0; line < lines; line++)
        {
            for (int column = 0; column < columns; column++)
            {
                BufferedImage tileImage = ImageUtils.scaleImage(tiles[line][column].getImage(), _tileSize);
                if (tiles[line][column].getPiece() != null)
                {
                    // one of ours
                    if (tiles[line][column].getPiece().getColor() == player)
                    {
                        BufferedImage allowedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("allowed"), _tileSize);
                        tileImage = ImageUtils.superimposeImages(tileImage, allowedContourImage);
                    }
                    // not one of ours
                    else
                    {
                        BufferedImage disallowedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("disallowed"), _tileSize);
                        tileImage = ImageUtils.superimposeImages(tileImage, disallowedContourImage);
                    }

                    BufferedImage pieceImage = ImageUtils.scaleImage(tiles[line][column].getPiece().getImage(), _tileSize);
                    tileImage = ImageUtils.superimposeImages(tileImage, pieceImage);
                }
                _tiles[line][column].setIcon(new ImageIcon(tileImage));
            }
        }
    }

    @Override
    public void updateTileSelected(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player, Integer selectLine, Integer selectColumn)
    {
        // unselecting all tiles
        updateTileUnselected(tiles, lines, columns, player, selectLine, selectColumn);

        // selecting the selected tile
        BufferedImage selectedTileImage = ImageUtils.scaleImage(tiles[selectLine][selectColumn].getImage(), _tileSize);
        BufferedImage selectedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("selected"), _tileSize);
        selectedTileImage = ImageUtils.superimposeImages(selectedTileImage, selectedContourImage);
        BufferedImage pieceImage = ImageUtils.scaleImage(tiles[selectLine][selectColumn].getPiece().getImage(), _tileSize);
        selectedTileImage = ImageUtils.superimposeImages(selectedTileImage, pieceImage);
        _tiles[selectLine][selectColumn].setIcon(new ImageIcon(selectedTileImage));
    }

    @Override
    public void updateTileUnselected(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player, Integer selectLine, Integer selectColumn)
    {
        for (int line = 0; line < lines; line++)
        {
            for (int column = 0; column < columns; column++)
            {
                BufferedImage tileImage = ImageUtils.scaleImage(tiles[line][column].getImage(), _tileSize);
                // a piece is on the tile
                if (tiles[line][column].getPiece() != null)
                {
                    // one of ours
                    if (tiles[line][column].getPiece().getColor() == player)
                    {
                        BufferedImage allowedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("allowed"), _tileSize);
                        tileImage = ImageUtils.superimposeImages(tileImage, allowedContourImage);
                    }
                    // not one of ours
                    else
                    {
                        BufferedImage disallowedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("disallowed"), _tileSize);
                        tileImage = ImageUtils.superimposeImages(tileImage, disallowedContourImage);
                    }
                    BufferedImage pieceImage = ImageUtils.scaleImage(tiles[line][column].getPiece().getImage(), _tileSize);
                    tileImage = ImageUtils.superimposeImages(tileImage, pieceImage);
                }
                _tiles[line][column].setIcon(new ImageIcon(tileImage));
            }
        }
    }

    @Override
    public void updateShowAllowedMoves(Tile[][] tiles, Integer lines, Integer columns, PlayerColor player, Coordinate selected, List<Coordinate> allowed, List<Coordinate> capture)
    {
        BufferedImage selectedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("selected"), _tileSize);
        BufferedImage allowedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("allowed"), _tileSize);
        BufferedImage disallowedContourImage = ImageUtils.scaleImage(_resources.getTiles().get("disallowed"), _tileSize);
        BufferedImage captureContourImage = ImageUtils.scaleImage(_resources.getTiles().get("capture"), _tileSize);

        // disallowing all tiles
        for (int line = 0; line < lines; line++)
        {
            for (int column = 0; column < columns; column++)
            {
                BufferedImage tileImage = ImageUtils.scaleImage(tiles[line][column].getImage(), _tileSize);
                tileImage = ImageUtils.superimposeImages(tileImage, disallowedContourImage);
                if (tiles[line][column].getPiece() != null)
                {
                    BufferedImage pieceImage = ImageUtils.scaleImage(tiles[line][column].getPiece().getImage(), _tileSize);
                    tileImage = ImageUtils.superimposeImages(tileImage, pieceImage);
                }
                _tiles[line][column].setIcon(new ImageIcon(tileImage));
            }
        }

        // selecting the selected piece
        BufferedImage tileImage = ImageUtils.scaleImage(tiles[selected.getLine()][selected.getColumn()].getImage(), _tileSize);
        tileImage = ImageUtils.superimposeImages(tileImage, selectedContourImage);
        BufferedImage pieceImage = ImageUtils.scaleImage(tiles[selected.getLine()][selected.getColumn()].getPiece().getImage(), _tileSize);
        tileImage = ImageUtils.superimposeImages(tileImage, pieceImage);
        _tiles[selected.getLine()][selected.getColumn()].setIcon(new ImageIcon(tileImage));

        // allowing the allowed moves
        for (Coordinate coordinate : allowed)
        {
            BufferedImage allowedTileImage = ImageUtils.scaleImage(tiles[coordinate.getLine()][coordinate.getColumn()].getImage(), _tileSize);
            allowedTileImage = ImageUtils.superimposeImages(allowedTileImage, allowedContourImage);
            if (tiles[coordinate.getLine()][coordinate.getColumn()].getPiece() != null)
            {
                BufferedImage allowedPieceImage = ImageUtils.scaleImage(tiles[coordinate.getLine()][coordinate.getColumn()].getPiece().getImage(), _tileSize);
                allowedTileImage = ImageUtils.superimposeImages(allowedTileImage, allowedPieceImage);
            }
            _tiles[coordinate.getLine()][coordinate.getColumn()].setIcon(new ImageIcon(allowedTileImage));
        }

        // capturing the captured moves
        for (Coordinate coordinate : capture)
        {
            BufferedImage capturedTileImage = ImageUtils.scaleImage(tiles[coordinate.getLine()][coordinate.getColumn()].getImage(), _tileSize);
            capturedTileImage = ImageUtils.superimposeImages(capturedTileImage, captureContourImage);
            if (tiles[coordinate.getLine()][coordinate.getColumn()].getPiece() != null)
            {
                BufferedImage capturedPieceImage = ImageUtils.scaleImage(tiles[coordinate.getLine()][coordinate.getColumn()].getPiece().getImage(), _tileSize);
                capturedTileImage = ImageUtils.superimposeImages(capturedTileImage, capturedPieceImage);
            }
            _tiles[coordinate.getLine()][coordinate.getColumn()].setIcon(new ImageIcon(capturedTileImage));
        }
    }

    @Override
    public void updateGameEnded(PlayerColor winner, PlayerColor looser)
    {
        JPanel endPanel = new JPanel();
        endPanel.setLayout(new BoxLayout(endPanel, BoxLayout.Y_AXIS));
        JLabel endText = new JLabel(winner + " player won the game, " + looser + " player was checkmate !");
        endPanel.add(endText);
        setContentPane(endPanel);
        repaint();
    }

    @Override
    public void updatePromotePawn(Integer line, Integer column)
    {
        JFrame promotionFrame = new JFrame("Pawn promotion");
        promotionFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel promotionPanel = new JPanel();
        promotionPanel.setLayout(new BoxLayout(promotionPanel, BoxLayout.Y_AXIS));

        JLabel promotionLabel = new JLabel("Congratulation, you can promote your pawn !\nPlease choose the available promotion.");
        promotionPanel.add(promotionLabel);

        JButton buttonQueen = new JButton("Queen");
        buttonQueen.addActionListener(e -> {_controller.promotePawnToQueen(line, column); promotionFrame.dispose();});
        JButton buttonKnight = new JButton("Knight");
        buttonKnight.addActionListener(e -> {_controller.promotePawnToKnight(line, column); promotionFrame.dispose();});
        JButton buttonRook = new JButton("Rook");
        buttonRook.addActionListener(e -> {_controller.promotePawnToRook(line, column); promotionFrame.dispose();});
        JButton buttonBishop = new JButton("Bishop");
        buttonBishop.addActionListener(e -> {_controller.promotePawnToBishop(line, column); promotionFrame.dispose();});
        JPanel promotionButtons = new JPanel(new GridLayout(1, 4, 0, 0));
        promotionButtons.add(buttonQueen);
        promotionButtons.add(buttonKnight);
        promotionButtons.add(buttonRook);
        promotionButtons.add(buttonBishop);

        promotionPanel.add(promotionButtons);

        promotionFrame.setContentPane(promotionPanel);
        promotionFrame.setVisible(true);
        promotionFrame.pack();
    }
}
