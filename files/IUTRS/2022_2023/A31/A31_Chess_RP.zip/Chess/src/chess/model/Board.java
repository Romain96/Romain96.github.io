package chess.model;

import chess.Resources;
import chess.model.observer.BoardObserver;
import chess.model.piece.Piece;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class Board
{
    private Integer _lines;
    private Integer _columns;
    private Tile[][] _tiles;
    private List<BoardObserver> _observers;

    public Board(Integer lines, Integer columns)
    {
        _observers = new ArrayList<>();
        _lines = lines;
        _columns = columns;
        _tiles = new Tile[_lines][_lines];
        for (int line = 0; line < _lines; line++)
        {
            for (int column = 0; column < 8; column++)
            {
                _tiles[line][column] = new Tile(line, column);
            }
        }
    }

    public Tile[][] getTiles()
    {
        return _tiles;
    }

    public Integer getLines()
    {
        return _lines;
    }

    public Integer getColumns()
    {
        return _columns;
    }

    public List<BoardObserver> getObservers()
    {
        return _observers;
    }

    public void setTiles(Tile[][] tiles)
    {
        _tiles = tiles;
    }

    public void setLines(Integer lines)
    {
        _lines = lines;
    }

    public void setColumns(Integer columns)
    {
        _columns = columns;
    }

    public void setObservers(List<BoardObserver> observers)
    {
        _observers = observers;
    }

    public Tile getTile(Integer line, Integer column)
    {
        return _tiles[line][column];
    }

    public void setTile(Integer line, Integer column, Tile tile)
    {
        _tiles[line][column] = tile;
    }

    public void addObserver(BoardObserver observer)
    {
        _observers.add(observer);
    }

    public void removeObserver(BoardObserver observer)
    {
        _observers.remove(observer);
    }

    public void removeAllObservers()
    {
        _observers.clear();
    }

    public void notifyBoardChanged()
    {
        for (BoardObserver observer : _observers)
        {
            observer.updateBoard(getTiles(), getLines(), getColumns());
        }
    }

    public void initTileImages(Resources resources)
    {
        BufferedImage white = resources.getTiles().get("white");
        BufferedImage black = resources.getTiles().get("black");
        BufferedImage[] coloredTiles = new BufferedImage[] {white, black};
        int index = 0;

        for (int line = 0; line < getLines(); line++)
        {
            for (int column = 0; column < getColumns(); column++)
            {
                getTile(line, column).setImage(coloredTiles[index]);
                index = (index + 1) % 2;
            }
            index = (index + 1) % 2;
        }
    }

    public void moveTile(Integer originLine, Integer originColumn, Integer destinationLine, Integer destinationColumn)
    {
        Piece toMove = getTile(originLine, originColumn).getPiece();
        getTile(destinationLine, destinationColumn).setPiece(toMove);
        getTile(originLine, originColumn).setPiece(null);
    }
}
