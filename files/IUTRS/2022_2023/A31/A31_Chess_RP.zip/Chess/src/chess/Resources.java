package chess;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Resources
{
    private String _path;
    private Map<String, BufferedImage> _tiles;
    private Map<String, BufferedImage> _blackPieces;
    private Map<String, BufferedImage> _whitePieces;
    private Map<String, BufferedImage> _letters;
    private Map<String, BufferedImage> _digits;

    public Resources(String path)
    {
        _path = path;
        _tiles = new HashMap<>();
        _blackPieces = new HashMap<>();
        _whitePieces = new HashMap<>();
        _letters = new HashMap<>();
        _digits = new HashMap<>();
    }

    public String getPath()
    {
        return _path;
    }

    public Map<String, BufferedImage> getTiles()
    {
        return _tiles;
    }

    public Map<String, BufferedImage> getBlackPieces()
    {
        return _blackPieces;
    }

    public Map<String, BufferedImage> getWhitePieces()
    {
        return _whitePieces;
    }

    public Map<String, BufferedImage> getLetters()
    {
        return _letters;
    }

    public Map<String, BufferedImage> getDigits()
    {
        return _digits;
    }

    public void setPath(String path)
    {
        _path = path;
    }

    public void setTiles(Map<String, BufferedImage> tiles)
    {
        _tiles = tiles;
    }

    public void setBlackPieces(Map<String, BufferedImage> blackPieces)
    {
        _blackPieces = blackPieces;
    }

    public void setWhitePieces(Map<String, BufferedImage> whitePieces)
    {
        _whitePieces = whitePieces;
    }

    public void setLetters(Map<String, BufferedImage> letters)
    {
        _letters = letters;
    }

    public void setDigits(Map<String, BufferedImage> digits)
    {
        _digits = digits;
    }

    public void loadAll() throws IOException
    {
        loadTiles();
        loadBlackPieces();
        loadWhitePieces();
        loadLetters();
        loadDigits();
    }

    public void loadTiles() throws IOException
    {
        getTiles().clear();
        String[] keys = new String[] {"black", "white", "allowed", "disallowed", "selected", "capture"};
        for (String key : keys)
        {
            BufferedImage value = ImageUtils.loadImage(getPath() + "/board/tiles/" + key + ".png");
            if (value != null)
            {
                getTiles().put(key, value);
            }
        }
    }

    public void loadBlackPieces() throws IOException
    {
        getBlackPieces().clear();
        String[] keys = new String[] {"king", "queen", "bishop", "knight", "rook", "pawn"};
        for (String key : keys)
        {
            BufferedImage value = ImageUtils.loadImage(getPath() + "/pieces/black/" + key + ".png");
            if (value != null)
            {
                getBlackPieces().put(key, value);
            }
        }
    }

    public void loadWhitePieces() throws IOException
    {
        getWhitePieces().clear();
        String[] keys = new String[] {"king", "queen", "bishop", "knight", "rook", "pawn"};
        for (String key : keys)
        {
            BufferedImage value = ImageUtils.loadImage(getPath() + "/pieces/white/" + key + ".png");
            if (value != null)
            {
                getWhitePieces().put(key, value);
            }
        }
    }

    public void loadLetters() throws IOException
    {
        getLetters().clear();
        String[] keys = new String[] {"letter_A", "letter_B", "letter_C", "letter_D", "letter_E", "letter_F", "letter_G", "letter_H"};
        for (String key : keys)
        {
            BufferedImage value = ImageUtils.loadImage(getPath() + "/board/letters/" + key + ".png");
            if (value != null)
            {
                getLetters().put(key, value);
            }
        }
    }

    public void loadDigits() throws IOException
    {
        getDigits().clear();
        String[] keys = new String[] {"digit_1", "digit_2", "digit_3", "digit_4", "digit_5", "digit_6", "digit_7", "digit_8"};
        for (String key : keys)
        {
            BufferedImage value = ImageUtils.loadImage(getPath() + "/board/digits/" + key + ".png");
            if (value != null)
            {
                getDigits().put(key, value);
            }
        }
    }
}
