package chess.model.player;

public class Player
{
    private PlayerColor _color;
    private String _name;

    public Player(PlayerColor color, String name)
    {
        _color = color;
        _name = name;
    }

    public PlayerColor getColor()
    {
        return _color;
    }

    public String getName()
    {
        return _name;
    }

    public void setColor(PlayerColor color)
    {
        _color = color;
    }

    public void setName(String name)
    {
        _name = name;
    }
}
