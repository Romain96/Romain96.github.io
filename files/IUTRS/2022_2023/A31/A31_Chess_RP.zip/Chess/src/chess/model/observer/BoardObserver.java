package chess.model.observer;

import chess.model.Tile;

public interface BoardObserver
{
    void updateBoard(Tile[][] tiles, Integer lines, Integer columns);
}
