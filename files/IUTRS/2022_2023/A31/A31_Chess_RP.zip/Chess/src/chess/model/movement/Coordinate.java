package chess.model.movement;

public class Coordinate
{
    private Integer _line;
    private Integer _column;

    public Coordinate(Integer line, Integer column)
    {
        _line = line;
        _column = column;
    }

    public Integer getLine()
    {
        return _line;
    }

    public Integer getColumn()
    {
        return _column;
    }

    public void setLine(Integer line)
    {
        _line = line;
    }

    public void setColumn(Integer column)
    {
        _column = column;
    }
}
