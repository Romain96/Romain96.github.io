package chess.model.movement;

import java.util.List;

public interface MovementStrategy
{
    List<List<Coordinate>> getSimpleMovements(Coordinate position);
    List<List<Coordinate>> getCaptureMovements(Coordinate position);
}
