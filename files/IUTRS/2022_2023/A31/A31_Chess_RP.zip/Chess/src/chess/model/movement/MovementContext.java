package chess.model.movement;

import java.util.ArrayList;
import java.util.List;

public class MovementContext
{
    private List<PieceMovement> _strategies;

    public MovementContext()
    {
        _strategies = new ArrayList<>();
    }

    public MovementContext(List<PieceMovement> strategies)
    {
        _strategies = strategies;
    }

    public List<PieceMovement> getStrategies()
    {
        return _strategies;
    }

    public void setStrategies(List<PieceMovement> strategies)
    {
        _strategies = strategies;
    }

    public void addStrategy(PieceMovement strategy)
    {
        if (!getStrategies().contains(strategy))
        {
            getStrategies().add(strategy);
        }
    }

    public void removeStrategy(PieceMovement strategy)
    {
        getStrategies().remove(strategy);
    }

    public void clearAllStrategies()
    {
        getStrategies().clear();
    }
}
