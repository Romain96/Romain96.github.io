package chess.model.movement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class PieceMovement implements MovementStrategy
{
    private Integer _repeat;

    public PieceMovement(Integer repeat)
    {
        _repeat = repeat;
    }

    public Integer getRepeat()
    {
        return _repeat;
    }

    public void setRepeat(Integer repeat)
    {
        _repeat = repeat;
    }

    @Override
    public List<List<Coordinate>> getSimpleMovements(Coordinate position)
    {
        return Collections.singletonList(new ArrayList<Coordinate>() {
        });
    }
}
